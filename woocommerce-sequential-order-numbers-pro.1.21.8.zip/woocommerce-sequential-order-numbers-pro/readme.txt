=== WooCommerce Sequential Order Numbers Pro ===
Author: skyverge
Tags: woocommerce
Requires at least: 5.6
Tested up to: 6.9
Requires PHP: 7.4
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Installation ==

1. Upload the entire 'woocommerce-sequential-order-numbers-pro' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
