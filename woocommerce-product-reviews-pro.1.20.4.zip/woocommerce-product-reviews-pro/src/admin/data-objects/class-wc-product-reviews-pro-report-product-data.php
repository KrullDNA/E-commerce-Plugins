<?php

/**
 * Data transfer object to hold information about the result of a Reviews report.
 */
class WC_Product_Reviews_Pro_Report_Product_Data
{
	/** @var WC_Product relevant product */
	public WC_Product $product;

	/** @var int number of reviews */
	public int $review_count = 0;

	/** @var int highest rating */
	public int $highest_rating = 0;

	/** @var int lowest rating */
	public int $lowest_rating = 0;

	/** @var int|float average rating */
	public $average_rating = 0;

	/**
	 * Constructor.
	 *
	 * @param WC_Product $product
	 * @param int $review_count
	 * @param int $highest_rating
	 * @param int $lowest_rating
	 * @param int|float $average_rating
	 */
	public function __construct(WC_Product $product, int $review_count, int $highest_rating, int $lowest_rating, $average_rating)
	{
		$this->product = $product;
		$this->review_count = $review_count;
		$this->highest_rating = $highest_rating;
		$this->lowest_rating = $lowest_rating;
		$this->average_rating = $average_rating;
	}
}
