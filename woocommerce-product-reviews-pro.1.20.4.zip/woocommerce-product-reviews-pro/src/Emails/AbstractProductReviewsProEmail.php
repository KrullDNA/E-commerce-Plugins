<?php
/**
 * WooCommerce Product Reviews Pro
 *
 * This source file is subject to the GNU General Public License v3.0
 * that is bundled with this package in the file license.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.html
 * If you did not receive a copy of the license and are unable to
 * obtain it through the world-wide-web, please send an email
 * to license@skyverge.com so we can send you a copy immediately.
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade WooCommerce Product Reviews Pro to newer
 * versions in the future. If you wish to customize WooCommerce Product Reviews Pro for your
 * needs please refer to http://docs.woocommerce.com/document/woocommerce-product-reviews-pro/ for more information.
 *
 * @author    SkyVerge
 * @copyright Copyright (c) 2015-2025, SkyVerge, Inc.
 * @license   http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */

namespace SkyVerge\WooCommerce\Product_Reviews_Pro\Emails;

use SkyVerge\WooCommerce\PluginFramework\v5_15_10\Emails\Traits\HasEmailPreviewValuesTrait;
use WC_Contribution;
use WC_Contribution_Comment;
use WC_Contribution_Review;
use WC_Email;
use WP_Comment;

abstract class AbstractProductReviewsProEmail extends WC_Email
{
	use HasEmailPreviewValuesTrait;

	/**
	 * Builds a dummy contribution object for use in previews.
	 *
	 * @since 1.20.0
	 */
	protected function getDummyContribution() : WC_Contribution
	{
		return new WC_Contribution_Review($this->getDummyComment());
	}

	/**
	 * Builds a dummy contribution comment object for use in previews.
	 *
	 * @since 1.20.0
	 */
	protected function getDummyContributionComment() : WC_Contribution_Comment
	{
		return new WC_Contribution_Comment($this->getDummyComment([
			'comment_type' => 'comment',
		]));
	}

	/**
	 * Builds a dummy WP Comment object for use in previews. This is required to build our other objects that utilize WP Comments as a base.
	 *
	 * @since 1.20.0
	 */
	protected function getDummyComment(array $args = []) : WP_Comment
	{
		return new WP_Comment((object) wp_parse_args($args, [
			'comment_ID' => 0,
			'comment_post_ID' => $this->getRandomProduct()->get_id(), // we need a real product ID for this
			'comment_author' => 'Jane Doe',
			'comment_author_email' => 'janedoe@example.org',
			'comment_author_url' => '',
			'comment_author_IP' => '192.168.1.1',
			'comment_date' => current_time('mysql', false),
			'comment_date_gmt' => current_time('mysql', true),
			'comment_content' => 'TODO',
			'comment_type' => 'review',
		]));
	}
}
