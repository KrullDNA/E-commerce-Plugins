<?php
/**
 * Smart Coupons analytics loader
 *
 * Loads analytics-related modules such as insights.
 *
 * @author      StoreApps
 * @since       9.73.0
 * @version     1.0.0
 * @package     WooCommerce Smart Coupons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_Analytics_Loader' ) ) {

	/**
	 * Analytics loader for Smart Coupons.
	 *
	 * @since 9.72.0
	 */
	class WC_SC_Analytics_Loader {

		/**
		 * Instance of WC_SC_Analytics_Loader.
		 *
		 * @var WC_SC_Analytics_Loader
		 */
		private static $instance = null;

		/**
		 * Get single instance of WC_SC_Analytics_Loader.
		 *
		 * @return WC_SC_Analytics_Loader
		 */
		public static function get_instance() {
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		private function __construct() {
			if ( ! is_admin() ) {
				return;
			}

			add_action( 'wp_dashboard_setup', array( $this, 'register_dashboard_widgets' ) );
			add_action( 'wp_ajax_wc_sc_get_insights_metrics', array( $this, 'ajax_get_insights_metrics' ) );
		}

		/**
		 * Handle dynamic calls by forwarding to main Smart Coupons instance.
		 *
		 * @param string $function_name Function name.
		 * @param array  $arguments     Arguments passed to function.
		 * @return mixed
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Load revenue insights dependencies if not already loaded.
		 *
		 * @return void
		 */
		private function load_insights_dependencies() {
			if ( ! class_exists( 'WC_SC_Insights_Order_Helper' ) ) {
				require_once WC_SC_PLUGIN_DIRPATH . 'includes/analytics/insights/class-wc-sc-insights-order-helper.php';
			}

			if ( ! class_exists( 'WC_SC_Insights' ) ) {
				require_once WC_SC_PLUGIN_DIRPATH . 'includes/analytics/insights/class-wc-sc-insights.php';
			}

			if ( ! class_exists( 'WC_SC_Revenue_Insights' ) ) {
				require_once WC_SC_PLUGIN_DIRPATH . 'includes/analytics/insights/revenue/class-wc-sc-revenue-insights.php';
			}
		}

		/**
		 * Register analytics dashboard widgets.
		 *
		 * @return void
		 */
		public function register_dashboard_widgets() {
			try {
				if ( ! current_user_can( 'manage_woocommerce' ) ) {
					return;
				}

				$this->load_insights_dependencies();

				WC_SC_Insights::get_instance()->register_dashboard_widget();
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
			}
		}

		/**
		 * AJAX handler to return revenue insights metrics.
		 *
		 * @return void
		 */
		public function ajax_get_insights_metrics() {
			try {
				if ( ! current_user_can( 'manage_woocommerce' ) ) {
					wp_send_json_error(
						array(
							'message' => _x( 'Permission denied.', 'ajax error', 'woocommerce-smart-coupons' ),
						)
					);
				}

				check_ajax_referer( 'wc_sc_get_insights_metrics', 'nonce' );

				$this->load_insights_dependencies();

				$insights           = WC_SC_Insights::get_instance();
				$normalized_metrics = $insights->get_normalized_default_metrics();
				$config             = $insights->get_config();
				$sections_data      = array();

				if ( ! empty( $config['sections'] ) ) {
					$sections_config = $config['sections'];

					// Sort sections by 'priority'.
					uasort(
						$sections_config,
						function ( $a, $b ) {
							$priority_a = isset( $a['priority'] ) ? (int) $a['priority'] : 10;
							$priority_b = isset( $b['priority'] ) ? (int) $b['priority'] : 10;
							if ( $priority_a === $priority_b ) {
								return 0;
							}
							return ( $priority_a < $priority_b ) ? -1 : 1;
						}
					);

					foreach ( $sections_config as $section_id => $section ) {
						$section_data = array(
							'label'   => isset( $section['label'] ) ? $section['label'] : '',
							'metrics' => array(),
						);

						if ( ! empty( $section['metrics'] ) ) {
							$metrics_config = $section['metrics'];

							foreach ( $metrics_config as $metric_key => $metric_meta ) {
								$value = isset( $normalized_metrics[ $metric_key ] ) ? $normalized_metrics[ $metric_key ] : 0;

								$section_data['metrics'][ $metric_key ] = array(
									'label' => isset( $metric_meta['label'] ) ? $metric_meta['label'] : '',
									'value' => $value,
								);
							}
						}

						$sections_data[ $section_id ] = $section_data;
					}
				}

				/**
				 * Filters the AJAX response data for Smart Coupons insights.
				 *
				 * @since 9.73.0
				 *
				 * @param array $sections_data      The formatted sections and metrics data.
				 * @param array $normalized_metrics The raw normalized metrics.
				 *
				 * @example
				 * add_filter( 'wc_sc_insights_ajax_sections_data', function( $sections_data, $normalized_metrics ) {
				 *     $sections_data['my_section']['metrics']['my_metric']['value'] = '100';
				 *     return $sections_data;
				 * }, 10, 2 );
				 */
				$sections_data = apply_filters( 'wc_sc_insights_ajax_sections_data', $sections_data, $normalized_metrics );

				wp_send_json_success(
					array(
						'sections' => $sections_data,
					)
				);
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );

				wp_send_json_error(
					array(
						'message' => _x( 'An error occurred while loading insights.', 'ajax error', 'woocommerce-smart-coupons' ),
					)
				);
			}
		}
	}
}

WC_SC_Analytics_Loader::get_instance();
