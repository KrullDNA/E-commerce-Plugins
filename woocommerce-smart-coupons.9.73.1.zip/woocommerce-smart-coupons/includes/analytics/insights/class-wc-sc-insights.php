<?php
/**
 * Smart Coupons insights
 *
 * Controller for Smart Coupons insights dashboard widget.
 *
 * @author      StoreApps
 * @since       9.73.0
 * @version     1.0.0
 * @package     WooCommerce Smart Coupons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_Insights' ) ) {

	/**
	 * Class WC_SC_Insights
	 */
	class WC_SC_Insights {

		/**
		 * Instance of WC_SC_Insights.
		 *
		 * @var WC_SC_Insights
		 */
		private static $instance = null;

		/**
		 * Get single instance of WC_SC_Insights.
		 *
		 * @return WC_SC_Insights
		 */
		public static function get_instance() {
			// Check if instance is already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Handle dynamic calls by forwarding to main Smart Coupons instance.
		 *
		 * @since 9.73.0
		 *
		 * @param string $function_name Function name.
		 * @param array  $arguments     Arguments passed to function.
		 * @return mixed
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return null;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Register insights dashboard widget.
		 *
		 * @since 9.73.0
		 *
		 * @return void
		 */
		public function register_dashboard_widget() {
			try {
				wp_add_dashboard_widget(
					'wc_sc_insights',
					_x( 'Smart Coupons – Results', 'dashboard widget title', 'woocommerce-smart-coupons' ),
					array( $this, 'render_dashboard_widget' )
				);
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
			}
		}

		/**
		 * Render insights dashboard widget.
		 *
		 * @since 9.73.0
		 *
		 * @return void
		 */
		public function render_dashboard_widget() {
			try {
				$view = WC_SC_PLUGIN_DIRPATH . 'includes/analytics/insights/views/dashboard-widget.php';

				if ( file_exists( $view ) ) {
					$metrics = array(
						'nonce'       => wp_create_nonce( 'wc_sc_get_insights_metrics' ),
						'ajax_action' => 'wc_sc_get_insights_metrics',
						'config'      => $this->get_config(),
					);

					include $view;
				}
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
			}
		}

		/**
		 * Get the metrics configuration for the Insights widget.
		 *
		 * This defines the sections, labels, and individual metrics to be displayed.
		 * Developers can use the 'wc_sc_insights_config' filter to extend this.
		 *
		 * @since 9.73.0
		 *
		 * @return array
		 */
		public function get_config() {
			/**
			 * Filters the configuration for Smart Coupons insights.
			 *
			 * @since 9.73.0
			 *
			 * @param array $config The initial configuration array.
			 *
			 * @example
			 * add_filter( 'wc_sc_insights_config', function( $config ) {
			 *     $config['sections']['my_section'] = array(
			 *         'label'    => 'My Section',
			 *         'priority' => 20,
			 *         'metrics'  => array(
			 *             'my_metric' => array(
			 *                 'label' => 'My Metric',
			 *             ),
			 *         ),
			 *     );
			 *     return $config;
			 * } );
			 */
			return apply_filters( 'wc_sc_insights_config', array( 'sections' => array() ) );
		}

		/**
		 * Get a flat array of all registered metric keys.
		 *
		 * @since 9.73.0
		 *
		 * @return array
		 */
		public function get_registered_metric_keys() {
			try {
				$config = $this->get_config();
				$keys   = array();

				if ( ! empty( $config['sections'] ) ) {
					foreach ( $config['sections'] as $section ) {
						if ( ! empty( $section['metrics'] ) ) {
							$keys = array_merge( $keys, array_keys( $section['metrics'] ) );
						}
					}
				}

				return array_unique( $keys );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return array();
			}
		}

		/**
		 * Generate an empty metrics array based on currently registered keys.
		 *
		 * @since 9.73.0
		 *
		 * @return array
		 */
		public function get_empty_metrics() {
			try {
				$keys    = $this->get_registered_metric_keys();
				$metrics = array();

				foreach ( $keys as $key ) {
					$metrics[ $key ] = 0;
				}

				return $metrics;
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return array();
			}
		}

		/**
		 * Get metrics for default range (all paid orders).
		 *
		 * @since 9.73.0
		 *
		 * @return array
		 */
		protected function get_metrics_for_default_range() {
			try {
				/**
				 * Filters the arguments for calculating default insights metrics.
				 *
				 * @since 9.73.0
				 *
				 * @param array $args    The calculation arguments.
				 * @param array $context The context.
				 */
				$args = apply_filters(
					'wc_sc_insights_default_calculate_args',
					array(
						'start_date' => '',
						'end_date'   => '',
						'statuses'   => wc_get_is_paid_statuses(),
					),
					array( 'source' => $this )
				);

				/**
				 * Filters the default metrics for Smart Coupons insights.
				 *
				 * @since 9.73.0
				 *
				 * @param array $metrics Initial metrics array.
				 * @param array $args    The calculation arguments.
				 * @param array $context The context.
				 */
				$metrics = apply_filters( 'wc_sc_insights_default_metrics_args', array(), $args, array( 'source' => $this ) );

				if ( ! empty( $metrics ) ) {
					return $metrics;
				}

				return $this->get_empty_metrics();
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );

				return $this->get_empty_metrics();
			}
		}

		/**
		 * Normalize metrics before passing to view.
		 *
		 * @since 9.73.0
		 *
		 * @param array $metrics Raw metrics.
		 * @return array
		 */
		protected function normalize_metrics_for_view( $metrics ) {
			try {
				$defaults = $this->get_empty_metrics();

				$metrics = wp_parse_args( $metrics, $defaults );

				foreach ( $metrics as $key => $value ) {
					if ( is_numeric( $value ) ) {
						$metrics[ $key ] = (float) $value;
					}
				}

				return $metrics;
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );

				return $this->get_empty_metrics();
			}
		}

		/**
		 * Get normalized metrics for default range.
		 *
		 * @since 9.73.0
		 *
		 * @return array
		 */
		public function get_normalized_default_metrics() {
			try {
				$metrics = $this->get_metrics_for_default_range();
				return $this->normalize_metrics_for_view( $metrics );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return $this->get_empty_metrics();
			}
		}
	}

}

WC_SC_Insights::get_instance();
