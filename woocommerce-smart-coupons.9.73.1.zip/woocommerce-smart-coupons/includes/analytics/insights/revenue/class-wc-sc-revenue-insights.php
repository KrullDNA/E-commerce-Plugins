<?php
/**
 * Smart Coupons revenue insights
 *
 * Aggregates Smart Coupons revenue metrics over a set of orders.
 *
 * @author      StoreApps
 * @since       9.73.0
 * @version     1.0.0
 * @package     WooCommerce Smart Coupons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_Revenue_Insights' ) ) {

	/**
	 * Class WC_SC_Revenue_Insights
	 */
	class WC_SC_Revenue_Insights {

		/**
		 * Instance of WC_SC_Revenue_Insights.
		 *
		 * @var WC_SC_Revenue_Insights
		 */
		private static $instance = null;

		/**
		 * Order helper instance.
		 *
		 * @var WC_SC_Insights_Order_Helper
		 */
		protected $order_helper;

		/**
		 * Get single instance of WC_SC_Revenue_Insights.
		 *
		 * @return WC_SC_Revenue_Insights
		 */
		public static function get_instance() {
			// Check if instance is already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor.
		 */
		public function __construct() {
			$this->order_helper = new WC_SC_Insights_Order_Helper();
			add_filter( 'wc_sc_insights_config', array( $this, 'add_insights_config' ) );
			add_filter( 'wc_sc_insights_default_metrics_args', array( $this, 'get_revenue_metrics' ), 10, 2 );
		}

		/**
		 * Handle call to functions which is not available in this class.
		 *
		 * @param string $function_name Function name.
		 * @param array  $arguments     Arguments passed while calling $function_name.
		 * @return mixed
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Add insights config for revenue insights.
		 *
		 * @since 9.73.0
		 *
		 * @param array $config Existing config.
		 * @return array
		 */
		public function add_insights_config( $config ) {
			global $store_credit_label;
			$config['sections']['revenue'] = array(
				'label'    => _x( 'Revenue Insights', 'dashboard widget', 'woocommerce-smart-coupons' ),
				'priority' => 1,
				'metrics'  => array(
					'store_credit_used'     => array(
						/* translators: PLural label for store credit */
						'label' => sprintf( _x( '%s used', 'dashboard widget', 'woocommerce-smart-coupons' ), $store_credit_label['plural'] ),
					),
					'orders_count'          => array(
						'label' => _x( 'Orders', 'dashboard widget', 'woocommerce-smart-coupons' ),
					),
					'action_products_value' => array(
						'label' => _x( 'Additional sales from coupon', 'dashboard widget', 'woocommerce-smart-coupons' ),
					),
					'gross_revenue'         => array(
						'label' => _x( 'Gross revenue', 'dashboard widget', 'woocommerce-smart-coupons' ),
					),
				),
			);

			return $config;
		}

		/**
		 * Get revenue metrics.
		 *
		 * @since 9.73.0
		 *
		 * @param array $metrics Existing metrics.
		 * @param array $args    Calculation arguments.
		 * @return array
		 */
		public function get_revenue_metrics( $metrics, $args ) {
			try {
				$revenue_metrics = $this->calculate( $args );

				if ( ! empty( $revenue_metrics ) ) {
					$metrics = array_merge( $metrics, $revenue_metrics );
				}

				return $metrics;
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return $metrics;
			}
		}

		/**
		 * Get empty metrics array.
		 *
		 * @since 9.73.0
		 *
		 * @return array
		 */
		public function get_empty_metrics() {
			return array(
				'orders_count'          => number_format_i18n( 0 ),
				'gross_revenue'         => wc_price( 0.0 ),
				'store_credit_used'     => wc_price( 0.0 ),
				'action_products_value' => wc_price( 0.0 ),
			);
		}

		/**
		 * Calculate revenue metrics for Smart Coupons orders.
		 *
		 * @since 9.73.0
		 *
		 * @param array $args Arguments for calculation.
		 * @return array
		 */
		public function calculate( $args = array() ) {
			try {
				$defaults = array(
					'start_date' => '',
					'end_date'   => '',
					'statuses'   => wc_get_is_paid_statuses(),
				);

				$args = wp_parse_args( $args, $defaults );

				/**
				 * Filters the arguments for revenue calculation.
				 *
				 * @since 9.73.0
				 *
				 * @param array $args    The calculation arguments.
				 * @param array $context The context.
				 */
				$args = apply_filters( 'wc_sc_revenue_calculate_args', $args, array( 'source' => $this ) );

				$orders = $this->query_orders( $args );

				if ( empty( $orders ) ) {
					$empty_metrics = $this->get_empty_metrics();

					/**
					 * Filters the calculated revenue metrics.
					 *
					 * @since 9.73.0
					 *
					 * @param array $metrics The calculated metrics.
					 * @param array $args    The calculation arguments.
					 * @param array $context The context.
					 */
					return apply_filters( 'wc_sc_revenue_calculated_metrics', $empty_metrics, $args, array( 'source' => $this ) );
				}

				$orders_count          = 0;
				$gross_revenue         = 0.0;
				$store_credit_used     = 0.0;
				$action_products_value = 0.0;

				foreach ( $orders as $order ) {
					if ( ! $order instanceof WC_Order ) {
						continue;
					}

					if ( ! $this->order_helper->is_smart_coupons_order( $order ) ) {
						continue;
					}

					++$orders_count;

					$gross_revenue += (float) $this->order_helper->get_gross_before_discounts( $order );

					$order_store_credit = (float) $this->order_helper->get_store_credit_used( $order );

					$store_credit_used += $order_store_credit;

					$action_products_value += (float) $this->order_helper->get_action_products_value( $order );
				}

				$metrics = array(
					'orders_count'          => number_format_i18n( (int) $orders_count ),
					'gross_revenue'         => wc_price( (float) $gross_revenue ),
					'store_credit_used'     => wc_price( (float) $store_credit_used ),
					'action_products_value' => wc_price( (float) $action_products_value ),
				);

				/**
				 * Filters the calculated revenue metrics.
				 *
				 * @since 9.73.0
				 *
				 * @param array $metrics The calculated metrics.
				 * @param array $args    The calculation arguments.
				 * @param array $context The context.
				 */
				return apply_filters( 'wc_sc_revenue_calculated_metrics', $metrics, $args, array( 'source' => $this ) );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );

				$empty_metrics = $this->get_empty_metrics();

				return apply_filters( 'wc_sc_revenue_calculated_metrics', $empty_metrics, array(), array( 'source' => $this ) );
			}
		}

		/**
		 * Query orders for calculation.
		 *
		 * @since 9.73.0
		 *
		 * @param array $args Query arguments.
		 * @return array
		 */
		protected function query_orders( $args ) {
			try {
				if ( ! function_exists( 'wc_get_orders' ) ) {
					return array();
				}

				$query_args = array(
					'status' => $args['statuses'],
					'limit'  => -1,
					'return' => 'objects',
				);

				if ( ! empty( $args['start_date'] ) || ! empty( $args['end_date'] ) ) {
					$date_query = array();

					if ( ! empty( $args['start_date'] ) ) {
						$date_query['after'] = $this->get_datetime_for_query( $args['start_date'], 'start' );
					}

					if ( ! empty( $args['end_date'] ) ) {
						$date_query['before'] = $this->get_datetime_for_query( $args['end_date'], 'end' );
					}

					if ( ! empty( $date_query ) ) {
						$query_args['date_created'] = $date_query;
					}
				}

				/**
				 * Filters the order query arguments for revenue insights.
				 *
				 * @since 9.73.0
				 *
				 * @param array $query_args The query arguments.
				 * @param array $args       The calculation arguments.
				 * @param array $context    The context.
				 */
				$query_args = apply_filters( 'wc_sc_revenue_orders_query_args', $query_args, $args, array( 'source' => $this ) );

				$orders = wc_get_orders( $query_args );

				if ( ! is_array( $orders ) ) {
					return array();
				}

				return $orders;
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return array();
			}
		}

		/**
		 * Get datetime string for orders query.
		 *
		 * @since 9.73.0
		 *
		 * @param string $date      Date string.
		 * @param string $boundary  Boundary start or end.
		 * @return string
		 */
		protected function get_datetime_for_query( $date, $boundary ) {
			try {
				$timezone = new DateTimeZone( wc_timezone_string() );

				if ( 'start' === $boundary ) {
					$format = 'Y-m-d 00:00:00';
				} else {
					$format = 'Y-m-d 23:59:59';
				}

				$datetime = DateTime::createFromFormat( 'Y-m-d H:i:s', gmdate( $format, strtotime( $date ) ) );

				if ( ! $datetime ) {
					return '';
				}

				$datetime->setTimezone( $timezone );

				return $datetime->format( 'Y-m-d H:i:s' );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return '';
			}
		}
	}
}
WC_SC_Revenue_Insights::get_instance();
