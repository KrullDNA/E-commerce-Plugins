<?php
/**
 * Smart Coupons insights dashboard widget view.
 *
 * @package WooCommerce Smart Coupons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wc_sc_nonce       = isset( $metrics['nonce'] ) ? wp_unslash( $metrics['nonce'] ) : '';
$wc_sc_ajax_action = isset( $metrics['ajax_action'] ) ? sanitize_text_field( wp_unslash( $metrics['ajax_action'] ) ) : 'wc_sc_get_insights_metrics';
$wc_sc_config      = isset( $metrics['config'] ) ? $metrics['config'] : array();

?>
<style>
	#wc_sc_insights,
	#wc_sc_insights h3,
	#wc_sc_insights .wc-sc-dashboard-links,
	#wc_sc_insights .wc-sc-dashboard-links a:hover {
		background-color: #f0fff0;
	}
	#wc_sc_insights .inside { padding: 0; margin: 0; }
	.wc-sc-widget-container .wc-sc-widget-section { border-bottom: 1px solid #dcdcde; }
	.wc-sc-widget-container .wc-sc-widget-section h3 {
		padding: 0.8em 1em !important;
		margin: 0 !important;
		color: #666 !important;
		font-size: 11px;
		font-weight: 600;
		letter-spacing: 0.5px;
		border-bottom: 1px solid #f0f0f1;
		background: #fcfcfc;
	}
	.wc-sc-widget-container .wc-sc-stats-container {
		display: flex;
		flex-wrap: wrap;
		align-items: stretch;
	}
	.wc-sc-widget-container .wc-sc-stats-container .wc-sc-single-stats {
		flex: 1 1 33.33%;
		text-align: center;
		padding: 1.5em 0.5em;
		display: flex;
		flex-direction: column;
		box-sizing: border-box;
		border-left: 1px solid #f0f0f1;
	}
	/* Remove left border for the first item in each row (desktop: 3 columns) */
	.wc-sc-widget-container .wc-sc-widget-section.wc-sc-data-container .wc-sc-stats-container > .wc-sc-single-stats:nth-child(3n+1) { border-left: 0; }
	/* Add top border for items starting from the second row (desktop: 4th item onwards) */
	.wc-sc-widget-container .wc-sc-widget-section.wc-sc-data-container .wc-sc-stats-container > .wc-sc-single-stats:nth-child(n+4) { border-top: 1px solid #f0f0f1; }
	
	.wc-sc-widget-container .wc-sc-label { font-size: 12px; font-weight: 400; color: #666; }
	.wc-sc-widget-container .wc-sc-value { font-size: 20px; font-weight: 700; color: #1d2327; margin-bottom: 4px; }
	.wc-sc-widget-loader {
		min-height: 100px;
		padding: 0;
		display: flex;
		align-items: center;
		justify-content: center;
		color: #666;
	}
	.wc-sc-dashboard-link-section { padding: 0; background: #fcfcfc; }
	.wc-sc-dashboard-link-section p.wc-sc-dashboard-links { margin: 0; display: flex; }
	.wc-sc-dashboard-links a {
		flex: 1;
		text-align: center;
		padding: 10px;
		color: #2271b1;
		text-decoration: none;
		font-weight: 500;
		border-right: 1px solid #f0f0f1;
		display: flex;
		align-items: center;
		justify-content: center;
		gap: 5px;
	}
	.wc-sc-dashboard-links a .dashicons { font-size: 16px; width: 16px; height: 16px; }
	.wc-sc-dashboard-links a:hover { background: #f6f7f7; color: #135e96; }
	.wc-sc-dashboard-links a:last-child { border-right: 0; }

	@media (max-width: 782px) {
		/* Switch to 2 columns layout on mobile */
		.wc-sc-widget-container .wc-sc-stats-container .wc-sc-single-stats {
			flex: 0 0 50%;
			border-left: 1px solid #f0f0f1;
		}
		/* Restore left border for items that were first in desktop rows (e.g., 4th item) */
		.wc-sc-widget-container .wc-sc-widget-section.wc-sc-data-container .wc-sc-stats-container > .wc-sc-single-stats:nth-child(3n+1) { border-left: 1px solid #f0f0f1; }
		/* Remove left border for the first item in each mobile row (odd items) */
		.wc-sc-widget-container .wc-sc-widget-section.wc-sc-data-container .wc-sc-stats-container > .wc-sc-single-stats:nth-child(2n+1) { border-left: 0; }
		/* Add top border for items starting from the second row (mobile: 3rd item onwards) */
		.wc-sc-widget-container .wc-sc-widget-section.wc-sc-data-container .wc-sc-stats-container > .wc-sc-single-stats:nth-child(n+3) { border-top: 1px solid #f0f0f1; }
		
		/* Align bottom links to match the 2-column grid */
		.wc-sc-dashboard-links a {
			border-top: 1px solid #f0f0f1;
			flex: 0 0 50%;
			box-sizing: border-box;
		}
		.wc-sc-dashboard-links a:first-child { border-right: 1px solid #f0f0f1; }
	}
</style>
<div
	class="wc-sc-widget-container"
	data-url-dashboard="<?php echo esc_url( admin_url( 'admin.php?page=wc-smart-coupons' ) ); ?>"
	data-url-settings="
	<?php
	echo esc_url(
		add_query_arg(
			array(
				'page' => 'wc-settings',
				'tab'  => 'wc-smart-coupons',
			),
			admin_url( 'admin.php' )
		)
	);
	?>
	"
>
</div>
<?php
wp_register_script( 'wc-smart-coupons-insights-inline', '', array(), $this->get_smart_coupons_version(), true );
wp_enqueue_script( 'wc-smart-coupons-insights-inline' );

wp_localize_script(
	'wc-smart-coupons-insights-inline',
	'wcScInsightsData',
	array(
		'ajax_url' => admin_url( 'admin-ajax.php' ),
		'nonce'    => $wc_sc_nonce,
		'action'   => $wc_sc_ajax_action,
		'config'   => $wc_sc_config,
		'strings'  => array(
			'loading'              => esc_html_x( 'Loading Smart Coupons results…', 'dashboard widget', 'woocommerce-smart-coupons' ),
			'dashboard'            => esc_html_x( 'Dashboard', 'dashboard widget links', 'woocommerce-smart-coupons' ),
			'settings'             => esc_html_x( 'Settings', 'dashboard widget links', 'woocommerce-smart-coupons' ),
			'network_error'        => esc_html_x( 'Network response was not ok', 'dashboard widget error', 'woocommerce-smart-coupons' ),
			'invalid_response'     => esc_html_x( 'Invalid response structure', 'dashboard widget error', 'woocommerce-smart-coupons' ),
			'console_error_prefix' => esc_html_x( 'Smart Coupons Analytics Error:', 'dashboard widget error', 'woocommerce-smart-coupons' ),
		),
	)
);

$wc_sc_inline_js = <<<'JS'
( function() {
	/**
	 * Renders the initial UI skeleton based on config.
	 *
	 * @param {HTMLElement} container
	 * @param {Object}      config
	 * @param {Object}      strings
	 */
	const renderSkeleton = ( container, config, strings ) => {
		if ( container.getAttribute( 'data-initialized' ) ) return;

		let html = `<div class="wc-sc-widget-section wc-sc-data-container wc-sc-widget-loader">${strings.loading || ''}</div>`;

		if ( config && config.sections ) {
			const sortedSectionIds = Object.keys( config.sections ).sort( ( a, b ) => {
				const priorityA = config.sections[a].priority || 10;
				const priorityB = config.sections[b].priority || 10;
				return priorityA - priorityB;
			} );

			sortedSectionIds.forEach( sectionId => {
				const section = config.sections[ sectionId ];
				const metrics = section.metrics || {};
				
				const metricKeys = Object.keys( metrics );

				html += `
					<div class="wc-sc-widget-section wc-sc-data-container wc-sc-data" data-section="${sectionId}" style="display:none">
						${section.label ? `<h3>${section.label}</h3>` : ''}
						<div class="wc-sc-stats-container">
							${metricKeys.map( key => `
								<div class="wc-sc-single-stats" data-metric-key="${key}">
									<span class="wc-sc-value" data-metric="${key}"></span>
									<span class="wc-sc-label">${metrics[key].label || ''}</span>
								</div>
							` ).join( '' )}
						</div>
					</div>
				`;
			} );
		}

		html += `
			<div class="wc-sc-widget-section wc-sc-dashboard-link-section">
				<p class="wc-sc-dashboard-links">
					<a href="${container.getAttribute( 'data-url-dashboard' ) || '#'}" target="_blank" rel="noopener noreferrer">${strings.dashboard || ''}<span class="dashicons dashicons-external"></span></a>
					<a href="${container.getAttribute( 'data-url-settings' ) || '#'}" target="_blank" rel="noopener noreferrer">${strings.settings || ''}<span class="dashicons dashicons-external"></span></a>
				</p>
			</div>
		`;

		container.innerHTML = html;
		container.setAttribute( 'data-initialized', '1' );
	};

	/**
	 * Fetches metrics data from the server.
	 *
	 * @param {Object} data
	 * @param {Object} strings
	 * @return {Promise<Object>}
	 */
	const fetchMetrics = async ( data, strings ) => {
		const formData = new FormData();
		formData.append( 'action', data.action || 'wc_sc_get_insights_metrics' );
		formData.append( 'nonce', data.nonce || '' );

		const response = await fetch( data.ajax_url || window.ajaxurl, {
			method: 'POST',
			body: formData
		} );

		if ( ! response.ok ) throw new Error( strings.network_error || 'Network response was not ok' );

		const result = await response.json();
		if ( ! result.success || ! result.data?.sections ) {
			throw new Error( strings.invalid_response || 'Invalid response structure' );
		}

		return result.data.sections;
	};

	/**
	 * Updates the UI with fetched metrics.
	 *
	 * @param {HTMLElement} container
	 * @param {Object}      sections
	 */
	const updateUI = ( container, sections ) => {
		Object.keys( sections ).forEach( sectionId => {
			const sectionData = sections[ sectionId ];
			const metrics     = sectionData.metrics || {};
			let visibleMetrics = 0;

			Object.keys( metrics ).forEach( metricKey => {
				const metricData = metrics[ metricKey ];
				const el = container.querySelector( `[data-section="${sectionId}"] [data-metric="${metricKey}"]` );
				if ( el ) {
					const card = el.closest( '.wc-sc-single-stats' );
					if ( card ) {
						const value = metricData.value || '';
						const label = metricData.label || '';

						card.querySelector('.wc-sc-label').innerHTML = label;
						
						// Create a temporary div to strip HTML and extract text
						const tempDiv = document.createElement('div');
						tempDiv.innerHTML = value;
						const textContent = tempDiv.textContent || tempDiv.innerText || '';

						// Sanitize numeric content: remove currency symbols, commas, and whitespace
						const sanitizedValue = textContent.replace(/[^\d.-]/g, '').trim();

						const isZero = sanitizedValue === '' || parseFloat( sanitizedValue ) === 0;

						if ( isZero ) {
							card.remove(); // Remove the card entirely so the next item flows into its place
						} else {
							el.innerHTML = value || '0';
							card.classList.remove( 'wc-sc-empty-stats' );
							card.style.display = '';
							visibleMetrics++;
						}
					}
				}
			} );

			const sectionEl = container.querySelector( `[data-section="${sectionId}"]` );
			if ( sectionEl ) {
				sectionEl.style.display = visibleMetrics > 0 ? '' : 'none';
			}
		} );

		const loader = container.querySelector( '.wc-sc-widget-loader' );
		if ( loader ) loader.style.display = 'none';
	};

	/**
	 * Initializes the widget.
	 */
	const init = async () => {
		const container = document.querySelector( '.wc-sc-widget-container' );
		const data      = window?.wcScInsightsData;
		if ( ! container || ! data ) return;

		const strings = data.strings || {};
		const config  = data.config  || {};

		renderSkeleton( container, config, strings );

		try {
			const sections = await fetchMetrics( data, strings );
			updateUI( container, sections );
		} catch ( error ) {
			if ( window.console ) console.error( strings.console_error_prefix || 'Smart Coupons Analytics Error:', error );
			const loader = container.querySelector( '.wc-sc-widget-loader' );
			if ( loader ) loader.textContent = strings.loading || '';
		}
	};

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
JS;

wp_add_inline_script( 'wc-smart-coupons-insights-inline', $wc_sc_inline_js );
?>
