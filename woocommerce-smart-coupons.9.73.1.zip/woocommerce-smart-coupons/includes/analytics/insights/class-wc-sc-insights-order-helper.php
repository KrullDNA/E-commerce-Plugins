<?php
/**
 * Smart Coupons order helper
 *
 * Helper methods for detecting Smart Coupons orders and computing order-level metrics.
 *
 * @author      StoreApps
 * @since       9.73.0
 * @version     1.0.0
 * @package     WooCommerce Smart Coupons
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_Insights_Order_Helper' ) ) {

	/**
	 * Class WC_SC_Insights_Order_Helper
	 */
	class WC_SC_Insights_Order_Helper {

		/**
		 * Handle call to functions which is not available in this class.
		 *
		 * @param string $function_name Function name.
		 * @param array  $arguments     Arguments passed while calling $function_name.
		 * @return mixed
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Check whether an order is influenced by Smart Coupons.
		 *
		 * @param WC_Order $order Order object.
		 * @return bool
		 */
		public function is_smart_coupons_order( $order ) {
			try {
				if ( ! $order instanceof WC_Order ) {
					return false;
				}

				$is_smart_coupons_order = false;

				if ( $this->order_has_smart_coupon_discount_type( $order ) ) {
					$is_smart_coupons_order = true;
				}

				if ( $this->order_has_smart_coupons_contribution( $order ) ) {
					$is_smart_coupons_order = true;
				}

				if ( $this->order_has_action_products( $order ) ) {
					$is_smart_coupons_order = true;
				}

				/**
				 * Filters whether an order is influenced by Smart Coupons.
				 *
				 * @since 9.73.0
				 *
				 * @param bool     $is_smart_coupons_order Whether it's a Smart Coupons order.
				 * @param WC_Order $order                  The order object.
				 * @param array    $context                The context.
				 */
				return (bool) apply_filters( 'wc_sc_insights_is_smart_coupons_order', $is_smart_coupons_order, $order, array( 'source' => $this ) );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return false;
			}
		}

		/**
		 * Get order total before discounts using Smart Coupons helper.
		 *
		 * @param WC_Order $order Order object.
		 * @return float
		 */
		public function get_gross_before_discounts( $order ) {
			try {
				if ( ! $order instanceof WC_Order ) {
					return 0.0;
				}

				if ( ! is_callable( array( $this, 'get_original_order_total_before_discount' ) ) ) {
					return 0.0;
				}

				$gross_before_discounts = (float) $this->get_original_order_total_before_discount( $order );

				/**
				 * Filters the gross total before discounts for Smart Coupons insights.
				 *
				 * @since 9.73.0
				 *
				 * @param float    $gross_before_discounts The gross total.
				 * @param WC_Order $order                  The order object.
				 * @param array    $context                The context.
				 */
				return (float) apply_filters( 'wc_sc_insights_gross_before_discounts', $gross_before_discounts, $order, array( 'source' => $this ) );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return 0.0;
			}
		}

		/**
		 * Get net revenue for an order.
		 *
		 * @param WC_Order $order Order object.
		 * @return float
		 */
		public function get_net_revenue( $order ) {
			try {
				if ( ! $order instanceof WC_Order ) {
					return 0.0;
				}

				if ( ! is_callable( array( $order, 'get_total' ) ) ) {
					return 0.0;
				}

				$net_revenue = (float) $order->get_total();

				/**
				 * Filters the net revenue for Smart Coupons insights.
				 *
				 * @since 9.73.0
				 *
				 * @param float    $net_revenue The net revenue.
				 * @param WC_Order $order       The order object.
				 * @param array    $context     The context.
				 */
				return (float) apply_filters( 'wc_sc_insights_net_revenue', $net_revenue, $order, array( 'source' => $this ) );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return 0.0;
			}
		}

		/**
		 * Get total store credit used in an order.
		 *
		 * @param WC_Order $order Order object.
		 * @return float
		 */
		public function get_store_credit_used( $order ) {
			try {
				if ( ! $order instanceof WC_Order ) {
					return 0.0;
				}

				if ( ! is_callable( array( $order, 'get_meta' ) ) ) {
					return 0.0;
				}

				$contribution = $order->get_meta( 'smart_coupons_contribution', true );

				if ( empty( $contribution ) || ! is_array( $contribution ) ) {
					return 0.0;
				}

				$store_credit_used = (float) array_sum( array_map( 'floatval', $contribution ) );

				/**
				 * Filters the store credit used for Smart Coupons insights.
				 *
				 * @since 9.73.0
				 *
				 * @param float    $store_credit_used The store credit amount.
				 * @param WC_Order $order             The order object.
				 * @param array    $context           The context.
				 */
				return (float) apply_filters( 'wc_sc_insights_store_credit_used', $store_credit_used, $order, array( 'source' => $this ) );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return 0.0;
			}
		}

		/**
		 * Get total value of action products in an order.
		 *
		 * @param WC_Order $order Order object.
		 * @return float
		 */
		public function get_action_products_value( $order ) {
			try {
				if ( ! $order instanceof WC_Order ) {
					return 0.0;
				}

				$total = 0.0;

				$items = $order->get_items( 'line_item' );

				if ( empty( $items ) || ! is_array( $items ) ) {
					return 0.0;
				}

				foreach ( $items as $item ) {
					if ( ! $item instanceof WC_Order_Item_Product ) {
						continue;
					}

					if ( ! is_callable( array( $item, 'get_meta' ) ) ) {
						continue;
					}

					$source = $item->get_meta( '_wc_sc_product_source', true );

					if ( empty( $source ) ) {
						continue;
					}

					$subtotal     = (float) $item->get_subtotal();
					$subtotal_tax = (float) $item->get_subtotal_tax();

					$total += $subtotal + $subtotal_tax;
				}

				/**
				 * Filters the action products value for Smart Coupons insights.
				 *
				 * @since 9.73.0
				 *
				 * @param float    $total   The total value.
				 * @param WC_Order $order   The order object.
				 * @param array    $context The context.
				 */
				return (float) apply_filters( 'wc_sc_insights_action_products_value', $total, $order, array( 'source' => $this ) );
			} catch ( \Throwable $e ) {
				$this->sc_block_catch_error( $e );
				return 0.0;
			}
		}

		/**
		 * Check whether order has a Smart Coupon discount type.
		 *
		 * @param WC_Order $order Order object.
		 * @return bool
		 */
		private function order_has_smart_coupon_discount_type( $order ) {
			if ( ! $order instanceof WC_Order ) {
				return false;
			}

			$coupons = $order->get_items( 'coupon' );

			if ( empty( $coupons ) || ! is_array( $coupons ) ) {
				return false;
			}

			foreach ( $coupons as $item ) {
				if ( ! $item instanceof WC_Order_Item_Coupon ) {
					continue;
				}

				$code = $item->get_name();

				if ( ! is_string( $code ) || '' === $code ) {
					continue;
				}

				$coupon = new WC_Coupon( $code );

				if ( ! $coupon instanceof WC_Coupon ) {
					continue;
				}

				if ( ! is_callable( array( $coupon, 'get_discount_type' ) ) ) {
					continue;
				}

				$discount_type = $coupon->get_discount_type();

				if ( 'smart_coupon' === $discount_type ) {
					return true;
				}
			}

			return false;
		}

		/**
		 * Check whether order has Smart Coupons contribution meta.
		 *
		 * @param WC_Order $order Order object.
		 * @return bool
		 */
		private function order_has_smart_coupons_contribution( $order ) {
			if ( ! $order instanceof WC_Order ) {
				return false;
			}

			if ( ! is_callable( array( $order, 'get_meta' ) ) ) {
				return false;
			}

			$contribution = $order->get_meta( 'smart_coupons_contribution', true );

			return ! empty( $contribution ) && is_array( $contribution );
		}

		/**
		 * Check whether order has action products.
		 *
		 * @param WC_Order $order Order object.
		 * @return bool
		 */
		private function order_has_action_products( $order ) {
			if ( ! $order instanceof WC_Order ) {
				return false;
			}

			$items = $order->get_items( 'line_item' );

			if ( empty( $items ) || ! is_array( $items ) ) {
				return false;
			}

			foreach ( $items as $item ) {
				if ( ! $item instanceof WC_Order_Item_Product ) {
					continue;
				}

				if ( ! is_callable( array( $item, 'get_meta' ) ) ) {
					continue;
				}

				$source = $item->get_meta( '_wc_sc_product_source', true );

				if ( ! empty( $source ) ) {
					return true;
				}
			}

			return false;
		}
	}
}
