<?php
/**
 * Smart Coupons BOGO Preset Coupon
 *
 * @author      StoreApps
 * @version     1.1.0
 *
 * @package     woocommerce-smart-coupons/includes/
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WC_SC_Preset_BOGO_Coupon' ) ) {

	/**
	 * Handles registration and rendering of the BOGO coupon preset UI.
	 *
	 * This class keeps BOGO-specific logic and delegates markup rendering to
	 * template files so the preset framework can be extended safely.
	 */
	class WC_SC_Preset_BOGO_Coupon {

		/**
		 * Holds class instance.
		 *
		 * @var WC_SC_Preset_BOGO_Coupon|null
		 */
		private static $instance = null;

		/**
		 * Constructor.
		 *
		 * @return void
		 */
		private function __construct() {

			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
			add_action( 'admin_head', array( $this, 'add_coupon_button' ) );
		}

		/**
		 * Gets class instance.
		 *
		 * @return WC_SC_Preset_BOGO_Coupon
		 */
		public static function get_instance() {

			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Handles proxy calls for unavailable methods.
		 *
		 * @param string $function_name The function name.
		 * @param array  $arguments     Arguments passed while calling $function_name.
		 *
		 * @return mixed
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Enqueues scripts and styles on coupon admin screen.
		 *
		 * @return void
		 */
		public function enqueue_assets() {

			$screen = get_current_screen();

			if ( empty( $screen->id ) || ! in_array( $screen->id, array( 'shop_coupon', 'edit-shop_coupon', 'marketing_page_wc-smart-coupons' ), true ) ) {
				return;
			}

			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
			$this->enqueue_product_search_dependencies( $suffix );
			wp_enqueue_script( 'sc-preset-popup', plugins_url( 'assets/js/sc-preset-popup' . $suffix . '.js', WC_SC_PLUGIN_FILE ), array( 'jquery' ), $this->get_version(), true );

			$localized_data = array(
				'rest_nonce' => wp_create_nonce( 'wp_rest' ),
				'rest_url'   => esc_url_raw( rest_url() ),
				'i18n'       => array(
					'generate_in_progress' => esc_html__( 'Generating...', 'woocommerce-smart-coupons' ),
					'generate_button'      => esc_html__( 'Generate coupon', 'woocommerce-smart-coupons' ),
					'generating_coupon'    => esc_html__( 'Generating coupon...', 'woocommerce-smart-coupons' ),
					'coupon_created'       => esc_html__( 'Coupon Created:', 'woocommerce-smart-coupons' ),
					'coupon_failed'        => esc_html__( 'Coupon creation failed.', 'woocommerce-smart-coupons' ),
					'valid_coupon_amount'  => esc_html__( 'Please enter a valid coupon amount.', 'woocommerce-smart-coupons' ),
					'select_buy_product'   => esc_html__( 'Please select at least one buy product.', 'woocommerce-smart-coupons' ),
					'select_get_product'   => esc_html__( 'Please select at least one get product.', 'woocommerce-smart-coupons' ),
				),
			);

			wp_localize_script(
				'sc-preset-popup',
				'scPresetData',
				$localized_data
			);

			wp_localize_script(
				'sc-preset-popup',
				'scBogoData',
				$localized_data
			);

			wp_enqueue_style( 'sc-preset-popup-style', plugins_url( 'assets/css/sc-preset-popup' . $suffix . '.css', WC_SC_PLUGIN_FILE ), array(), $this->get_version() . '.' . time() );
		}

		/**
		 * Enqueues required dependencies for product search fields.
		 *
		 * @param string $suffix Asset suffix.
		 *
		 * @return void
		 */
		public function enqueue_product_search_dependencies( $suffix = '' ) {

			if ( ! function_exists( 'WC' ) || ! is_object( WC() ) ) {
				return;
			}

			if ( ! wp_script_is( 'woocommerce_admin', 'registered' ) ) {
				wp_register_script( 'woocommerce_admin', WC()->plugin_url() . '/assets/js/admin/woocommerce_admin' . $suffix . '.js', array( 'jquery', 'jquery-blockui', 'jquery-ui-sortable', 'jquery-ui-widget', 'jquery-ui-core', 'jquery-tiptip' ), WC()->version, false );
			}

			if ( ! wp_script_is( 'wc-sc-select2', 'registered' ) ) {
				if ( method_exists( $this, 'is_wc_gte_32' ) && true === $this->is_wc_gte_32() ) {
					wp_register_script( 'wc-sc-select2', WC()->plugin_url() . '/assets/js/selectWoo/selectWoo.full' . $suffix . '.js', array( 'jquery' ), WC()->version, false );
				} else {
					wp_register_script( 'wc-sc-select2', WC()->plugin_url() . '/assets/js/select2/select2.full' . $suffix . '.js', array( 'jquery' ), WC()->version, false );
				}
			}

			if ( ! wp_script_is( 'wc-enhanced-select', 'registered' ) ) {
				wp_register_script( 'wc-enhanced-select', WC()->plugin_url() . '/assets/js/admin/wc-enhanced-select' . $suffix . '.js', array( 'jquery', 'wc-sc-select2' ), WC()->version, false );
			}

			if ( ! wp_style_is( 'wc-sc-select2', 'registered' ) ) {
				$assets_path = str_replace( array( 'http:', 'https:' ), '', WC()->plugin_url() ) . '/assets/';
				wp_register_style( 'wc-sc-select2', $assets_path . 'css/select2.css', array(), WC()->version );
			}

			if ( ! wp_script_is( 'wc-sc-select2', 'enqueued' ) ) {
				wp_enqueue_script( 'wc-sc-select2' );
			}

			if ( ! wp_script_is( 'wc-enhanced-select', 'enqueued' ) ) {
				wp_enqueue_script( 'wc-enhanced-select' );
			}

			if ( ! wp_style_is( 'wc-sc-select2', 'enqueued' ) ) {
				wp_enqueue_style( 'wc-sc-select2' );
			}
		}

		/**
		 * Renders BOGO trigger button, shared modal shell and BOGO template.
		 *
		 * @return void
		 */
		public function add_coupon_button() {

			$screen = get_current_screen();

			if ( ! in_array( $screen->id, array( 'edit-shop_coupon', 'marketing_page_wc-smart-coupons' ), true ) ) {
				return;
			}

			$presets = $this->get_available_presets();

			if ( empty( $presets ) || ! is_array( $presets ) ) {
				return;
			}

			?>

			<script type="text/javascript">
				document.addEventListener('DOMContentLoaded', function () {
					setTimeout(function () {
						var dropdownLabel = '<?php echo esc_js( esc_html__( 'Smart Coupons Quick Preset', 'woocommerce-smart-coupons' ) ); ?>';
						var presets = <?php echo wp_json_encode( $presets ); ?>;
						var tourBtn = document.querySelector('.wrap a.button[href*="page=sc-tour"]');
						var addNewBtn = document.querySelector('.wrap .page-title-action');

						if (tourBtn) {
							var dropdownAfterTour = createPresetDropdown(dropdownLabel, presets);
							tourBtn.parentNode.insertBefore(dropdownAfterTour, tourBtn.nextSibling);
							return;
						}

						if (addNewBtn) {
							var dropdown = createPresetDropdown(dropdownLabel, presets);
							addNewBtn.parentNode.insertBefore(dropdown, addNewBtn.nextSibling);
							return;
						}

						var legacyTourBtn = document.querySelector('h2 a.button[href*="page=sc-tour"]');
						var legacyBtn = document.querySelector('h2 .add-new-h2');

						if (legacyTourBtn) {
							var dropdownLegacyAfterTour = createPresetDropdown(dropdownLabel, presets);
							legacyTourBtn.parentNode.insertBefore(dropdownLegacyAfterTour, legacyTourBtn.nextSibling);
							return;
						}

						if (legacyBtn) {
							var dropdownLegacy = createPresetDropdown(dropdownLabel, presets);
							legacyBtn.parentNode.insertBefore(dropdownLegacy, legacyBtn.nextSibling);
						}
					}, 0);

					function createPresetDropdown(label, presetsData) {
						var wrapper = document.createElement('div');
						wrapper.title = 'Presets let you quickly create common coupon offers without configuring every setting manually';
						wrapper.className = 'sc-preset-dropdown';
						wrapper.style.margin = '-.3em 1em';
						wrapper.style.verticalAlign = 'text-bottom';

						var toggle = document.createElement('button');
						toggle.type = 'button';
						toggle.className = 'button';
						toggle.id = 'scPresetToggle';
						toggle.textContent = label;
						toggle.style.background = '#f0fff0';
						toggle.style.borderColor = '#bfbfbf';
						toggle.setAttribute('aria-haspopup', 'true');
						toggle.setAttribute('aria-expanded', 'false');

						var menu = document.createElement('div');
						menu.className = 'sc-preset-menu';
						menu.style.display = 'none';

						Object.keys(presetsData).forEach(function (presetKey) {
							if (!presetsData[presetKey] || !presetsData[presetKey].label) {
								return;
							}

							var item = document.createElement('button');
							item.type = 'button';
							item.className = 'sc-preset-item';
							item.textContent = String(presetsData[presetKey].label);
							item.setAttribute('data-sc-open-preset', '1');
							item.setAttribute('data-sc-preset', String(presetKey));

							item.addEventListener('click', function (event) {
								event.preventDefault();
								event.stopPropagation();

								menu.style.display = 'none';
								toggle.setAttribute('aria-expanded', 'false');

								if ('function' === typeof window.scOpenPresetModal) {
									window.scOpenPresetModal(String(presetKey));
									return;
								}

								var fallbackTrigger = document.createElement('button');
								fallbackTrigger.type = 'button';
								fallbackTrigger.style.display = 'none';
								fallbackTrigger.setAttribute('data-sc-open-preset', '1');
								fallbackTrigger.setAttribute('data-sc-preset', String(presetKey));
								document.body.appendChild(fallbackTrigger);
								fallbackTrigger.click();
								fallbackTrigger.remove();
							});

							menu.appendChild(item);
						});

						toggle.addEventListener('click', function () {
							var isOpen = menu.style.display === 'block';
							menu.style.display = isOpen ? 'none' : 'block';
							toggle.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
						});

						document.addEventListener('click', function (event) {
							if (!wrapper.contains(event.target)) {
								menu.style.display = 'none';
								toggle.setAttribute('aria-expanded', 'false');
							}
						});

						wrapper.appendChild(toggle);
						wrapper.appendChild(menu);

						return wrapper;
					}
				});
			</script>

			<div id="scBogoModal" class="sc-modal" data-sc-modal="coupon-preset">
				<div class="sc-modal-content">

					<span class="sc-close">&times;</span>
					<div id="scPresetModalBody"></div>

					<div class="sc-wizard-actions">
						<button type="button" class="button" id="scStepPrev"><?php esc_html_e( 'Previous', 'woocommerce-smart-coupons' ); ?></button>
						<button type="button" class="button button-primary" id="scStepNext"><?php esc_html_e( 'Next', 'woocommerce-smart-coupons' ); ?></button>
						<button type="button" class="button button-primary" id="scGenerateBogo"><?php esc_html_e( 'Generate coupon', 'woocommerce-smart-coupons' ); ?></button>
					</div>

					<div id="scBogoResult" class="sc-bogo-result" data-sc-result="coupon-preset"></div>

				</div>
			</div>

			<div id="scPresetTemplates" style="display:none;">
				<?php foreach ( $presets as $preset_key => $preset_data ) { ?>
					<?php
					$template_name = isset( $preset_data['template'] ) ? $preset_data['template'] : '';
					$template_args = isset( $preset_data['args'] ) && is_array( $preset_data['args'] ) ? $preset_data['args'] : array();
					?>
					<div data-sc-preset-template="<?php echo esc_attr( $preset_key ); ?>">
						<?php $this->get_template( $template_name, $template_args ); ?>
					</div>
				<?php } ?>
			</div>


			<?php
		}

		/**
		 * Gets available preset definitions.
		 *
		 * @return array<string,array<string,mixed>>
		 */
		public function get_available_presets() {

			$presets = array(
				'bogo' => array(
					'label'    => esc_html__( 'Create BOGO Coupon', 'woocommerce-smart-coupons' ),
					'template' => $this->get_template_name(),
					'args'     => $this->get_template_args(),
				),
			);

			$presets = apply_filters( 'wc_sc_coupon_presets', $presets, $this );

			if ( empty( $presets ) || ! is_array( $presets ) ) {
				return array();
			}

			foreach ( $presets as $preset_key => $preset_data ) {
				if ( ! is_string( $preset_key ) || empty( $preset_key ) || ! is_array( $preset_data ) ) {
					unset( $presets[ $preset_key ] );
					continue;
				}

				if ( empty( $preset_data['label'] ) || empty( $preset_data['template'] ) ) {
					unset( $presets[ $preset_key ] );
					continue;
				}

				$presets[ $preset_key ]['label'] = wp_strip_all_tags( (string) $preset_data['label'] );
			}

			return $presets;
		}

		/**
		 * Gets preset key.
		 *
		 * @return string
		 */
		public function get_preset_key() {
			return 'bogo';
		}

		/**
		 * Gets BOGO template name.
		 *
		 * @return string
		 */
		public function get_template_name() {
			return 'admin/presets/bogo.php';
		}

		/**
		 * Gets BOGO template args.
		 *
		 * @return array<string,mixed>
		 */
		public function get_template_args() {

			$is_allow_auto_apply = $this->sc_get_option( 'wc_sc_allow_auto_apply', 'yes' );

			return array(
				'coupon_discount_types' => $this->get_coupon_discount_types(),
				'is_wc_gte_30'          => $this->is_wc_gte_30(),
				'is_allow_auto_apply'   => ( 'yes' === $is_allow_auto_apply ),
			);
		}

		/**
		 * Gets available coupon discount types.
		 *
		 * @return array<string,string>
		 */
		public function get_coupon_discount_types() {

			$coupon_discount_types = function_exists( 'wc_get_coupon_types' ) ? wc_get_coupon_types() : array();

			if ( empty( $coupon_discount_types ) || ! is_array( $coupon_discount_types ) ) {
				$coupon_discount_types = array(
					'percent'       => __( 'Percentage discount', 'woocommerce' ),
					'fixed_cart'    => __( 'Fixed cart discount', 'woocommerce' ),
					'fixed_product' => __( 'Fixed product discount', 'woocommerce' ),
				);
			}

			return $coupon_discount_types;
		}

		/**
		 * Loads preset template file.
		 *
		 * @param string $template_name Template path relative to plugin templates directory.
		 * @param array  $args          Template data.
		 *
		 * @return void
		 */
		public function get_template( $template_name = '', $args = array() ) {

			if ( empty( $template_name ) || ! is_string( $template_name ) ) {
				return;
			}

			global $wp_filesystem;

			if ( ! function_exists( 'WP_Filesystem' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
			}
			WP_Filesystem();

			$template_path = trailingslashit( WC_SC_PLUGIN_DIRPATH . 'templates' ) . ltrim( $template_name, '/' );

			$real_full_path = realpath( $template_path );
			if ( $real_full_path && strpos( wp_normalize_path( $real_full_path ), wp_normalize_path( realpath( WP_PLUGIN_DIR ) ) ) === 0 && is_readable( $real_full_path ) ) {
				if ( $wp_filesystem->exists( $real_full_path ) && $wp_filesystem->is_readable( $real_full_path ) ) {
					if ( ! empty( $args ) && is_array( $args ) ) {
						extract( $args, EXTR_SKIP ); // phpcs:ignore
					}

					include $real_full_path; // nosemgrep: audit.php.lang.security.file.inclusion-arg .
				}
			}
		}
	}
}

// Initialize class.
WC_SC_Preset_BOGO_Coupon::get_instance();
