<?php
/**
 * Compatibility file for WPML
 *
 * @author      StoreApps
 * @since       3.3.0
 * @version     1.2.0
 *
 * @package     woocommerce-smart-coupons/includes/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_WPML_Compatibility' ) ) {

	/**
	 * Class for handling compatibility with WPML
	 */
	class WC_SC_WPML_Compatibility {

		/**
		 * Variable to hold instance of WC_SC_WPML_Compatibility
		 *
		 * @var $instance
		 */
		private static $instance = null;

		/**
		 * Constructor
		 */
		public function __construct() {

			add_action( 'init', array( $this, 'woocommerce_wpml_compatibility' ), 11 );
			add_action( 'wpml_language_has_switched', array( $this, 'sc_gift_discount_on_lang_switch' ), 10 );
		}

		/**
		 * Get single instance of WC_SC_WPML_Compatibility
		 *
		 * @return WC_SC_WPML_Compatibility Singleton object of WC_SC_WPML_Compatibility
		 */
		public static function get_instance() {
			// Check if instance is already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Function to handle compatibility with WooCommerce Multilingual
		 */
		public function woocommerce_wpml_compatibility() {
			global $woocommerce_wpml;
			if ( class_exists( 'woocommerce_wpml' ) && $woocommerce_wpml instanceof woocommerce_wpml ) {
				if ( ! empty( $woocommerce_wpml->products ) && has_action( 'woocommerce_before_checkout_process', array( $woocommerce_wpml->products, 'wcml_refresh_cart_total' ) ) ) {
					remove_action( 'woocommerce_before_checkout_process', array( $woocommerce_wpml->products, 'wcml_refresh_cart_total' ) );
				}
				if ( ! empty( $woocommerce_wpml->cart ) && has_action( 'woocommerce_before_checkout_process', array( $woocommerce_wpml->cart, 'wcml_refresh_cart_total' ) ) ) {
					remove_action( 'woocommerce_before_checkout_process', array( $woocommerce_wpml->cart, 'wcml_refresh_cart_total' ) );
				}
			}
		}

		/**
		 * Prevents product discount removal when the site language is switched.
		 *
		 * In a WPML-enabled setup, switching languages can trigger cart or product
		 * re-evaluation, which may unintentionally remove applied discounts.
		 * This function ensures that existing product discounts remain intact
		 * during a language switch.
		 *
		 * @return void
		 */
		public function sc_gift_discount_on_lang_switch() {
			if ( is_admin() || ! function_exists( 'WC' ) || ! WC()->cart ) {
				return;
			}
			if ( ! class_exists( 'WC_SC_Coupon_Actions' ) ) {
				include_once WC_SC_PLUGIN_DIRPATH . 'includes/class-wc-sc-coupon-actions.php';
			}
			$wc_sc_coupon_actions = WC_SC_Coupon_Actions::get_instance();
			foreach ( WC()->cart->get_cart() as $key => $item ) {
				if ( empty( $item['wc_sc_product_source'] ) ) {
					continue;
				}

				$pid = isset( $item['product_id'] ) ? (int) $item['product_id'] : 0;
				$vid = isset( $item['variation_id'] ) ? (int) $item['variation_id'] : 0;
				$qty = isset( $item['quantity'] ) ? (int) $item['quantity'] : 1;

				WC()->cart->cart_contents[ $key ] = $wc_sc_coupon_actions->modify_cart_item_data( $item, $pid, $vid, $qty );
			}

			WC()->cart->calculate_totals();
		}
	}

}

WC_SC_WPML_Compatibility::get_instance();
