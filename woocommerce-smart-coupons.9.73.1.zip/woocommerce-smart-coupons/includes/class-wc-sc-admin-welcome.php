<?php
/**
 * A Welcome page for store admin
 *
 * @author      StoreApps
 * @since       3.3.0
 * @version     1.9.0
 *
 * @package     woocommerce-smart-coupons/includes/
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! class_exists( 'WC_SC_Admin_Welcome' ) ) {

	/**
	 * WC_SC_Admin_Welcome class
	 */
	class WC_SC_Admin_Welcome {

		/**
		 * Variable to hold instance of WC_SC_Admin_Welcome
		 *
		 * @var $instance
		 */
		private static $instance = null;

		/**
		 * Hook in tabs.
		 */
		private function __construct() {
			add_action( 'admin_menu', array( $this, 'admin_menus' ) );
			add_action( 'admin_head', array( $this, 'admin_head' ) );
			add_action( 'admin_init', array( $this, 'sc_welcome' ) );

			add_action( 'admin_enqueue_scripts', array( $this, 'register' ) );
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		}

		/**
		 * Get single instance of WC_SC_Admin_Welcome
		 *
		 * @return WC_SC_Admin_Welcome Singleton object of WC_SC_Admin_Welcome
		 */
		public static function get_instance() {
			// Check if instance is already exists.
			if ( is_null( self::$instance ) ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Handle call to functions which is not available in this class
		 *
		 * @param string $function_name The function name.
		 * @param array  $arguments Array of arguments passed while calling $function_name.
		 * @return result of function call
		 */
		public function __call( $function_name, $arguments = array() ) {

			global $woocommerce_smart_coupon;

			if ( ! is_callable( array( $woocommerce_smart_coupon, $function_name ) ) ) {
				return;
			}

			if ( ! empty( $arguments ) ) {
				return call_user_func_array( array( $woocommerce_smart_coupon, $function_name ), $arguments );
			} else {
				return call_user_func( array( $woocommerce_smart_coupon, $function_name ) );
			}
		}

		/**
		 * Add admin menus/screens.
		 */
		public function admin_menus() {

			$get_page = ( ! empty( $_GET['page'] ) ) ? wc_clean( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore

			if ( empty( $get_page ) ) {
				return;
			}

			$welcome_page_name  = __( 'About Smart Coupons', 'woocommerce-smart-coupons' );
			$welcome_page_title = __( 'Welcome to Smart Coupons', 'woocommerce-smart-coupons' );

			$parent_slug = ( $this->is_wc_gte_44() ) ? 'woocommerce-marketing' : 'woocommerce';

			switch ( $get_page ) {
				case 'sc-onboarding':
					add_submenu_page( $parent_slug, $welcome_page_title, $welcome_page_name, 'manage_options', 'sc-onboarding', array( $this, 'onboarding_screen' ) );
					break;
				case 'sc-about':
					add_submenu_page( $parent_slug, $welcome_page_title, $welcome_page_name, 'manage_options', 'sc-about', array( $this, 'about_screen' ) );
					break;
				case 'sc-tour':
					add_submenu_page( $parent_slug, $welcome_page_title, $welcome_page_name, 'manage_options', 'sc-tour', array( $this, 'tour_screen' ) );
					break;
			}
		}

		/**
		 * Add styles just for this page, and remove dashboard page links.
		 */
		public function admin_head() {
			$parent_slug = ( $this->is_wc_gte_44() ) ? 'woocommerce-marketing' : 'woocommerce';

			remove_submenu_page( $parent_slug, 'sc-onboarding' );
			remove_submenu_page( $parent_slug, 'sc-about' );
			remove_submenu_page( $parent_slug, 'sc-tour' );

			$get_page = ( ! empty( $_GET['page'] ) ) ? wc_clean( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore

			if ( ! empty( $get_page ) && ( 'sc-tour' === $get_page || 'sc-about' === $get_page ) ) {
				?>
			<style type="text/css">
				/*<![CDATA[*/
				h1.wc-sc-about,
				p.wc-sc-about.about-text {
					text-align: center;
					margin: 0;
					padding: 0;
				}
				.dashicons.dashicons-tickets-alt.wc-sc-left,
				.dashicons.dashicons-tickets-alt.wc-sc-right {
					font-size: 1em;
					width: 2em;
					height: 1em;
				}
				.dashicons.dashicons-tickets-alt.wc-sc-right {
					transform: scaleX(-1);
				}
				.about-wrap h3 {
					margin-top: 1em;
					margin-right: 0em;
					margin-bottom: 0.1em;
				}
				.about-wrap .button-primary {
					margin-top: 18px;
				}
				.about-wrap .button-hero {
					color: #FFF!important;
					border-color: #03a025!important;
					background: #03a025 !important;
					box-shadow: 0 1px 0 #03a025;
					font-size: 1em;
					font-weight: bold;
				}
				.about-wrap .button-hero:hover {
					color: #FFF!important;
					background: #0AAB2E!important;
					border-color: #0AAB2E!important;
				}
				.about-wrap p {
					margin-top: 0.6em;
					margin-bottom: 0.8em;
				}
				.about-wrap .feature-section {
					padding-bottom: 5px;
				}
				.about-wrap .aligncenter {
					text-align: center;
				}
				.about-wrap,
				.about-wrap .has-2-columns,
				.about-wrap .has-3-columns {
					max-width: unset !important;
				}
				ul.sc-top-features {
					list-style-type: disc !important;
					padding-left: 1.5em !important;
				}
				<?php if ( 'sc-tour' === $get_page ) { ?>
					.wc-sc-grid-container {
						display: grid;
						gap: 4em 1em;
						padding: 1em;
						border-radius: 8px;
						justify-content: center;
						margin-top: 1em;
					}
					@media (min-width: 719px) {
						.wc-sc-grid-container {
							grid-template-columns: repeat(auto-fill, minmax(50%, 1fr));
						}
					}
					@media screen and (min-width: 720px) and (max-width: 1199px) {
						.wc-sc-grid-container {
							grid-template-columns: repeat(auto-fill, minmax(49%, 1fr));
						}
					}
					@media screen and (min-width: 1200px) and (max-width: 1279px) {
						.wc-sc-grid-container {
							grid-template-columns: repeat(auto-fill, minmax(33%, 1fr));
						}
					}
					@media screen and (min-width: 1200px) and (max-width: 1499px) {
						.wc-sc-grid-container {
							grid-template-columns: repeat(auto-fill, minmax(25%, 1fr));
						}
					}
					@media screen and (min-width: 1500px) and (max-width: 1819px) {
						.wc-sc-grid-container {
							grid-template-columns: repeat(auto-fill, minmax(20%, 1fr));
						}
					}
					@media screen and (min-width: 1820px) {
						.wc-sc-grid-container {
							grid-template-columns: repeat(auto-fill, minmax(18%, 1fr));
						}
					}
					.wc-sc-grid-item {
						border: 1px solid #e1e1e1;
						border-radius: 8px;
						padding: 1.2em;
						box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
						transition: transform 0.3s ease, box-shadow 0.3s ease;
						max-width: 20%;
						min-width: 18em;
						flex: 1 1 auto;
						position: relative;
						height: 100%;
					}
					.wc-sc-grid-item .dashicons {
						font-size: 1.5em;
						color: var(--wp-admin-theme-color);
						position: absolute;
						top: -.05em;
						right: 0.65em;
						font-size: 10em;
						opacity: 0.1;
					}
					.wc-sc-grid-item:nth-child(3n+1) {
						background-color: #fff; /* #e0f7fa; */ /* Light cyan */
					}
					.wc-sc-grid-item:nth-child(3n+2) {
						background-color: #fff; /* #f1f8e9; */ /* Light green */
					}
					.wc-sc-grid-item:nth-child(3n) {
						background-color: #fff; /* #fff3e0; */ /* Light orange */
					}
					.wc-sc-grid-item:hover {
						transform: translateY(-5px);
						box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
					}
					.icon-title-wrapper {
						display: flex;
						align-items: center;
						justify-content: center;
						margin-bottom: 1.5em;
					}
					.icon-title-wrapper h3 {
						font-size: 1.5em;
						margin: 0;
						text-align: center;
					}
					.wc-sc-grid-item p {
						font-size: 14px;
						margin-bottom: 20px;
					}
					.wc-sc-grid-item .button-primary {
						text-decoration: none;
						font-size: 1em;
						padding: .2em 1em;
						border-radius: .4em;
						display: inline-block;
						width: 90%;
					}
					button.start-tour {
						position: absolute;
						bottom: 1em;
						left: 50%;
						transform: translateX(-50%);
					}
				<?php } ?>
				/*]]>*/
			</style>
				<?php
			}
		}

		/**
		 * Intro text/links shown on all about pages.
		 */
		private function intro() {

			?>
			<h1 class="wc-sc-about"><span class="dashicons dashicons-tickets-alt wc-sc-left"></span><?php echo esc_html__( 'WooCommerce Smart Coupons', 'woocommerce-smart-coupons' ); ?><span class="dashicons dashicons-tickets-alt wc-sc-right"></span></h1>

			<p class="about-text wc-sc-about"><?php echo esc_html__( 'Dive into the features and use them to move your goals forward.', 'woocommerce-smart-coupons' ); ?></p>

			<div class="has-2-columns feature-section col two-col" style="margin-bottom: 30px !important;">
				<div class="is-vertically-aligned-center column col">
					<?php /* translators: HTML entity for Right-arrow */ ?>
					<a href="<?php echo esc_url( add_query_arg( array( 'post_type' => 'shop_coupon' ), admin_url( 'edit.php' ) ) ); ?>" class="button button-hero"><?php printf( esc_html__( 'Go to Coupons dashboard %s', 'woocommerce-smart-coupons' ), '&xrarr;' ); ?></a>
				</div>

				<div class="is-vertically-aligned-center column col last-feature">
					<p class="alignright">
						<?php
							$settings_tab_url = add_query_arg(
								array(
									'page' => 'wc-settings',
									'tab'  => 'wc-smart-coupons',
								),
								admin_url( 'admin.php' )
							);
						?>
						<a href="<?php echo esc_url( $settings_tab_url ); ?>" class="button button-primary" target="_blank"><?php echo esc_html__( 'Settings', 'woocommerce-smart-coupons' ); ?></a>
						<a href="<?php echo esc_url( apply_filters( 'smart_coupons_docs_url', 'https://woocommerce.com/document/smart-coupons/', 'woocommerce-smart-coupons' ) ); ?>" class="docs button button-primary" target="_blank"><?php echo esc_html__( 'Docs', 'woocommerce-smart-coupons' ); ?></a>
					</p>
				</div>
			</div>

			<h2 class="nav-tab-wrapper">
				<a class="nav-tab 
				<?php

				$get_page = ( ! empty( $_GET['page'] ) ) ? wc_clean( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore

				if ( 'sc-about' === $get_page ) {
					echo 'nav-tab-active';
				}
				?>
				" href="<?php echo esc_url( admin_url( add_query_arg( array( 'page' => 'sc-about' ), 'admin.php' ) ) ); ?>">
					<?php echo esc_html__( 'Features & Use Cases', 'woocommerce-smart-coupons' ); ?>
				</a>
				<?php if ( class_exists( 'WC_SC_Tours' ) ) { ?>
				<a class="nav-tab 
					<?php
					if ( 'sc-tour' === $get_page ) {
						echo 'nav-tab-active';
					}
					?>
				" href="<?php echo esc_url( admin_url( add_query_arg( array( 'page' => 'sc-tour' ), 'admin.php' ) ) ); ?>">
					<?php echo esc_html__( 'Guided Tour', 'woocommerce-smart-coupons' ); ?>
				</a>
				<?php } ?>
			</h2>
			<?php
		}

		/**
		 * Output the about screen.
		 */
		public function about_screen() {
			if ( ! wp_script_is( 'jquery' ) ) {
				wp_enqueue_script( 'jquery' );
			}
			$this->enqueue();
			?>

			<script type="text/javascript">
				jQuery(function(){
					jQuery('#toplevel_page_woocommerce').find('a[href$=shop_coupon]').addClass('current');
					jQuery('#toplevel_page_woocommerce').find('a[href$=shop_coupon]').parent().addClass('current');
				});
			</script>

			<style type="text/css">
				.wc-sc-tab-content-description {
					text-align: center;
					padding: 1em 2em;
					width: 50%;
					margin: 0 auto;
				}

				.wc-sc-doc-wrapper {
					column-count: 3;
					column-gap: 20px;
				}

				.wc-sc-doc-wrapper .wc-sc-doc-group {
					background: white;
					padding: 20px;
					margin-bottom: 20px;
					border-radius: 8px;
					box-shadow: 0 4px 8px rgba(0,0,0,0.05);
					break-inside: avoid;
				}

				.wc-sc-doc-wrapper h3 {
					margin-top: 0;
				}
			</style>

			<div class="wrap about-wrap">

			<?php $this->intro(); ?>

			<p class="wc-sc-tab-content-description">
				<?php echo esc_html__( 'Discover what the plugin can do and turn its features into real results. Explore, experiment, and elevate your results with the right strategy for your website.', 'woocommerce-smart-coupons' ); ?>
			</p>

			<?php
			$docs = array(
				array(
					'parent-title' => esc_html_x( 'Settings and configurations', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
					'child'        => array(
						'https://woocommerce.com/document/smart-coupons/how-to-categorize-coupons/'                                             => esc_html_x( 'How to categorize coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-change-coupon-page-url-in-my-account/'                           => esc_html_x( 'How to change coupon page URL/endpoint in My Account', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-change-the-coupon-expiry-date-format-displayed-on-the-website/'  => esc_html_x( 'How to change the coupon expiry date format displayed on the website', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-change-replace-and-override-email-template/'                     => esc_html_x( 'How to change, replace and override email template', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-change-edit-the-subject-line-of-an-auto-generated-coupon-email/' => esc_html_x( 'How to change/edit the subject line of an auto-generated coupon email', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-choose-order-statuses-for-coupon-auto-generation/'               => esc_html_x( 'How to Choose Order Status for Auto-generating Coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-clear-smart-coupons-cache-in-woocommerce/'                       => esc_html_x( 'How to clear Smart Coupons cache in WooCommerce', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-configure-smart-coupons/'                                        => esc_html_x( 'How to configure Smart Coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-customize-coupon-style-smart-coupons/'                           => esc_html_x( 'How to customize coupon styles in Smart Coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-enable-and-customize-coupon-banners/'                            => esc_html_x( 'How to enable and customize coupon banners', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-rename-store-credit/'                                            => esc_html_x( 'How to rename Store Credit', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-schedule-delivery-of-coupon/'                                    => esc_html_x( 'How to schedule coupon / store credit delivery', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-set-expiry-time-with-the-expiry-date/'                           => esc_html_x( 'How to Set a Coupon Expiry Date and Time', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-set-coupon-code-length-for-auto-generated-coupons/'              => esc_html_x( 'How to set coupon code length for auto-generated coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-set-up-a-reminder-email-for-expiring-coupons/'                   => esc_html_x( 'How to set up a reminder email for expiring coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-setup-reminder-email-for-unused-coupons/'                        => esc_html_x( 'How to setup reminder emails for unused coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-show-an-image-on-the-email-template/'                            => esc_html_x( 'How to show an image on the email template', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-translate-smart-coupons/'                                        => esc_html_x( 'How to translate Smart Coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/smart-coupons-compatibility-with-paypal-standard/'                      => esc_html_x( 'Smart Coupons compatibility with PayPal Standard for gift cards', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/using-apply-before-tax/'                                                => esc_html_x( 'Using ‘Apply Before Tax’', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/using-multiple-currencies-for-purchasing-gift-cards/'                   => esc_html_x( 'Using multiple currencies for purchasing gift cards', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
					),
				),
				array(
					'parent-title' => esc_html_x( 'General and reference', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
					'child'        => array(
						'https://woocommerce.com/document/smart-coupons/'                        => esc_html_x( 'Smart Coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/code-snippets/'          => esc_html_x( 'Code Snippets', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/smart-coupons-faqs/'     => esc_html_x( 'Smart Coupons FAQs', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/smart-coupons-rest-api/' => esc_html_x( 'Smart Coupons REST API', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/tiered-discounts/'       => esc_html_x( 'Tiered Discounts', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
					),
				),
				array(
					'parent-title' => esc_html_x( 'Use cases', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
					'child'        => array(
						'https://woocommerce.com/document/smart-coupons/use-case-apply-different-discounts-for-category-and-non-category-products-using-auto-apply-coupons/' => esc_html_x( 'Use Case: Apply Different Discounts for Category and Non-Category products using Auto-Apply coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/use-case-automatically-apply-a-coupon-when-a-customer-has-made-more-than-x-orders/'                  => esc_html_x( 'Use Case: Automatically apply a coupon when a customer has made more than X orders', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/use-case-automatically-apply-a-coupon-when-a-specific-product-is-added-to-the-cart/'                 => esc_html_x( 'Use Case: Automatically apply a coupon when a specific product is added to the cart', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/use-case-buy-4-or-more-products-and-get-30-off-on-the-cheapest-one/'                                 => esc_html_x( 'Use Case: Buy 4 or More products and get 30% Off on the cheapest one', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/use-case-how-to-issue-store-credit-for-a-refund-using-smart-refunder-plugin/'                        => esc_html_x( 'Use Case: How to issue Store Credit for a refund using Smart Refunder plugin', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/use-case-letting-customers-pick-a-free-gift-with-smart-coupons-during-the-holiday-season/'           => esc_html_x( 'Use Case: Letting customers pick a free gift with Smart Coupons during the holiday season', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/use-case-offering-a-free-product-on-the-next-order-when-a-user-spends-a-minimum-amount/'             => esc_html_x( 'Use Case: Offering a free product on the next order when a user spends a minimum amount', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/use-case-tracking-coupon-conversions-from-ads-or-newsletters/'                                       => esc_html_x( 'Use Case: Tracking coupon conversions from Ads or Newsletters', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
					),
				),
				array(
					'parent-title' => esc_html_x( 'Restrictions', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
					'child'        => array(
						'https://woocommerce.com/document/smart-coupons/different-ways-to-restrict-gift-cards/'                     => esc_html_x( 'Different ways to restrict gift cards', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-block-emails-domains-from-applying-the-coupon/'      => esc_html_x( 'How to block emails or domains from applying the coupon', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-set-a-max-discount-for-percentage-discount-coupon/'  => esc_html_x( 'How to limit a percentage discount coupon (70% off up to $50)', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-prevent-users-from-applying-multiple-coupons/'       => esc_html_x( 'How to prevent users from applying multiple coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-create-coupon-for-new-users-only/'                   => esc_html_x( 'How to provide a discount coupon to new users only', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-restrict-a-coupon-by-number-of-orders-made/'         => esc_html_x( 'How to restrict a coupon by number of orders made', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-restrict-coupon-by-country-state-city-and-zip-code/' => esc_html_x( 'How to restrict coupons by location — country, state, city and ZIP code', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-restrict-coupon-by-payment-method/'                  => esc_html_x( 'How to restrict coupons by payment methods', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-restrict-a-coupon-based-on-product-attributes/'      => esc_html_x( 'How to restrict coupons by product attributes', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-restrict-coupons-by-product-taxonomy/'               => esc_html_x( 'How to restrict coupons by product taxonomy', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-restrict-coupon-by-shipping-method/'                 => esc_html_x( 'How to restrict coupons by shipping methods', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-restrict-coupon-by-user-roles/'                      => esc_html_x( 'How to restrict coupons by user roles', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-restrict-coupons-to-billing-emails/'                 => esc_html_x( 'How to restrict coupons to billing emails', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-restrict-coupons-to-woocommerce-custom-taxonomies/'  => esc_html_x( 'How to restrict coupons to WooCommerce custom taxonomies', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-restrict-coupon-by-product-quantity-in-cart/'        => esc_html_x( 'How to set up quantity discounts (bulk or volume discounts)', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
					),
				),
				array(
					'parent-title' => esc_html_x( 'How-tos', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
					'child'        => array(
						'https://woocommerce.com/document/smart-coupons/creating-effective-buy-one-get-one-promotions/'                          => esc_html_x( 'Creating Effective Buy One Get One Promotions', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-allow-customers-to-pick-one-out-of-many-gift-products/'           => esc_html_x( 'How to allow customers to pick one out of many gift products', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-allow-your-customers-to-send-gift-coupons/'                       => esc_html_x( 'How to allow your customers to send gift coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-apply-coupons-on-cheapest-costliest-product-in-cart/'             => esc_html_x( 'How to apply coupons on cheapest / costliest product in cart', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-assign-gift-certificates-to-user/'                                => esc_html_x( 'How to assign gift certificates to user', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-auto-apply-coupon/'                                               => esc_html_x( 'How to auto apply coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-auto-apply-tiered-discounts-based-on-customers-spending/'         => esc_html_x( 'How to auto apply tiered discounts based on customer’s spending', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-auto-generate-coupons-based-on-order-total/'                      => esc_html_x( 'How to auto generate coupons based on order total', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-auto-generate-coupons-using-shortcode/'                           => esc_html_x( 'How to auto-generate coupons (using shortcode)', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-autocomplete-gift-card-order-status/'                             => esc_html_x( 'How to autocomplete gift card order status', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-bulk-generate-coupons/'                                           => esc_html_x( 'How to bulk generate coupons (WooCommerce coupon code generator)', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-copy-coupon-code-from-coupon-list-page/'                          => esc_html_x( 'How to copy coupon code from coupon list page', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-create-a-woocommerce-bogo-buy-one-get-one-offer/'                 => esc_html_x( 'How to create a WooCommerce BOGO (Buy One Get One) offer', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-sell-gift-card-of-a-fixed-amount/'                                => esc_html_x( 'How to create and sell a fixed-amount gift card', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-sell-gift-card-of-variable-but-a-fixed-amount/'                   => esc_html_x( 'How to create gift card denominations in WooCommerce', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-sell-gift-card-of-any-amount/'                                    => esc_html_x( 'How to create gift cards in WooCommerce (advanced)', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-create-coupons-using-smart-coupons/'                              => esc_html_x( 'How to create smart and advanced WooCommerce coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-display-a-coupon-code-notice-sitewide/'                           => esc_html_x( 'How to display a coupon code notice sitewide', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-display-any-message-on-cart-after-applying-a-coupon/'             => esc_html_x( 'How to Display Any Message on Cart or Checkout Page After Applying a Coupon', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-display-available-coupons-on-any-page-using-shortcode/'           => esc_html_x( 'How to Display Available Coupons on Any Page (Using Shortcode)', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-display-promotional-messages-based-on-the-cart-threshold/'        => esc_html_x( 'How to display promotional messages based on the cart threshold', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-display-the-products-original-and-discounted-prices-in-the-cart/' => esc_html_x( 'How to display the product’s original and discounted prices in the cart', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-get-a-shareable-link-of-a-coupon/'                                => esc_html_x( 'How to Get a Coupon Shareable Link', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-give-a-sample-product-for-free/'                                  => esc_html_x( 'How to give a sample product for free', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-import-coupons-in-bulk-using-a-csv-file/'                         => esc_html_x( 'How to import coupons in bulk using a CSV file', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-give-coupons-with-products-for-next-order/'                       => esc_html_x( 'How to link next order coupons to a product', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-make-coupons-visible-to-customers-on-the-website/'                => esc_html_x( 'How to make coupons visible to customers on the website', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-migrate-coupons-from-one-store-to-another/'                       => esc_html_x( 'How to migrate coupons from one store to another', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-offer-cashback-coupons/'                                          => esc_html_x( 'How to offer cashback coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-gift-a-product-via-coupon/'                                       => esc_html_x( 'How to offer free gift (free product with purchase)', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-print-coupons/'                                                   => esc_html_x( 'How to print coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-provide-store-credit-for-a-refund/'                               => esc_html_x( 'How to provide store credit for a refund', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-regenerate-and-resend-coupons/'                                   => esc_html_x( 'How to Regenerate and Resend Coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-resend-coupons-generated-from-an-order-to-the-buyer/'             => esc_html_x( 'How to resend coupons generated from an order to the buyer', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-run-a-flash-sale-on-a-product/'                                   => esc_html_x( 'How to run a flash sale on a product', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-sell-gift-card-at-less-price/'                                    => esc_html_x( 'How to sell gift cards at a discount', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-quickly-send-store-credit/'                                       => esc_html_x( 'How to send store credit to customers instantly', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-set-up-a-buy-2-get-50-off-offer/'                                 => esc_html_x( 'How to set up a ‘buy 2 get 50% off’ offer', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-share-coupons-for-signup/'                                        => esc_html_x( 'How to share coupons for signup', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-show-any-message-coupon-description-on-a-coupon/'                 => esc_html_x( 'How to show any message/coupon description on a coupon', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-show-coupons-on-the-product-page/'                                => esc_html_x( 'How to show coupons on the product page', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-show-store-credit-balance-anywhere/'                              => esc_html_x( 'How to show Store Credit balance anywhere', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-stack-or-combine-coupons/'                                        => esc_html_x( 'How to stack or combine coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-upload-an-image-for-gift-cards/'                                  => esc_html_x( 'How to upload an image for gift cards', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-see-sent-received-coupons/'                                       => esc_html_x( 'How to view sent/received coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/using-the-woocommerce-coupon-code-generator-for-mass-coupon-generation/' => esc_html_x( 'Mass Coupon Generation using Smart Coupons', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
						'https://woocommerce.com/document/smart-coupons/how-to-apply-single-or-multiple-coupons-on-click-of-a-link/'             => esc_html_x( 'URL coupons – how to auto-apply promo coupon codes via a link', 'Documentation title on admin side', 'woocommerce-smart-coupons' ),
					),
				),
			);
			?>

			<div class="wc-sc-doc-wrapper">
				<?php foreach ( $docs as $group ) : ?>
					<div class="wc-sc-doc-group">
						<h3><?php echo esc_html( htmlspecialchars( $group['parent-title'], ENT_QUOTES, 'UTF-8' ) ); ?></h3>
							<ol>
							<?php foreach ( $group['child'] as $url => $title ) : ?>
								<li>
									<a href="<?php echo esc_url( htmlspecialchars( $url, ENT_QUOTES, 'UTF-8' ) ); ?>" target="_blank" rel="noopener">
										<?php echo esc_html( htmlspecialchars( $title, ENT_QUOTES, 'UTF-8' ) ); ?>
									</a>
								</li>
								<?php endforeach; ?>
							</ol>
					</div>
				<?php endforeach; ?>
			</div>
			<?php
		}

		/**
		 * Output the about screen.
		 */
		public function tour_screen() {
			if ( ! wp_script_is( 'jquery' ) ) {
				wp_enqueue_script( 'jquery' );
			}
			?>

			<script type="text/javascript">
				jQuery(function(){
					jQuery('#toplevel_page_woocommerce').find('a[href$=shop_coupon]').addClass('current');
					jQuery('#toplevel_page_woocommerce').find('a[href$=shop_coupon]').parent().addClass('current');
				});
			</script>

			<div class="wrap about-wrap">

			<?php $this->intro(); ?>

			<div class="wc-sc-grid-container">
				<div class="wc-sc-grid-item">
					<div class="icon-title-wrapper">
						<h3><?php esc_html_e( 'How to setup BOGO', 'woocommerce-smart-coupons' ); ?></h3>
					</div>
					<p><?php esc_html_e( 'Learn how to create a Buy One, Get One (BOGO) offer to boost sales and attract customers', 'woocommerce-smart-coupons' ); ?></p>
					<p><?php esc_html_e( 'This step-by-step guide will walk you through the process of setting up a BOGO deal, ensuring that your customers enjoy great value and keep coming back for more.', 'woocommerce-smart-coupons' ); ?></p>
					<button id="wc_sc_tour_01" class="button button-primary start-tour"><?php esc_html_e( 'Start this tour', 'woocommerce-smart-coupons' ); ?></button>
				</div>
				<div class="wc-sc-grid-item">
					<div class="icon-title-wrapper">
						<h3><?php esc_html_e( 'Setup fixed denomination Gift Cards', 'woocommerce-smart-coupons' ); ?></h3>
					</div>
					<p><?php esc_html_e( 'Discover how to set up and offer gift cards in your store', 'woocommerce-smart-coupons' ); ?></p>
					<p><?php esc_html_e( 'This guide will help you create gift cards, making it easy for your customers to purchase and redeem them, driving more sales and enhancing customer loyalty.', 'woocommerce-smart-coupons' ); ?></p>
					<button id="wc_sc_tour_02" class="button button-primary start-tour"><?php esc_html_e( 'Start this tour', 'woocommerce-smart-coupons' ); ?></button>
				</div>
				<div class="wc-sc-grid-item">
					<div class="icon-title-wrapper">
						<h3><?php esc_html_e( 'Setup any denomination Gift Cards', 'woocommerce-smart-coupons' ); ?></h3>
					</div>
					<p><?php esc_html_e( 'Learn how to configure the sale of store credit in any amount', 'woocommerce-smart-coupons' ); ?></p>
					<p><?php esc_html_e( 'This guide will show you how to set up flexible store credit options, allowing your customers to purchase credit in any custom denominations to use in your store.', 'woocommerce-smart-coupons' ); ?></p>
					<button id="wc_sc_tour_09" class="button button-primary start-tour"><?php esc_html_e( 'Start this tour', 'woocommerce-smart-coupons' ); ?></button>
				</div>
				<div class="wc-sc-grid-item">
					<div class="icon-title-wrapper">
						<h3><?php esc_html_e( 'Setup discounted price Gift Cards', 'woocommerce-smart-coupons' ); ?></h3>
					</div>
					<p><?php esc_html_e( 'Learn how to offer Gift Card worth $100 for just $90', 'woocommerce-smart-coupons' ); ?></p>
					<p><?php esc_html_e( 'This guide will show you how to create a compelling offer that encourages customers to buy Gift Cards at a significant discount, boosting your sales and customer engagement.', 'woocommerce-smart-coupons' ); ?></p>
					<button id="wc_sc_tour_11" class="button button-primary start-tour"><?php esc_html_e( 'Start this tour', 'woocommerce-smart-coupons' ); ?></button>
				</div>
			</div>
			</div>
			<?php
		}

		/**
		 * Sends user to the welcome page on first activation.
		 */
		public function sc_welcome() {

			if ( ! get_transient( '_smart_coupons_activation_redirect' ) ) {
				return;
			}

			// Delete the redirect transient.
			delete_transient( '_smart_coupons_activation_redirect' );

			wp_safe_redirect( admin_url( 'admin.php?page=sc-onboarding' ) );
			exit;
		}

		/**
		 * Onboarding screen
		 */
		public function onboarding_screen() {
			?>
			<script type="text/javascript">
				document.addEventListener('DOMContentLoaded', () => {
					const screens = document.querySelectorAll('.screen');
					let currentIndex = 0;

					function showScreen(index) {
						screens.forEach((screen, i) => {
							screen.classList.toggle('active', i === index);
						});
					}

					// Attach events to buttons inside each screen.
					screens.forEach((screen, index) => {

						const startBtn = screen.querySelector('.btn-start');
						const nextBtn = screen.querySelector('.btn-next');
						const prevBtn = screen.querySelector('.btn-previous');

						if (startBtn) {
							startBtn.addEventListener('click', () => {
								if (index < screens.length - 1) {
									currentIndex = index + 1;
									showScreen(currentIndex);
								}
							});
						}

						if (nextBtn) {
							nextBtn.addEventListener('click', () => {
								if (index < screens.length - 1) {
									currentIndex = index + 1;
									showScreen(currentIndex);
								}
							});
						}

						if (prevBtn) {
							prevBtn.addEventListener('click', () => {
								if (index > 0) {
									currentIndex = index - 1;
									showScreen(currentIndex);
								}
							});
						}

					});

					// Initial render.
					showScreen(currentIndex);
				});
			</script>
			<div class="screen-container" data-current="0">

				<section class="screen active">
					<!-- screen 1 -->
					<div class="container">
						<div class="main-content">
							<div class="header-section">
								<!-- StoreApps Logo -->
								<svg class="logo" viewBox="0 0 124.728 40.5163" fill="none">
									<defs>
										<filter id="filter0_d_1_985" x="0" y="0" width="124.728" height="40.5163" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
											<feFlood flood-opacity="0" result="BackgroundImageFix" />
											<feColorMatrix in="SourceAlpha" result="hardAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" />
											<feOffset dy="2" />
											<feGaussianBlur stdDeviation="2" />
											<feComposite in2="hardAlpha" operator="out" />
											<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.06 0" />
											<feBlend in2="BackgroundImageFix" mode="normal" result="effect1_dropShadow_1_985" />
											<feBlend in="SourceGraphic" in2="effect1_dropShadow_1_985" mode="normal" result="shape" />
										</filter>
									</defs>
									<g filter="url(#filter0_d_1_985)">
										<rect fill="white" height="32.5163" rx="16.2581" width="116.728" x="4" y="2" />
										<rect height="31.5163" rx="15.7581" stroke="black" stroke-opacity="0.08" width="115.728" x="4.5" y="2.5" />
										<path d="M38.5958 14.483L36.6965 11.1414V11.1178C36.493 10.7749 36.2032 10.4913 35.856 10.2951C35.5088 10.099 35.1162 9.99729 34.7175 10.0001H23.3303C22.9329 9.99825 22.542 10.1005 22.1964 10.2966C21.8507 10.4927 21.5625 10.7758 21.3602 11.1178L21.3454 11.1414L19.452 14.483C18.4935 16.1936 19.1305 18.494 20.6936 19.2254V26.1592C20.694 26.2072 20.704 26.2547 20.723 26.2988C20.7419 26.3429 20.7696 26.3827 20.8042 26.416C20.8388 26.4492 20.8798 26.4752 20.9246 26.4924C20.9694 26.5096 21.0172 26.5176 21.0652 26.5161H36.9914C37.0863 26.5161 37.1774 26.4786 37.2448 26.4117C37.3122 26.3449 37.3504 26.2541 37.3512 26.1592V19.2254C38.9202 18.494 39.5602 16.1936 38.5958 14.483ZM31.6827 19.252C31.8884 19.5538 32.0475 19.8849 32.1546 20.2341C32.2478 20.5712 32.2944 20.9195 32.2932 21.2693C32.2948 21.7022 32.2012 22.1301 32.0189 22.5227C31.8301 22.9213 31.5527 23.2713 31.2078 23.5461C30.8144 23.8621 30.3638 24.0994 29.8807 24.2451C29.4975 24.3667 29.1017 24.4439 28.7009 24.4752V24.4427C29.6064 24.2481 29.7981 23.0978 29.2701 22.505C29.2154 22.423 29.151 22.3477 29.0784 22.2809C28.9134 22.0859 28.7351 21.9026 28.5446 21.7323C28.2998 21.5052 27.9548 21.2221 27.5507 20.8829C26.8625 20.3426 26.2029 19.7667 25.5747 19.1576C25.2804 18.874 25.0027 18.5737 24.743 18.2581H27.2086C26.8958 17.9466 26.6161 17.6037 26.374 17.2347C26.1721 16.9318 26.0161 16.6009 25.9109 16.2525C25.8187 15.9153 25.7731 15.567 25.7752 15.2173C25.7735 14.7848 25.8661 14.357 26.0466 13.9639C26.2332 13.5706 26.5052 13.224 26.8429 12.9493C27.2371 12.6345 27.6874 12.3973 28.1701 12.2504C28.4685 12.1544 28.7758 12.0882 29.0873 12.0528H29.3586C28.4532 12.2474 28.2644 13.3976 28.7924 13.9904C28.8463 14.0732 28.9107 14.1485 28.9841 14.2146C29.0603 14.3097 29.142 14.4003 29.2289 14.4859C29.3144 14.5714 29.4088 14.6658 29.5238 14.7661C29.7715 14.9932 30.1136 15.2734 30.5206 15.6125C31.208 16.1528 31.8666 16.7287 32.4937 17.3379C32.7855 17.6273 33.0612 17.9325 33.3195 18.2522H30.8451C31.1576 18.556 31.4382 18.891 31.6827 19.252Z" fill="#5950EC" />
										<path d="M49.5858 17.0637H48.0167C48.0167 16.7363 47.6304 16.291 46.9579 16.291C46.4861 16.291 45.908 16.5033 45.908 16.8808C45.908 17.1964 46.3415 17.3232 47.2647 17.565C48.2969 17.8334 49.7509 18.1814 49.7509 19.6295C49.7509 20.88 48.6538 21.6616 47.1202 21.6616C45.0557 21.6616 44.2122 20.2754 44.2122 19.252H45.7812C45.7812 19.252 45.908 20.2931 47.2086 20.2931C47.9106 20.2931 48.1701 19.9982 48.1701 19.7033C48.1701 19.2904 47.6215 19.1459 47.014 19.0013C46.0319 18.7684 44.3065 18.4115 44.3065 16.9368C44.3065 15.7424 45.4863 14.8546 46.9756 14.8546C48.6803 14.8753 49.5858 16.0403 49.5858 17.0637ZM56.378 16.4561H54.0569V21.5436H52.4584V16.4561H50.1343V14.9815H56.378V16.4561ZM63.3147 18.267C63.3129 18.9357 63.1131 19.5888 62.7403 20.144C62.3675 20.6991 61.8386 21.1313 61.2203 21.386C60.602 21.6407 59.9221 21.7064 59.2665 21.5749C58.6109 21.4433 58.0089 21.1205 57.5367 20.647C57.0645 20.1736 56.7432 19.5708 56.6134 18.9148C56.4836 18.2589 56.5511 17.5792 56.8074 16.9615C57.0637 16.3439 57.4973 15.8161 58.0534 15.4448C58.6095 15.0735 59.2632 14.8753 59.9319 14.8753C60.8296 14.8784 61.6896 15.237 62.3236 15.8727C62.9575 16.5083 63.3139 17.3692 63.3147 18.267ZM58.006 18.267C58.0042 18.6479 58.1155 19.0207 58.3256 19.3384C58.5358 19.6561 58.8354 19.9043 59.1867 20.0517C59.5379 20.1991 59.925 20.239 60.2989 20.1664C60.6728 20.0938 61.0168 19.9119 61.2874 19.6438C61.5579 19.3757 61.7429 19.0334 61.819 18.6602C61.895 18.287 61.8586 17.8996 61.7145 17.547C61.5703 17.1944 61.3249 16.8925 61.0092 16.6794C60.6934 16.4664 60.3216 16.3517 59.9407 16.3499C59.6871 16.3476 59.4354 16.3954 59.2003 16.4906C58.9652 16.5858 58.7512 16.7265 58.5706 16.9046C58.39 17.0827 58.2464 17.2948 58.1479 17.5286C58.0495 17.7624 57.9983 18.0133 57.9971 18.267H58.006ZM69.7471 17.4471C69.7624 17.8728 69.6622 18.2947 69.4571 18.668C69.252 19.0414 68.9496 19.3522 68.5821 19.5676L69.9299 21.5436H67.9775L66.9924 19.9156H65.8363V21.5436H64.2585V14.9903H67.426C68.7561 14.9903 69.7471 16.0226 69.7471 17.4471ZM65.8245 16.4561V18.4498H67.1841C67.4485 18.4498 67.7021 18.3448 67.889 18.1579C68.076 17.9709 68.181 17.7174 68.181 17.453C68.181 17.1886 68.076 16.935 67.889 16.7481C67.7021 16.5611 67.4485 16.4561 67.1841 16.4561H65.8245ZM75.9907 14.9903V16.465H72.5518V17.5916H75.4215V18.9601H72.5518V20.0867H75.9907V21.5613H70.9769V14.9903H75.9907ZM84.2458 20.5202H81.0871L80.6594 21.5436H78.9783L81.7802 14.9903H83.5497L86.3634 21.5436H84.6705L84.2458 20.5202ZM83.6972 19.2314L82.6767 16.7923L81.6356 19.2402L83.6972 19.2314ZM92.7899 17.5149C92.7899 18.8067 91.9729 20.0601 90.2948 20.0601H88.8702V21.5348H87.2806V14.9903H90.3066C91.9817 14.9903 92.7899 16.2438 92.7899 17.5149ZM88.8702 16.4561V18.6032H90.1237C90.2687 18.6152 90.4146 18.5951 90.551 18.5444C90.6874 18.4936 90.811 18.4135 90.9129 18.3096C91.0148 18.2057 91.0926 18.0806 91.1407 17.9433C91.1888 17.8059 91.2061 17.6597 91.1913 17.5149C91.2036 17.372 91.1844 17.2281 91.135 17.0935C91.0855 16.9588 91.0071 16.8367 90.9053 16.7357C90.8034 16.6347 90.6806 16.5573 90.5456 16.509C90.4105 16.4607 90.2665 16.4426 90.1237 16.4561H88.8702ZM99.3697 17.5149C99.3697 18.8067 98.5528 20.0601 96.8746 20.0601H95.4501V21.5348H93.8604V14.9903H96.8805C98.5616 14.9903 99.3697 16.2438 99.3697 17.5149ZM95.4501 16.4561V18.6032H96.7006C96.8454 18.6147 96.991 18.5943 97.127 18.5434C97.263 18.4924 97.3862 18.4122 97.4878 18.3084C97.5894 18.2045 97.6669 18.0796 97.7148 17.9425C97.7628 17.8054 97.78 17.6594 97.7653 17.5149C97.7777 17.3717 97.7584 17.2276 97.7088 17.0927C97.6592 16.9578 97.5805 16.8355 97.4783 16.7345C97.3761 16.6334 97.2529 16.5561 97.1175 16.508C96.9821 16.4599 96.8377 16.4422 96.6947 16.4561H95.4501ZM105.563 17.0637H103.994C103.994 16.7363 103.608 16.291 102.935 16.291C102.464 16.291 101.885 16.5033 101.885 16.8808C101.885 17.1964 102.319 17.3232 103.242 17.565C104.274 17.8334 105.728 18.1814 105.728 19.6295C105.728 20.88 104.631 21.6616 103.098 21.6616C101.048 21.6616 100.19 20.2754 100.19 19.252H101.759C101.759 19.252 101.885 20.2931 103.186 20.2931C103.888 20.2931 104.148 19.9982 104.148 19.7033C104.148 19.2904 103.599 19.1459 102.991 19.0013C102.009 18.7684 100.287 18.4115 100.287 16.9368C100.287 15.7424 101.467 14.8546 102.941 14.8546C104.658 14.8753 105.563 16.0403 105.563 17.0637Z" fill="#161E2E" />
									</g>
								</svg>
								
								<!-- App Info -->
								<div class="app-info">
									<div class="app-icon">
										<svg viewBox="0 0 42 39.5862" fill="none">
											<g clip-path="url(#clip0_1_977)">
												<path d="M41.301 15.7191H36.7407L39.8494 6.12354C39.8802 6.03508 39.893 5.94132 39.887 5.84782C39.881 5.75431 39.8564 5.66296 39.8146 5.57915C39.7728 5.49535 39.7147 5.4208 39.6437 5.3599C39.5727 5.299 39.4903 5.253 39.4012 5.22461L23.422 0.03304C23.3345 0.00480179 23.2423 -0.00586261 23.1507 0.00165675C23.0591 0.00917612 22.9699 0.0347312 22.8882 0.076861C22.8065 0.118991 22.7338 0.176868 22.6744 0.247181C22.615 0.317494 22.57 0.398862 22.542 0.486631L17.6076 15.7191H0.703152C0.517375 15.7191 0.339145 15.7928 0.207396 15.9241C0.0756471 16.0555 0.00108642 16.2338 0 16.4201V38.8853C0.00108642 39.0716 0.0756471 39.2498 0.207396 39.3812C0.339145 39.5125 0.517375 39.5863 0.703152 39.5863H41.301C41.4864 39.5863 41.6642 39.5124 41.7953 39.3809C41.9264 39.2495 42 39.0712 42 38.8853V16.4201C42 16.2342 41.9264 16.0559 41.7953 15.9244C41.6642 15.7929 41.4864 15.7191 41.301 15.7191ZM23.6564 1.58762L38.3033 6.35859L35.2686 15.7191H33.8048L35.4496 10.5852C35.4777 10.4975 35.4884 10.4051 35.4809 10.3132C35.4734 10.2214 35.4479 10.1319 35.4059 10.05C35.3639 9.968 35.3062 9.89515 35.236 9.83558C35.1659 9.77601 35.0848 9.73089 34.9973 9.7028C34.4692 9.52726 34.0314 9.15 33.7789 8.65285C33.5264 8.15571 33.4796 7.57878 33.6485 7.04722C33.7056 6.87059 33.6904 6.67849 33.6064 6.51305C33.5224 6.34762 33.3763 6.22236 33.2003 6.16478L27.8547 4.42876C27.678 4.37142 27.4859 4.3865 27.3203 4.47071C27.1546 4.55492 27.0289 4.70142 26.9706 4.87823C26.8007 5.40631 26.4298 5.84584 25.9386 6.10139C25.4475 6.35693 24.8756 6.40787 24.3472 6.24313C24.1705 6.18579 23.9784 6.20087 23.8127 6.28508C23.6471 6.36929 23.5214 6.51579 23.4631 6.6926L20.5477 15.7191H19.0756L23.6564 1.58762ZM29.2569 15.7191L26.5635 10.8038L26.0783 11.0718L28.6237 15.7191H22.0198L24.6103 7.72761C25.292 7.80492 25.9812 7.67963 26.5924 7.36731C27.2036 7.05499 27.7097 6.56943 28.048 5.97097L32.16 7.31525C32.0842 7.99921 32.2097 8.69045 32.521 9.30375C32.8322 9.91705 33.3157 10.4256 33.9117 10.7667L32.308 15.715L29.2569 15.7191ZM21.0576 28.3537H16.1232C15.9246 28.0892 15.6907 27.8534 15.4282 27.6527C15.6907 27.452 15.9246 27.2161 16.1232 26.9517H21.0576C21.0576 27.1826 21.0206 27.4135 21.0206 27.6527C21.0206 27.8918 21.0206 28.1228 21.0576 28.3537ZM15.42 24.8445C15.42 25.4027 15.1992 25.938 14.806 26.333C14.4129 26.7281 13.8795 26.9506 13.3229 26.9517H11.1888V24.8445C11.1909 24.2863 11.413 23.7516 11.8066 23.3569C12.2002 22.9623 12.7334 22.7396 13.29 22.7374H15.3871L15.42 24.8445ZM9.80302 17.1252H11.1888V22.0446C10.9261 22.2433 10.691 22.4763 10.4897 22.7374C10.2885 22.4763 10.0534 22.2433 9.79068 22.0446L9.80302 17.1252ZM9.80302 24.8445V26.9517H7.70178C7.14517 26.9495 6.61197 26.7268 6.21838 26.3321C5.82479 25.9374 5.60271 25.4027 5.60055 24.8445V22.7374H7.70178C8.2584 22.7396 8.7916 22.9623 9.18518 23.3569C9.57877 23.7516 9.80085 24.2863 9.80302 24.8445ZM1.40219 17.1252H8.3926V21.4137C8.16332 21.361 7.92879 21.3347 7.69356 21.3354H4.90151C4.71611 21.3354 4.53831 21.4092 4.40721 21.5407C4.27612 21.6722 4.20247 21.8505 4.20247 22.0364V24.8445C4.2018 25.0804 4.22801 25.3156 4.2806 25.5455H1.40219V17.1252ZM1.40219 26.9517H4.90973C5.1079 27.2151 5.34022 27.4508 5.60055 27.6527C5.34022 27.8545 5.1079 28.0902 4.90973 28.3537H1.40219V26.9517ZM8.3926 38.1842H1.40219V29.7598H4.2806C4.22801 29.9897 4.2018 30.2249 4.20247 30.4608V33.2648C4.20247 33.4508 4.27612 33.6291 4.40721 33.7605C4.53831 33.892 4.71611 33.9658 4.90151 33.9658H7.70178C7.93701 33.9665 8.17155 33.9402 8.40082 33.8875L8.3926 38.1842ZM7.69356 32.568H5.60055V30.4608C5.60271 29.9026 5.82479 29.3679 6.21838 28.9732C6.61197 28.5785 7.14517 28.3558 7.70178 28.3537H9.80302V30.4608C9.80085 31.019 9.57877 31.5537 9.18518 31.9484C8.7916 32.3431 8.2584 32.5658 7.70178 32.568H7.69356ZM11.1888 38.1842H9.79068V33.2648C10.0534 33.0661 10.2885 32.8331 10.4897 32.5721C10.691 32.8331 10.9261 33.0661 11.1888 33.2648V38.1842ZM11.1888 30.4608V28.3537H13.29C13.8466 28.3548 14.38 28.5772 14.7731 28.9723C15.1663 29.3673 15.3871 29.9027 15.3871 30.4608V32.568H13.29C12.7334 32.5658 12.2002 32.3431 11.8066 31.9484C11.413 31.5537 11.1909 31.019 11.1888 30.4608ZM40.5896 38.1842H12.6033V33.8916C12.8325 33.9446 13.0671 33.9709 13.3023 33.97H16.1232C16.3086 33.97 16.4864 33.8961 16.6175 33.7646C16.7486 33.6332 16.8222 33.4549 16.8222 33.269V30.4608C16.8229 30.2249 16.7967 29.9897 16.7441 29.7598H21.2673C21.7437 31.7515 22.875 33.5242 24.4789 34.7924C26.0827 36.0605 28.0657 36.7502 30.1081 36.7502C32.1505 36.7502 34.1334 36.0605 35.7373 34.7924C37.3411 33.5242 38.4724 31.7515 38.9489 29.7598H40.5937L40.5896 38.1842ZM22.4022 27.6527C22.4022 26.1251 22.8539 24.6319 23.7002 23.3618C24.5465 22.0916 25.7493 21.1017 27.1566 20.5171C28.5639 19.9326 30.1125 19.7796 31.6065 20.0776C33.1005 20.3756 34.4728 21.1112 35.55 22.1914C36.6271 23.2715 37.3606 24.6477 37.6578 26.1459C37.9549 27.6441 37.8024 29.197 37.2195 30.6083C36.6366 32.0196 35.6494 33.2258 34.3829 34.0745C33.1163 34.9231 31.6272 35.3761 30.104 35.3761C29.0924 35.3766 28.0907 35.1772 27.156 34.7893C26.2213 34.4013 25.3721 33.8325 24.6568 33.1152C23.9415 32.3979 23.3742 31.5462 22.9874 30.6089C22.6005 29.6716 22.4017 28.6671 22.4022 27.6527ZM40.6019 28.3537H39.1504C39.1504 28.1228 39.1833 27.8918 39.1833 27.6527C39.1833 27.4135 39.1627 27.1826 39.1504 26.9517H40.5855L40.6019 28.3537ZM40.6019 25.5455H38.9571C38.4807 23.5539 37.3494 21.7811 35.7455 20.5129C34.1417 19.2448 32.1587 18.5551 30.1163 18.5551C28.0739 18.5551 26.091 19.2448 24.4871 20.5129C22.8833 21.7811 21.752 23.5539 21.2755 25.5455H16.7523C16.8049 25.3156 16.8311 25.0804 16.8304 24.8445V22.0364C16.8304 21.8505 16.7568 21.6722 16.6257 21.5407C16.4946 21.4092 16.3168 21.3354 16.1314 21.3354H13.3023C13.0671 21.3345 12.8325 21.3608 12.6033 21.4137V17.1252H40.6019V25.5455Z" fill="#F17EB8" />
												<path d="M30.104 31.1618C29.7332 31.1618 29.3776 31.0141 29.1154 30.7511C28.8532 30.4882 28.7059 30.1316 28.7059 29.7598H27.2996C27.3025 30.3806 27.5102 30.983 27.8903 31.4731C28.2704 31.9631 28.8015 32.3133 29.4008 32.4689V33.9699H30.803V32.4689C31.4605 32.297 32.0331 31.8909 32.4137 31.3266C32.7944 30.7622 32.9571 30.0781 32.8714 29.4022C32.7858 28.7263 32.4577 28.1048 31.9484 27.6538C31.4391 27.2028 30.7834 26.9532 30.104 26.9516C29.8267 26.9516 29.5556 26.8691 29.325 26.7146C29.0944 26.5601 28.9147 26.3405 28.8085 26.0836C28.7024 25.8266 28.6746 25.5439 28.7287 25.2711C28.7829 24.9984 28.9164 24.7478 29.1125 24.5512C29.3086 24.3545 29.5584 24.2206 29.8304 24.1664C30.1024 24.1121 30.3844 24.1399 30.6406 24.2464C30.8968 24.3528 31.1158 24.533 31.2699 24.7643C31.424 24.9955 31.5062 25.2674 31.5062 25.5455H32.9043C32.9016 24.9252 32.6945 24.3232 32.3152 23.8332C31.9359 23.3432 31.4057 22.9927 30.8071 22.8363V21.3353H29.4008V22.8363C28.743 23.0083 28.1703 23.4147 27.7896 23.9795C27.409 24.5443 27.2466 25.2289 27.3327 25.9051C27.4189 26.5813 27.7478 27.2028 28.2578 27.6535C28.7679 28.1042 29.4242 28.353 30.104 28.3536C30.2942 28.3433 30.4846 28.3719 30.6634 28.4378C30.8423 28.5037 31.0059 28.6055 31.1442 28.7368C31.2825 28.8682 31.3927 29.0265 31.468 29.202C31.5433 29.3776 31.5821 29.5666 31.5821 29.7577C31.5821 29.9488 31.5433 30.1378 31.468 30.3133C31.3927 30.4889 31.2825 30.6471 31.1442 30.7785C31.0059 30.9099 30.8423 31.0117 30.6634 31.0776C30.4846 31.1435 30.2942 31.1721 30.104 31.1618Z" fill="#F17EB8" />
												<path d="M30.1533 12.3336C29.9844 12.2632 29.7985 12.2443 29.6189 12.2794C29.4394 12.3145 29.2742 12.4019 29.1439 12.5308C29.0137 12.6596 28.9243 12.8241 28.8869 13.0037C28.8496 13.1833 28.8659 13.3699 28.9338 13.5402C29.0017 13.7106 29.1183 13.857 29.2689 13.9612C29.4194 14.0654 29.5973 14.1227 29.7802 14.1259C29.9631 14.1292 30.1429 14.0782 30.297 13.9794C30.4512 13.8807 30.5728 13.7384 30.6467 13.5706C30.6967 13.4571 30.7236 13.3347 30.7258 13.2106C30.728 13.0865 30.7055 12.9633 30.6595 12.848C30.6135 12.7328 30.5451 12.6279 30.4582 12.5396C30.3712 12.4512 30.2676 12.3812 30.1533 12.3336ZM30.1533 13.3397C30.1239 13.4077 30.0751 13.4654 30.0131 13.5056C29.951 13.5458 29.8785 13.5667 29.8046 13.5656C29.7308 13.5646 29.6589 13.5416 29.598 13.4996C29.5371 13.4577 29.49 13.3986 29.4626 13.3298C29.4351 13.261 29.4286 13.1856 29.4438 13.1131C29.4591 13.0406 29.4953 12.9743 29.5481 12.9224C29.6008 12.8706 29.6677 12.8356 29.7403 12.8218C29.8129 12.808 29.8879 12.816 29.9559 12.8449C30.0449 12.887 30.1137 12.9625 30.1476 13.0551C30.1815 13.1477 30.1776 13.25 30.1369 13.3397H30.1533Z" fill="#F17EB8" />
												<path d="M29.7914 14.2345C29.6498 14.2356 29.5095 14.2061 29.3802 14.1479C29.254 14.0963 29.1394 14.0196 29.0433 13.9225C28.9472 13.8255 28.8716 13.71 28.821 13.583C28.7437 13.3911 28.725 13.1806 28.7674 12.978C28.8097 12.7755 28.9112 12.5902 29.0589 12.4456C29.2066 12.3011 29.3938 12.2038 29.5967 12.1662C29.7996 12.1287 30.0091 12.1525 30.1985 12.2346C30.451 12.3436 30.6504 12.5481 30.7536 12.8036C30.8567 13.0591 30.8553 13.3451 30.7495 13.5995C30.6412 13.853 30.4372 14.0531 30.1821 14.1562C30.0584 14.2082 29.9256 14.2349 29.7914 14.2345ZM29.7914 12.3707C29.6571 12.3706 29.5247 12.4034 29.406 12.4665C29.2872 12.5295 29.1857 12.6207 29.1102 12.7322C29.0347 12.8437 28.9877 12.972 28.9731 13.1059C28.9585 13.2399 28.9769 13.3754 29.0266 13.5005C29.1091 13.7013 29.2672 13.8613 29.4666 13.9459C29.668 14.0295 29.8943 14.0295 30.0957 13.9459C30.2975 13.8641 30.4586 13.7054 30.5439 13.5047C30.6273 13.3027 30.6273 13.0758 30.5439 12.8738C30.4597 12.6761 30.3018 12.5193 30.104 12.4367C30.0066 12.3942 29.9017 12.3718 29.7956 12.3707H29.7914ZM29.7914 13.6779C29.7266 13.6776 29.6624 13.665 29.6023 13.6407C29.4846 13.5884 29.3918 13.4923 29.3432 13.3727C29.2958 13.2535 29.2972 13.1202 29.3473 13.0021C29.3973 12.8839 29.492 12.7903 29.6105 12.7418C29.6691 12.7173 29.732 12.7047 29.7956 12.7047C29.8591 12.7047 29.922 12.7173 29.9806 12.7418C30.099 12.7927 30.1925 12.8884 30.241 13.008C30.2895 13.1277 30.289 13.2617 30.2396 13.381C30.2149 13.4401 30.1785 13.4937 30.1326 13.5383C30.0866 13.583 30.0321 13.6178 29.9724 13.6407C29.9152 13.6652 29.8536 13.6779 29.7914 13.6779ZM29.7914 12.9232C29.7588 12.9175 29.7254 12.9175 29.6928 12.9232C29.6599 12.9357 29.6301 12.9549 29.6053 12.9798C29.5804 13.0047 29.5612 13.0346 29.5488 13.0676C29.5356 13.0996 29.5288 13.1339 29.5288 13.1686C29.5288 13.2033 29.5356 13.2376 29.5488 13.2696C29.5619 13.3022 29.5813 13.3318 29.6061 13.3566C29.6308 13.3814 29.6603 13.4009 29.6928 13.414C29.7244 13.4282 29.7588 13.4355 29.7935 13.4355C29.8282 13.4355 29.8625 13.4282 29.8942 13.414C29.9601 13.3865 30.0131 13.3349 30.0423 13.2696C30.0558 13.2371 30.0628 13.2023 30.0628 13.1671C30.0629 13.1319 30.0561 13.097 30.0427 13.0645C30.0293 13.0319 30.0097 13.0023 29.9849 12.9774C29.9602 12.9525 29.9308 12.9327 29.8984 12.9191C29.8628 12.9138 29.8265 12.9152 29.7914 12.9232Z" fill="#F17EB8" />
												<path d="M25.1079 13.8098C25.0377 13.9792 25.0189 14.1656 25.0539 14.3457C25.0889 14.5257 25.1761 14.6914 25.3045 14.822C25.433 14.9526 25.5971 15.0422 25.7762 15.0797C25.9552 15.1172 26.1413 15.1009 26.3112 15.0327C26.481 14.9646 26.6271 14.8477 26.7309 14.6967C26.8348 14.5457 26.892 14.3674 26.8952 14.184C26.8985 14.0005 26.8476 13.8202 26.7491 13.6657C26.6506 13.5111 26.5088 13.3891 26.3415 13.315C26.2284 13.2643 26.1062 13.2368 25.9823 13.2344C25.8584 13.2319 25.7353 13.2544 25.6203 13.3005C25.5052 13.3467 25.4006 13.4156 25.3125 13.503C25.2245 13.5905 25.1549 13.6948 25.1079 13.8098ZM26.3086 14.3211C26.2893 14.3668 26.2613 14.4081 26.226 14.4428C26.1907 14.4775 26.1489 14.5048 26.103 14.5232C26.0571 14.5416 26.0081 14.5507 25.9587 14.55C25.9093 14.5493 25.8605 14.5388 25.8152 14.5191C25.7698 14.5002 25.7287 14.4724 25.6941 14.4374C25.6596 14.4024 25.6323 14.3609 25.614 14.3152C25.5956 14.2695 25.5865 14.2206 25.5871 14.1714C25.5878 14.1221 25.5982 14.0735 25.6178 14.0284C25.637 13.9829 25.6649 13.9416 25.6999 13.9069C25.735 13.8723 25.7765 13.8449 25.8222 13.8263C25.8678 13.8077 25.9166 13.7984 25.9659 13.7987C26.0151 13.7991 26.0638 13.8091 26.1092 13.8284C26.1545 13.8476 26.1957 13.8756 26.2302 13.9108C26.2648 13.9459 26.2921 13.9876 26.3107 14.0333C26.3292 14.0791 26.3385 14.1281 26.3382 14.1774C26.3378 14.2268 26.3278 14.2756 26.3086 14.3211Z" fill="#F17EB8" />
											</g>
											<defs>
												<clipPath id="clip0_1_977">
													<rect fill="white" height="39.5862" width="42" />
												</clipPath>
											</defs>
										</svg>
									</div>
									<div class="app-title">
										<h1><?php echo esc_html_x( 'Smart Coupons', 'Plugin name on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></h1>
										<p><?php echo esc_html_x( 'for WooCommerce', 'Plugin name part 2 on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
								</div>
							</div>
							
							<div class="welcome-section">
								<div class="welcome-text">
									<h2><?php echo esc_html_x( 'Welcome to Smart Coupons', 'Welcome text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></h2>
									<p><?php echo esc_html_x( 'Your discount, pricing & loyalty engine for WooCommerce', 'Welcome description on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
								</div>
								
								<div class="stats">
									<!-- Trusted stat -->
									<div class="stat-card">
										<svg class="stat-icon" viewBox="0 0 13.503 21.5" fill="none">
											<path d="M2.75147 19.75C2.75147 18.3358 2.75147 17.6287 3.19081 17.1893C3.63015 16.75 4.33726 16.75 5.75147 16.75H7.75147C9.16569 16.75 9.87279 16.75 10.3121 17.1893C10.7515 17.6287 10.7515 18.3358 10.7515 19.75V20.75H2.75147V19.75Z" stroke="#7F54B3" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" />
											<path d="M6.75147 11.75L6.75147 16.75" stroke="#7F54B3" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" />
											<path d="M0.751473 20.75H12.7515" stroke="#7F54B3" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" />
											<path d="M7.78805 1.61651L8.84394 3.74573C8.98792 4.04212 9.37188 4.32642 9.69584 4.38086L11.6096 4.70145C12.8335 4.90712 13.1215 5.80236 12.2396 6.6855L10.7517 8.18563C10.4998 8.43968 10.3618 8.92964 10.4398 9.28048L10.8657 11.1375C11.2017 12.6074 10.4278 13.176 9.13791 12.4078L7.3441 11.3371C7.02014 11.1435 6.4862 11.1435 6.15624 11.3371L4.36243 12.4078C3.07858 13.176 2.29866 12.6013 2.63462 11.1375L3.06058 9.28048C3.13857 8.92964 3.00058 8.43968 2.74861 8.18563L1.26078 6.6855C0.384873 5.80236 0.666842 4.90712 1.89071 4.70145L3.8045 4.38086C4.12246 4.32642 4.50642 4.04212 4.6504 3.74573L5.70629 1.61651C6.28222 0.461164 7.21812 0.461164 7.78805 1.61651Z" stroke="#7F54B3" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" />
										</svg>
										<div>
											<div class="stat-label"><?php echo esc_html_x( 'Trusted', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></div>
											<div class="stat-value"><?php echo esc_html_x( '13+ years', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></div>
										</div>
									</div>
									
									<!-- Stores stat -->
									<div class="stat-card">
										<svg class="stat-icon" viewBox="0 0 21.5 20.5" fill="none">
											<path d="M1.75 9.25L1.75 13.75C1.75 16.5784 1.75 17.9926 2.62868 18.8713C3.50736 19.75 4.92158 19.75 7.75 19.75L13.75 19.75C16.5784 19.75 17.9926 19.75 18.8713 18.8713C19.75 17.9926 19.75 16.5784 19.75 13.75V9.25" stroke="#7F54B3" stroke-width="1.5" />
											<path d="M6.72072 7.25L7.44521 7.05605C7.34787 6.69245 6.9961 6.45732 6.62291 6.5064C6.24972 6.55549 5.97072 6.87359 5.97072 7.25L6.72072 7.25ZM0.863479 8.29045L1.5663 8.02865L1.5663 8.02865L0.863479 8.29045ZM20.6365 8.29045L19.9337 8.02865L19.9337 8.02866L20.6365 8.29045ZM14.7793 7.25H15.5293C15.5293 6.87359 15.2503 6.55549 14.8771 6.5064C14.5039 6.45732 14.1521 6.69245 14.0548 7.05605L14.7793 7.25ZM1.20768 6.3277L1.85768 6.70185L1.85768 6.70185L1.20768 6.3277ZM2.17134 4.65355L1.52133 4.27939H1.52133L2.17134 4.65355ZM20.2923 6.3277L19.6423 6.70185V6.70185L20.2923 6.3277ZM19.3287 4.65355L19.9787 4.27939V4.27939L19.3287 4.65355ZM20.7373 7.47893L19.9898 7.54116V7.54117L20.7373 7.47893ZM0.762746 7.47893L0.0153325 7.41669V7.41669L0.762746 7.47893ZM6.72072 7.25L5.97072 7.25C5.97072 8.48749 4.95869 9.5 3.69875 9.5V10.25L3.69875 11C5.77678 11 7.47072 9.32622 7.47072 7.25H6.72072ZM3.69875 10.25V9.5C2.71882 9.5 1.88568 8.88607 1.5663 8.02865L0.863479 8.29045L0.160654 8.55225C0.693548 9.98286 2.07768 11 3.69875 11L3.69875 10.25ZM20.6365 8.29045L19.9337 8.02866C19.6143 8.88607 18.7812 9.5 17.8013 9.5V10.25V11C19.4223 11 20.8065 9.98286 21.3394 8.55225L20.6365 8.29045ZM17.8013 10.25V9.5C16.5413 9.5 15.5293 8.48749 15.5293 7.25H14.7793H14.0293C14.0293 9.32622 15.7232 11 17.8013 11V10.25ZM10.75 10.25V9.5C9.14134 9.5 7.81679 8.4441 7.44521 7.05605L6.72072 7.25L5.99623 7.44395C6.54834 9.50635 8.48156 11 10.75 11V10.25ZM14.7793 7.25L14.0548 7.05605C13.6832 8.4441 12.3587 9.5 10.75 9.5V10.25V11C13.0185 11 14.9517 9.50635 15.5038 7.44395L14.7793 7.25ZM1.20768 6.3277L1.85768 6.70185L2.82135 5.0277L2.17134 4.65355L1.52133 4.27939L0.557668 5.95355L1.20768 6.3277ZM20.2923 6.3277L20.9423 5.95355L19.9787 4.27939L19.3287 4.65355L18.6787 5.0277L19.6423 6.70185L20.2923 6.3277ZM4.66512 0.75V1.5L16.8349 1.5V0.75V0L4.66512 0V0.75ZM18.8086 2.70934H19.5586C19.5586 1.20786 18.334 0 16.8349 0V0.75V1.5C17.5159 1.5 18.0586 2.04659 18.0586 2.70934H18.8086ZM19.3287 4.65355L19.9787 4.27939C19.7032 3.80089 19.5586 3.25972 19.5586 2.70934H18.8086H18.0586C18.0586 3.52286 18.2725 4.322 18.6787 5.0277L19.3287 4.65355ZM2.69143 2.70934L3.44143 2.70934C3.44143 2.04659 3.98413 1.5 4.66512 1.5V0.75V0C3.16603 0 1.94143 1.20786 1.94143 2.70934L2.69143 2.70934ZM20.6365 8.29045L21.3394 8.55225C21.3822 8.43715 21.4443 8.27692 21.476 8.07441C21.5076 7.87312 21.5053 7.66456 21.4847 7.41669L20.7373 7.47893L19.9898 7.54117C20.006 7.73553 19.9992 7.80963 19.9942 7.842C19.9893 7.87315 19.9825 7.89756 19.9337 8.02865L20.6365 8.29045ZM20.2923 6.3277L19.6423 6.70185C19.9174 7.17967 19.9685 7.28434 19.9898 7.54116L20.7373 7.47893L21.4847 7.41669C21.4324 6.78904 21.2114 6.42106 20.9423 5.95355L20.2923 6.3277ZM2.17134 4.65355L2.82135 5.0277C3.22756 4.322 3.44143 3.52286 3.44143 2.70934L2.69143 2.70934L1.94143 2.70934C1.94143 3.25972 1.79677 3.80089 1.52133 4.27939L2.17134 4.65355ZM0.863479 8.29045L1.5663 8.02865C1.51747 7.89756 1.51074 7.87315 1.50586 7.842C1.50078 7.80963 1.49397 7.73552 1.51016 7.54116L0.762746 7.47893L0.0153325 7.41669C-0.00530809 7.66457 -0.00759906 7.87312 0.0239711 8.07441C0.0557318 8.27692 0.117781 8.43715 0.160654 8.55225L0.863479 8.29045ZM1.20768 6.3277L0.557668 5.95355C0.288564 6.42106 0.0675968 6.78904 0.0153325 7.41669L0.762746 7.47893L1.51016 7.54116C1.53154 7.28434 1.58265 7.17967 1.85768 6.70185L1.20768 6.3277Z" fill="#7F54B3" />
											<path d="M5.75 16.25H9.75" stroke="#7F54B3" stroke-linecap="round" stroke-width="1.5" />
										</svg>
										<div>
											<div class="stat-label"><?php echo esc_html_x( 'Stores', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></div>
											<div class="stat-value"><?php echo esc_html_x( '25,000+', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></div>
										</div>
									</div>
									
									<!-- Revenue growth stat -->
									<div class="stat-card">
										<svg class="stat-icon" viewBox="0 0 21.5 21.5" fill="none">
											<path d="M12.75 16.75C17.1683 16.75 20.75 13.1683 20.75 8.75C20.75 4.33172 17.1683 0.75 12.75 0.75C8.33172 0.75 4.75 4.33172 4.75 8.75C4.75 13.1683 8.33172 16.75 12.75 16.75Z" stroke="#7F54B3" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" />
											<path d="M1.90657 9.75C1.17523 10.8676 0.75 12.2035 0.75 13.6388C0.75 17.5662 3.93378 20.75 7.86116 20.75C9.29646 20.75 10.6324 20.3248 11.75 19.5934" stroke="#7F54B3" stroke-linejoin="round" stroke-width="1.5" />
											<path d="M12.75 5.75C11.6454 5.75 10.75 6.42157 10.75 7.25C10.75 8.07843 11.6454 8.75 12.75 8.75C13.8546 8.75 14.75 9.42157 14.75 10.25C14.75 11.0784 13.8546 11.75 12.75 11.75M12.75 5.75C13.6208 5.75 14.3616 6.1674 14.6362 6.75M12.75 5.75V4.25M12.75 11.75C11.8792 11.75 11.1384 11.3326 10.8638 10.75M12.75 11.75V13.25" stroke="#7F54B3" stroke-linejoin="round" stroke-width="1.5" />
										</svg>
										<div>
											<div class="stat-label"><?php echo esc_html_x( 'Revenue growth', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></div>
											<div class="stat-value"><?php echo esc_html_x( 'Millions', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></div>
										</div>
									</div>
								</div>
							</div>
						</div>
						
						<button class="cta-button btn-start"><?php echo esc_html_x( 'Get Started', 'Get started button on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></button>
					</div>
				</section>

				<section class="screen">
					<!-- screen 2 -->
					<div class="container slideItem">
						<div class="left-section">
							<div class="content-area">
								<?php $this->onboarding_header(); ?>
								
								<!-- Title -->
								<div class="title-section">
									<h1 class="title"><?php echo esc_html_x( 'Discounts. Made Smarter.', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></h1>
								</div>
								
								<!-- Features List -->
								<div class="features-list">
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'BOGO, tiered, recurring - everything handled', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Dynamic pricing by location, role, order history', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Coupon restrictions like a boss, never eat loss', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Flash sales, cart nudges, seasonal madness', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Proven for every business, every model', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
								</div>
							</div>
							
							<?php $this->navigation_buttons(); ?>
						</div>
						
						<!-- Right Section with Illustration -->
						<div class="right-section">
							<div class="illustration-container">
								<img src="<?php echo esc_url( WC_SC_PLUGIN_URL . 'assets/images/onboarding/coupon-discount.png' ); ?>" alt="Discounts. Made Smarter.">
							</div>
						</div>
						
						<?php $this->storeapps_logo(); ?>
						
						<!-- Pagination Controls -->
						<?php $this->pagination_controls( 2 ); ?>
					</div>
				</section>

				<section class="screen">
					<!-- screen 3 -->
					<div class="container slideItem">
						<div class="left-section">
							<div class="content-area">
								<?php $this->onboarding_header(); ?>
								
								<!-- Title -->
								<div class="title-section">
									<h1 class="title"><?php echo esc_html_x( 'Gift Cards That Raise Revenue', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></h1>
								</div>
								
								<!-- Features List -->
								<div class="features-list">
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Giveaways, self-purchase and gift to friends', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Fixed amounts or customer choice', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Rewards, cashback - all in one', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Multi-use, multi-purchase balance', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Beautiful designs, instant delivery', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
								</div>
							</div>
							
							<?php $this->navigation_buttons(); ?>
						</div>
						
						<!-- Right Section with Illustration -->
						<div class="right-section">
							<div class="illustration-container">
								<img src="<?php echo esc_url( WC_SC_PLUGIN_URL . 'assets/images/onboarding/coupon-gift.png' ); ?>" alt="Gift Cards That Raise Revenue">
							</div>
						</div>
						
						<?php $this->storeapps_logo(); ?>
						
						<!-- Pagination Controls -->
						<?php $this->pagination_controls( 3 ); ?>
					</div>
				</section>

				<section class="screen">
					<!-- screen 4 -->
					<div class="container slideItem">
						<div class="left-section">
							<div class="content-area">
								<?php $this->onboarding_header(); ?>
								
								<!-- Title -->
								<div class="title-section">
									<h1 class="title"><?php echo esc_html_x( 'Frictionless Sharing', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></h1>
								</div>
								
								<!-- Features List -->
								<div class="features-list">
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Automagically apply coupons - no codes to remember', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Share via links, emails, QR codes', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Bulk generate thousands in seconds', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<?php /* translators: Link to Affiliate plugin */ ?>
										<p class="feature-text"><?php printf( esc_html_x( 'CSV export for partners, integrations for %s', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ), '<a href="' . esc_url( 'https://woocommerce.com/products/affiliate-for-woocommerce/' ) . '" class="smLink">' . esc_html_x( 'Affiliates', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ) . '</a>' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'On-site promotional messages', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
								</div>
							</div>
							
							<?php $this->navigation_buttons(); ?>
						</div>
						
						<!-- Right Section with Illustration -->
						<div class="right-section">
							<div class="illustration-container">
								<img src="<?php echo esc_url( WC_SC_PLUGIN_URL . 'assets/images/onboarding/coupon-sharing.png' ); ?>" alt="Frictionless Sharing">
							</div>
						</div>
						
						<?php $this->storeapps_logo(); ?>
						
						<!-- Pagination Controls -->
						<?php $this->pagination_controls( 4 ); ?>
					</div>
				</section>

				<section class="screen">
					<!-- screen 5 -->
					<div class="container slideItem">
						<div class="left-section">
							<div class="content-area">
								<?php $this->onboarding_header(); ?>
								
								<!-- Title -->
								<div class="title-section">
									<h1 class="title"><?php echo esc_html_x( 'Boost Loyalty & Repeat Sales', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></h1>
								</div>
								
								<!-- Features List -->
								<div class="features-list">
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Welcome discounts that convert', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Cashback credits for next order', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Winback offers', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
								</div>
							</div>
							
							<?php $this->navigation_buttons(); ?>
						</div>
						
						<!-- Right Section with Illustration -->
						<div class="right-section">
							<div class="illustration-container">
								<img src="<?php echo esc_url( WC_SC_PLUGIN_URL . 'assets/images/onboarding/coupon-sales.png' ); ?>" alt="Boost Loyalty & Repeat Sales">
							</div>
						</div>
						
						<?php $this->storeapps_logo(); ?>
						
						<!-- Pagination Controls -->
						<?php $this->pagination_controls( 5 ); ?>
					</div>
				</section>

				<section class="screen">
					<!-- screen 6 -->
					<div class="container slideItem">
						<div class="left-section">
							<div class="content-area">
								<?php $this->onboarding_header(); ?>
								
								<!-- Title -->
								<div class="title-section">
									<h1 class="title"><?php echo esc_html_x( 'One More Thing', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></h1>
								</div>
								
								<!-- Features List -->
								<div class="features-list">
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><a href="<?php echo esc_url( 'https://woocommerce.com/document/smart-coupons/' ); ?>" class="smLink"><?php echo esc_html_x( 'Lots of docs and guides here', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></a></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Questions? Team is always around', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Beware of knock-off products', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<p class="feature-text"><?php echo esc_html_x( 'Start small, think big, iterate', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></p>
									</div>
									
									<div class="feature-item">
										<?php $this->check_icon(); ?>
										<?php /* translators: Plugin name */ ?>
										<p class="feature-text"><?php printf( esc_html_x( 'You\'ve got this. Seriously. Go ahead and make more with %s.', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ), '<strong style="color: #EF57AF; font-weight: 600;">' . esc_html_x( 'Smart Coupons', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ) . '</strong>' ); ?></p>
									</div>
								</div>
							</div>

							<!-- Navigation Buttons -->
							<div class="navigation-buttons">
								<button class="btn-previous">
									<svg class="arrow-icon" viewBox="0 0 20 20" fill="none">
										<path d="M5.88388 0.441942L0.883884 5.44194L5.88388 10.4419" stroke="#7F54B3" stroke-width="1.25" transform="translate(7, 4.5)"/>
									</svg>
									<span><?php echo esc_html_x( 'Previous', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></span>
								</button>
								
								<button class="cta-button btn-next">
									<span><a href="<?php echo esc_url( add_query_arg( array( 'page' => 'sc-about' ), admin_url( 'admin.php' ) ) ); ?>" class="wc-sc-onboarding-unset"><?php echo esc_html_x( 'Next', 'Next button on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></a></span>
									<svg class="arrow-icon" viewBox="0 0 20 20" fill="none">
										<path d="M5.88388 0.441942L0.883884 5.44194L5.88388 10.4419" stroke="white" stroke-width="1.25" transform="translate(7, 4.5) scale(-1, 1) translate(-13, 0)"/>
									</svg>
								</button>
							</div>
						</div>
						
						<!-- Right Section with Illustration -->
						<div class="right-section">
							<div class="illustration-container">
								<img src="<?php echo esc_url( WC_SC_PLUGIN_URL . 'assets/images/onboarding/coupon-more.png' ); ?>" alt="One More Thing">
							</div>
						</div>
						
						<?php $this->storeapps_logo(); ?>
						
						<!-- Pagination Controls -->
						<?php $this->pagination_controls( 6 ); ?>
					</div>
				</section>
			</div>
			<?php
		}

		/**
		 * Function to register styles & scripts
		 */
		public function register() {
			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
			if ( ! wp_style_is( 'wc-sc-onboarding', 'registered' ) ) {
				wp_register_style( 'wc-sc-onboarding', untrailingslashit( plugins_url( '/', WC_SC_PLUGIN_FILE ) ) . '/assets/css/wc-sc-onboarding' . $suffix . '.css', array(), $this->get_smart_coupons_version() );
			}
		}

		/**
		 * Enqueue styles & scripts
		 */
		public function enqueue() {
			$get_page = ( ! empty( $_GET['page'] ) ) ? wc_clean( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore

			if ( 'sc-onboarding' === $get_page ) {
				if ( ! wp_style_is( 'wc-sc-onboarding' ) ) {
					wp_enqueue_style( 'wc-sc-onboarding' );
				}
			}
		}

		/**
		 * Onboarding header
		 */
		public function onboarding_header() {
			?>
								<!-- App Header -->
								<div class="app-header">
									<div class="app-icon">
										<svg viewBox="0 0 21 19.7931" fill="none">
											<g clip-path="url(#clip0_5_111)">
												<path d="M20.6505 7.85954H18.3704L19.9247 3.06178C19.9401 3.01754 19.9465 2.97066 19.9435 2.92391C19.9405 2.87716 19.9282 2.83148 19.9073 2.78958C19.8864 2.74768 19.8574 2.7104 19.8219 2.67995C19.7864 2.64951 19.7451 2.6265 19.7006 2.61231L11.711 0.0165237C11.6672 0.00240461 11.6212 -0.00292759 11.5754 0.000832093C11.5296 0.00459178 11.485 0.0173693 11.4441 0.0384342C11.4032 0.0594991 11.3669 0.0884376 11.3372 0.123594C11.3075 0.158751 11.285 0.199435 11.271 0.243319L8.8038 7.85954H0.351576C0.258687 7.85954 0.169573 7.8964 0.103698 7.96207C0.0378236 8.02775 0.000543209 8.1169 0 8.21004V19.4426C0.000543209 19.5358 0.0378236 19.6249 0.103698 19.6906C0.169573 19.7563 0.258687 19.7931 0.351576 19.7931H20.6505C20.7432 19.7931 20.8321 19.7562 20.8976 19.6905C20.9632 19.6247 21 19.5356 21 19.4426V8.21004C21 8.11708 20.9632 8.02793 20.8976 7.9622C20.8321 7.89647 20.7432 7.85954 20.6505 7.85954ZM11.8282 0.793815L19.1517 3.1793L17.6343 7.85954H16.9024L17.7248 5.29262C17.7389 5.24876 17.7442 5.20255 17.7404 5.15662C17.7367 5.1107 17.7239 5.06597 17.7029 5.02499C17.6819 4.984 17.6531 4.94758 17.618 4.91779C17.583 4.88801 17.5424 4.86545 17.4986 4.8514C17.2346 4.76363 17.0157 4.575 16.8894 4.32643C16.7632 4.07786 16.7398 3.78939 16.8243 3.52361C16.8528 3.4353 16.8452 3.33925 16.8032 3.25653C16.7612 3.17381 16.6882 3.11119 16.6002 3.08239L13.9274 2.21438C13.839 2.18571 13.7429 2.19326 13.6601 2.23536C13.5773 2.27746 13.5145 2.35071 13.4853 2.43912C13.4003 2.70316 13.2149 2.92292 12.9693 3.0507C12.7237 3.17847 12.4378 3.20394 12.1736 3.12157C12.0852 3.0929 11.9892 3.10044 11.9064 3.14254C11.8235 3.18465 11.7607 3.2579 11.7315 3.3463L10.2738 7.85954H9.53779L11.8282 0.793815ZM14.6285 7.85954L13.2818 5.4019L13.0392 5.53591L14.3118 7.85954H11.0099L12.3052 3.86381C12.646 3.90246 12.9906 3.83982 13.2962 3.68366C13.6018 3.5275 13.8549 3.28472 14.024 2.98549L16.08 3.65763C16.0421 3.99961 16.1048 4.34523 16.2605 4.65188C16.4161 4.95853 16.6578 5.2128 16.9558 5.38334L16.154 7.85748L14.6285 7.85954ZM10.5288 14.1768H8.06158C7.96228 14.0446 7.84537 13.9267 7.71412 13.8263C7.84537 13.726 7.96228 13.608 8.06158 13.4758H10.5288C10.5288 13.5913 10.5103 13.7068 10.5103 13.8263C10.5103 13.9459 10.5103 14.0614 10.5288 14.1768ZM7.71001 12.4223C7.71001 12.7013 7.5996 12.969 7.40301 13.1665C7.20643 13.364 6.93973 13.4753 6.66144 13.4758H5.59438V12.4223C5.59546 12.1432 5.7065 11.8758 5.90329 11.6785C6.10009 11.4811 6.36669 11.3698 6.645 11.3687H7.69356L7.71001 12.4223ZM4.90151 8.56261H5.59438V11.0223C5.46304 11.1217 5.34549 11.2382 5.24486 11.3687C5.14423 11.2382 5.02668 11.1217 4.89534 11.0223L4.90151 8.56261ZM4.90151 12.4223V13.4758H3.85089C3.57258 13.4747 3.30598 13.3634 3.10919 13.1661C2.91239 12.9687 2.80136 12.7014 2.80027 12.4223V11.3687H3.85089C4.1292 11.3698 4.3958 11.4811 4.59259 11.6785C4.78939 11.8758 4.90042 12.1432 4.90151 12.4223ZM0.701097 8.56261H4.1963V10.7069C4.08166 10.6805 3.96439 10.6674 3.84678 10.6677H2.45075C2.35805 10.6677 2.26915 10.7046 2.20361 10.7703C2.13806 10.8361 2.10123 10.9252 2.10123 11.0182V12.4223C2.1009 12.5402 2.11401 12.6578 2.1403 12.7728H0.701097V8.56261ZM0.701097 13.4758H2.45487C2.55395 13.6075 2.67011 13.7254 2.80027 13.8263C2.67011 13.9273 2.55395 14.0451 2.45487 14.1768H0.701097V13.4758ZM4.1963 19.0921H0.701097V14.8799H2.1403C2.11401 14.9949 2.1009 15.1125 2.10123 15.2304V16.6324C2.10123 16.7254 2.13806 16.8145 2.20361 16.8803C2.26915 16.946 2.35805 16.9829 2.45075 16.9829H3.85089C3.96851 16.9833 4.08577 16.9701 4.20041 16.9438L4.1963 19.0921ZM3.84678 16.284H2.80027V15.2304C2.80136 14.9513 2.91239 14.684 3.10919 14.4866C3.30598 14.2893 3.57258 14.1779 3.85089 14.1768H4.90151V15.2304C4.90042 15.5095 4.78939 15.7768 4.59259 15.9742C4.3958 16.1715 4.1292 16.2829 3.85089 16.284H3.84678ZM5.59438 19.0921H4.89534V16.6324C5.02668 16.5331 5.14423 16.4166 5.24486 16.286C5.34549 16.4166 5.46304 16.5331 5.59438 16.6324V19.0921ZM5.59438 15.2304V14.1768H6.645C6.92328 14.1774 7.18998 14.2886 7.38657 14.4862C7.58315 14.6837 7.69356 14.9513 7.69356 15.2304V16.284H6.645C6.36669 16.2829 6.10009 16.1715 5.90329 15.9742C5.7065 15.7768 5.59546 15.5095 5.59438 15.2304ZM20.2948 19.0921H6.30164V16.9458C6.41626 16.9723 6.53354 16.9854 6.65116 16.985H8.06158C8.15428 16.985 8.24318 16.9481 8.30873 16.8823C8.37428 16.8166 8.4111 16.7274 8.4111 16.6345V15.2304C8.41143 15.1125 8.39833 14.9949 8.37204 14.8799H10.6336C10.8719 15.8757 11.4375 16.7621 12.2394 17.3962C13.0414 18.0303 14.0328 18.3751 15.054 18.3751C16.0753 18.3751 17.0667 18.0303 17.8686 17.3962C18.6706 16.7621 19.2362 15.8757 19.4744 14.8799H20.2968L20.2948 19.0921ZM11.2011 13.8263C11.2011 13.0626 11.4269 12.3159 11.8501 11.6809C12.2732 11.0458 12.8747 10.5509 13.5783 10.2586C14.282 9.96629 15.0563 9.88982 15.8033 10.0388C16.5503 10.1878 17.2364 10.5556 17.775 11.0957C18.3135 11.6358 18.6803 12.3239 18.8289 13.073C18.9775 13.8221 18.9012 14.5985 18.6097 15.3042C18.3183 16.0098 17.8247 16.6129 17.1914 17.0372C16.5582 17.4616 15.8136 17.6881 15.052 17.6881C14.5462 17.6883 14.0453 17.5886 13.578 17.3946C13.1107 17.2007 12.686 16.9162 12.3284 16.5576C11.9708 16.1989 11.6871 15.7731 11.4937 15.3045C11.3002 14.8358 11.2008 14.3335 11.2011 13.8263ZM20.301 14.1768H19.5752C19.5752 14.0614 19.5916 13.9459 19.5916 13.8263C19.5916 13.7068 19.5814 13.5913 19.5752 13.4758H20.2927L20.301 14.1768ZM20.301 12.7728H19.4786C19.2403 11.7769 18.6747 10.8906 17.8728 10.2565C17.0708 9.6224 16.0794 9.27758 15.0582 9.27758C14.0369 9.27758 13.0455 9.6224 12.2436 10.2565C11.4416 10.8906 10.876 11.7769 10.6378 12.7728H8.37615C8.40244 12.6578 8.41555 12.5402 8.41521 12.4223V11.0182C8.41521 10.9252 8.37839 10.8361 8.31284 10.7703C8.24729 10.7046 8.15839 10.6677 8.06569 10.6677H6.65116C6.53354 10.6672 6.41626 10.6804 6.30164 10.7069V8.56261H20.301V12.7728Z" fill="#F17EB8"/>
												<path d="M15.052 15.5809C14.8666 15.5809 14.6888 15.507 14.5577 15.3756C14.4266 15.2441 14.3529 15.0658 14.3529 14.8799H13.6498C13.6512 15.1903 13.7551 15.4915 13.9451 15.7365C14.1352 15.9816 14.4007 16.1566 14.7004 16.2345V16.985H15.4015V16.2345C15.7302 16.1485 16.0165 15.9455 16.2068 15.6633C16.3972 15.3811 16.4785 15.0391 16.4357 14.7011C16.3929 14.3631 16.2288 14.0524 15.9742 13.8269C15.7195 13.6014 15.3917 13.4766 15.052 13.4758C14.9133 13.4758 14.7778 13.4346 14.6625 13.3573C14.5472 13.2801 14.4573 13.1703 14.4042 13.0418C14.3512 12.9133 14.3373 12.772 14.3643 12.6356C14.3914 12.4992 14.4582 12.3739 14.5562 12.2756C14.6543 12.1773 14.7792 12.1103 14.9152 12.0832C15.0512 12.0561 15.1922 12.07 15.3203 12.1232C15.4484 12.1764 15.5579 12.2665 15.6349 12.3821C15.712 12.4978 15.7531 12.6337 15.7531 12.7727H16.4521C16.4508 12.4626 16.3472 12.1616 16.1576 11.9166C15.9679 11.6716 15.7028 11.4964 15.4035 11.4182V10.6677H14.7004V11.4182C14.3715 11.5042 14.0851 11.7074 13.8948 11.9898C13.7045 12.2722 13.6233 12.6144 13.6663 12.9525C13.7094 13.2906 13.8739 13.6014 14.1289 13.8268C14.3839 14.0521 14.7121 14.1765 15.052 14.1768C15.1471 14.1716 15.2423 14.186 15.3317 14.2189C15.4211 14.2519 15.5029 14.3027 15.5721 14.3684C15.6412 14.4341 15.6963 14.5133 15.734 14.601C15.7716 14.6888 15.791 14.7833 15.791 14.8789C15.791 14.9744 15.7716 15.0689 15.734 15.1567C15.6963 15.2444 15.6412 15.3236 15.5721 15.3893C15.5029 15.455 15.4211 15.5058 15.3317 15.5388C15.2423 15.5717 15.1471 15.5861 15.052 15.5809Z" fill="#F17EB8"/>
												<path d="M15.0767 6.16679C14.9922 6.13159 14.8993 6.12217 14.8095 6.13971C14.7197 6.15725 14.6371 6.20097 14.572 6.26539C14.5069 6.32981 14.4622 6.41207 14.4435 6.50186C14.4248 6.59164 14.433 6.68497 14.4669 6.77013C14.5009 6.85529 14.5592 6.9285 14.6345 6.9806C14.7098 7.03269 14.7987 7.06134 14.8902 7.06296C14.9816 7.06459 15.0715 7.03911 15.1486 6.98972C15.2256 6.94033 15.2865 6.86923 15.3234 6.78533C15.3484 6.72856 15.3619 6.66736 15.363 6.60532C15.364 6.54327 15.3528 6.48163 15.3298 6.42402C15.3068 6.3664 15.2726 6.31397 15.2291 6.2698C15.1857 6.22563 15.1338 6.19061 15.0767 6.16679ZM15.0767 6.66987C15.062 6.70385 15.0376 6.73271 15.0066 6.75281C14.9756 6.77291 14.9393 6.78335 14.9024 6.78282C14.8654 6.78229 14.8295 6.77081 14.799 6.74983C14.7686 6.72884 14.7451 6.69929 14.7313 6.6649C14.7176 6.63051 14.7144 6.59282 14.722 6.55657C14.7296 6.52033 14.7477 6.48715 14.7741 6.46123C14.8005 6.4353 14.8339 6.41778 14.8702 6.41088C14.9065 6.40398 14.944 6.40801 14.978 6.42245C15.0225 6.44349 15.0569 6.48125 15.0738 6.52755C15.0908 6.57386 15.0888 6.62498 15.0685 6.66987H15.0767Z" fill="#F17EB8"/>
												<path d="M14.8957 7.11727C14.8248 7.11781 14.7547 7.10304 14.6901 7.07398C14.6269 7.04813 14.5696 7.0098 14.5216 6.96127C14.4736 6.91274 14.4358 6.85501 14.4104 6.79151C14.3718 6.69558 14.3625 6.59028 14.3836 6.48901C14.4048 6.38775 14.4555 6.29508 14.5294 6.22281C14.6032 6.15053 14.6968 6.10191 14.7983 6.08312C14.8998 6.06434 15.0045 6.07624 15.0992 6.11731C15.2254 6.17182 15.3252 6.27403 15.3767 6.40179C15.4283 6.52954 15.4276 6.67254 15.3747 6.79976C15.3205 6.9265 15.2185 7.02657 15.091 7.0781C15.0291 7.10412 14.9627 7.11744 14.8957 7.11727ZM14.8957 6.18535C14.8285 6.18528 14.7623 6.20173 14.7029 6.23324C14.6436 6.26475 14.5928 6.31037 14.555 6.36611C14.5173 6.42184 14.4938 6.48601 14.4865 6.55298C14.4792 6.61995 14.4884 6.68769 14.5132 6.75028C14.5545 6.85065 14.6335 6.93066 14.7332 6.97295C14.8339 7.01476 14.9471 7.01476 15.0478 6.97295C15.1487 6.93204 15.2293 6.85271 15.2719 6.75234C15.3136 6.65134 15.3136 6.53788 15.2719 6.43689C15.2298 6.33807 15.1508 6.25966 15.0519 6.21834C15.0032 6.19711 14.9508 6.18589 14.8977 6.18535H14.8957ZM14.8957 6.83893C14.8633 6.83878 14.8312 6.83249 14.8011 6.82038C14.7422 6.79419 14.6958 6.74616 14.6716 6.68636C14.6478 6.62674 14.6485 6.56012 14.6736 6.50103C14.6986 6.44194 14.7459 6.39517 14.8052 6.37091C14.8345 6.35866 14.866 6.35235 14.8977 6.35235C14.9295 6.35235 14.9609 6.35866 14.9902 6.37091C15.0494 6.39636 15.0962 6.44419 15.1205 6.50402C15.1447 6.56384 15.1445 6.63084 15.1198 6.69048C15.1074 6.72008 15.0892 6.74685 15.0662 6.76917C15.0433 6.7915 15.016 6.80892 14.9861 6.82038C14.9575 6.83263 14.9268 6.83894 14.8957 6.83893ZM14.8957 6.46163C14.8793 6.45874 14.8626 6.45874 14.8463 6.46163C14.8299 6.46783 14.815 6.47748 14.8026 6.48992C14.7902 6.50236 14.7805 6.51732 14.7744 6.53379C14.7677 6.5498 14.7643 6.56697 14.7643 6.5843C14.7643 6.60164 14.7677 6.6188 14.7744 6.63482C14.7809 6.65109 14.7906 6.66588 14.803 6.67828C14.8153 6.69068 14.8301 6.70045 14.8463 6.70698C14.8622 6.71409 14.8793 6.71776 14.8967 6.71776C14.914 6.71776 14.9312 6.71409 14.9471 6.70698C14.98 6.69327 15.0065 6.66746 15.0211 6.63482C15.0278 6.61857 15.0313 6.60115 15.0314 6.58355C15.0314 6.56595 15.028 6.54852 15.0213 6.53225C15.0146 6.51597 15.0048 6.50118 14.9924 6.48871C14.98 6.47624 14.9653 6.46634 14.9491 6.45957C14.9313 6.4569 14.9132 6.4576 14.8957 6.46163Z" fill="#F17EB8"/>
												<path d="M12.5539 6.90491C12.5188 6.98961 12.5094 7.08281 12.5269 7.17284C12.5444 7.26287 12.588 7.34572 12.6522 7.41101C12.7165 7.4763 12.7985 7.52113 12.888 7.53987C12.9776 7.55861 13.0706 7.55044 13.1555 7.51638C13.2405 7.48231 13.3135 7.42387 13.3654 7.34837C13.4174 7.27288 13.4459 7.18369 13.4476 7.09198C13.4492 7.00028 13.4238 6.91013 13.3745 6.83284C13.3253 6.75555 13.2544 6.69456 13.1707 6.6575C13.1141 6.63214 13.0531 6.61843 12.9911 6.61719C12.9292 6.61595 12.8676 6.6272 12.8101 6.65027C12.7525 6.67335 12.7002 6.70778 12.6562 6.75152C12.6122 6.79527 12.5774 6.84743 12.5539 6.90491ZM13.1542 7.16057C13.1446 7.18339 13.1306 7.20406 13.1129 7.2214C13.0953 7.23874 13.0744 7.25241 13.0514 7.26161C13.0285 7.27081 13.004 7.27536 12.9793 7.27501C12.9546 7.27465 12.9302 7.2694 12.9075 7.25954C12.8848 7.25009 12.8643 7.23621 12.847 7.21871C12.8297 7.20121 12.8161 7.18043 12.8069 7.1576C12.7977 7.13476 12.7932 7.11032 12.7935 7.0857C12.7938 7.06108 12.799 7.03677 12.8088 7.01419C12.8184 6.99144 12.8324 6.97081 12.8499 6.95348C12.8674 6.93615 12.8882 6.92245 12.911 6.91316C12.9338 6.90388 12.9583 6.89919 12.9829 6.89936C13.0075 6.89954 13.0318 6.90458 13.0545 6.91419C13.0772 6.9238 13.0978 6.9378 13.1151 6.95538C13.1323 6.97297 13.146 6.99379 13.1553 7.01667C13.1645 7.03955 13.1692 7.06403 13.169 7.08873C13.1689 7.11342 13.1638 7.13783 13.1542 7.16057Z" fill="#F17EB8"/>
												<path d="M12.9815 7.60798C12.911 7.60771 12.8412 7.59371 12.7759 7.56675C12.6648 7.52049 12.5731 7.43704 12.5165 7.3306C12.4598 7.22417 12.4417 7.10133 12.4652 6.98301C12.4888 6.86469 12.5524 6.75821 12.6455 6.68169C12.7385 6.60517 12.8551 6.56335 12.9754 6.56335C13.0957 6.56335 13.2123 6.60517 13.3053 6.68169C13.3983 6.75821 13.462 6.86469 13.4855 6.98301C13.509 7.10133 13.4909 7.22417 13.4343 7.3306C13.3776 7.43704 13.2859 7.52049 13.1748 7.56675C13.1137 7.5932 13.048 7.60722 12.9815 7.60798ZM12.9815 6.67606C12.9288 6.67647 12.8766 6.68624 12.8273 6.70492C12.7272 6.74628 12.6475 6.82555 12.6053 6.92553C12.5636 7.02653 12.5636 7.13999 12.6053 7.24098C12.6461 7.34213 12.7252 7.42294 12.8253 7.46572C12.926 7.50753 13.0391 7.50753 13.1398 7.46572C13.2399 7.42436 13.3197 7.34509 13.3619 7.24511C13.4038 7.14498 13.4047 7.0323 13.3643 6.93155C13.3238 6.83079 13.2454 6.7501 13.146 6.70698C13.0939 6.68548 13.0379 6.67495 12.9815 6.67606ZM12.9815 7.32964C12.9491 7.32964 12.917 7.32334 12.887 7.31108C12.8577 7.29883 12.8312 7.28084 12.8089 7.25819C12.7867 7.23553 12.7692 7.20865 12.7574 7.17913C12.7329 7.11902 12.7329 7.05162 12.7574 6.99151C12.7835 6.9325 12.8314 6.88594 12.8911 6.86162C12.9203 6.8489 12.9518 6.84235 12.9836 6.84235C13.0154 6.84235 13.0469 6.8489 13.0761 6.86162C13.1351 6.88783 13.1813 6.93633 13.2048 6.99656C13.2283 7.05679 13.2271 7.12389 13.2015 7.18325C13.1825 7.22605 13.1516 7.26252 13.1127 7.28844C13.0738 7.31436 13.0283 7.32864 12.9815 7.32964ZM12.9815 6.9544C12.9652 6.95142 12.9485 6.95142 12.9322 6.9544C12.8992 6.9681 12.8728 6.99392 12.8582 7.02656C12.8449 7.05963 12.8449 7.09657 12.8582 7.12965C12.8647 7.14593 12.8744 7.16071 12.8868 7.17311C12.8992 7.18551 12.9139 7.19528 12.9301 7.20181C12.9466 7.21117 12.9648 7.21694 12.9836 7.21873C13.0024 7.22051 13.0214 7.21828 13.0392 7.21218C13.0571 7.20607 13.0735 7.19624 13.0873 7.18332C13.1012 7.1704 13.1121 7.15469 13.1194 7.13722C13.1267 7.11976 13.1303 7.10093 13.1298 7.08199C13.1293 7.06306 13.1249 7.04443 13.1167 7.02735C13.1085 7.01027 13.0968 6.99512 13.0824 6.9829C13.068 6.97068 13.0511 6.96167 13.0329 6.95646C13.0162 6.95167 12.9986 6.95096 12.9815 6.9544Z" fill="#F17EB8"/>
											</g>
											<defs>
												<clipPath id="clip0_5_111">
													<rect fill="white" height="19.7931" width="21"/>
												</clipPath>
											</defs>
										</svg>
									</div>
									<div class="app-name"><?php echo esc_html_x( 'Smart Coupons', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></div>
								</div>
			<?php
		}

		/**
		 * Check icon
		 */
		public function check_icon() {
			?>
										<svg class="check-icon" viewBox="0 0 16 16" fill="none">
											<rect fill="#14AC19" height="16" rx="8" width="16"/>
											<path d="M7.15146 9.27279L10.8284 5.59584L11.3941 6.16153L7.15146 10.4042L4.60588 7.85859L5.17156 7.29291L7.15146 9.27279Z" fill="white"/>
										</svg>
			<?php
		}

		/**
		 * Navigation buttons
		 */
		public function navigation_buttons() {
			?>
							<!-- Navigation Buttons -->
							<div class="navigation-buttons">
								<button class="btn-previous">
									<svg class="arrow-icon" viewBox="0 0 20 20" fill="none">
										<path d="M5.88388 0.441942L0.883884 5.44194L5.88388 10.4419" stroke="#7F54B3" stroke-width="1.25" transform="translate(7, 4.5)"/>
									</svg>
									<span><?php echo esc_html_x( 'Previous', 'Text on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></span>
								</button>
								
								<button class="cta-button btn-next">
									<span><?php echo esc_html_x( 'Next', 'Next button on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></span>
									<svg class="arrow-icon" viewBox="0 0 20 20" fill="none">
										<path d="M5.88388 0.441942L0.883884 5.44194L5.88388 10.4419" stroke="white" stroke-width="1.25" transform="translate(7, 4.5) scale(-1, 1) translate(-13, 0)"/>
									</svg>
								</button>
							</div>
			<?php
		}

		/**
		 * Logo
		 */
		public function storeapps_logo() {
			?>
						<!-- StoreApps Logo -->
						<div class="storeapps-logo">
							<svg viewBox="0 0 124.728 40.5163" fill="none">
								<defs>
									<filter id="filter0_d_5_94" x="0" y="0" width="124.728" height="40.5163" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
										<feFlood flood-opacity="0" result="BackgroundImageFix"/>
										<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
										<feOffset dy="2"/>
										<feGaussianBlur stdDeviation="2"/>
										<feComposite in2="hardAlpha" operator="out"/>
										<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.06 0"/>
										<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_5_94"/>
										<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_5_94" result="shape"/>
									</filter>
								</defs>
								<g filter="url(#filter0_d_5_94)">
									<rect x="4" y="2" width="116.728" height="32.5163" rx="16.2581" fill="white"/>
									<rect x="4.5" y="2.5" width="115.728" height="31.5163" rx="15.7581" stroke="black" stroke-opacity="0.08"/>
									<path d="M38.5958 14.483L36.6965 11.1414V11.1178C36.493 10.7749 36.2032 10.4913 35.856 10.2951C35.5088 10.099 35.1162 9.99729 34.7175 10.0001H23.3303C22.9329 9.99825 22.542 10.1005 22.1964 10.2966C21.8507 10.4927 21.5625 10.7758 21.3602 11.1178L21.3454 11.1414L19.452 14.483C18.4935 16.1936 19.1305 18.494 20.6936 19.2254V26.1592C20.694 26.2072 20.704 26.2547 20.723 26.2988C20.7419 26.3429 20.7696 26.3827 20.8042 26.416C20.8388 26.4492 20.8798 26.4752 20.9246 26.4924C20.9694 26.5096 21.0172 26.5176 21.0652 26.5161H36.9914C37.0863 26.5161 37.1774 26.4786 37.2448 26.4117C37.3122 26.3449 37.3504 26.2541 37.3512 26.1592V19.2254C38.9202 18.494 39.5602 16.1936 38.5958 14.483ZM31.6827 19.252C31.8884 19.5538 32.0475 19.8849 32.1546 20.2341C32.2478 20.5712 32.2944 20.9195 32.2932 21.2693C32.2948 21.7022 32.2012 22.1301 32.0189 22.5227C31.8301 22.9213 31.5527 23.2713 31.2078 23.5461C30.8144 23.8621 30.3638 24.0994 29.8807 24.2451C29.4975 24.3667 29.1017 24.4439 28.7009 24.4752V24.4427C29.6064 24.2481 29.7981 23.0978 29.2701 22.505C29.2154 22.423 29.151 22.3477 29.0784 22.2809C28.9134 22.0859 28.7351 21.9026 28.5446 21.7323C28.2998 21.5052 27.9548 21.2221 27.5507 20.8829C26.8625 20.3426 26.2029 19.7667 25.5747 19.1576C25.2804 18.874 25.0027 18.5737 24.743 18.2581H27.2086C26.8958 17.9466 26.6161 17.6037 26.374 17.2347C26.1721 16.9318 26.0161 16.6009 25.9109 16.2525C25.8187 15.9153 25.7731 15.567 25.7752 15.2173C25.7735 14.7848 25.8661 14.357 26.0466 13.9639C26.2332 13.5706 26.5052 13.224 26.8429 12.9493C27.2371 12.6345 27.6874 12.3973 28.1701 12.2504C28.4685 12.1544 28.7758 12.0882 29.0873 12.0528H29.3586C28.4532 12.2474 28.2644 13.3976 28.7924 13.9904C28.8463 14.0732 28.9107 14.1485 28.9841 14.2146C29.0603 14.3097 29.142 14.4003 29.2289 14.4859C29.3144 14.5714 29.4088 14.6658 29.5238 14.7661C29.7715 14.9932 30.1136 15.2734 30.5206 15.6125C31.208 16.1528 31.8666 16.7287 32.4937 17.3379C32.7855 17.6273 33.0612 17.9325 33.3195 18.2522H30.8451C31.1576 18.556 31.4382 18.891 31.6827 19.252Z" fill="#5950EC"/>
									<path d="M49.5858 17.0637H48.0167C48.0167 16.7363 47.6304 16.291 46.9579 16.291C46.4861 16.291 45.908 16.5033 45.908 16.8808C45.908 17.1964 46.3415 17.3232 47.2647 17.565C48.2969 17.8334 49.7509 18.1814 49.7509 19.6295C49.7509 20.88 48.6538 21.6616 47.1202 21.6616C45.0557 21.6616 44.2122 20.2754 44.2122 19.252H45.7812C45.7812 19.252 45.908 20.2931 47.2086 20.2931C47.9106 20.2931 48.1701 19.9982 48.1701 19.7033C48.1701 19.2904 47.6215 19.1459 47.014 19.0013C46.0319 18.7684 44.3065 18.4115 44.3065 16.9368C44.3065 15.7424 45.4863 14.8546 46.9756 14.8546C48.6803 14.8753 49.5858 16.0403 49.5858 17.0637ZM56.378 16.4561H54.0569V21.5436H52.4584V16.4561H50.1343V14.9815H56.378V16.4561ZM63.3147 18.267C63.3129 18.9357 63.1131 19.5888 62.7403 20.144C62.3675 20.6991 61.8386 21.1313 61.2203 21.386C60.602 21.6407 59.9221 21.7064 59.2665 21.5749C58.6109 21.4433 58.0089 21.1205 57.5367 20.647C57.0645 20.1736 56.7432 19.5708 56.6134 18.9148C56.4836 18.2589 56.5511 17.5792 56.8074 16.9615C57.0637 16.3439 57.4973 15.8161 58.0534 15.4448C58.6095 15.0735 59.2632 14.8753 59.9319 14.8753C60.8296 14.8784 61.6896 15.237 62.3236 15.8727C62.9575 16.5083 63.3139 17.3692 63.3147 18.267ZM58.006 18.267C58.0042 18.6479 58.1155 19.0207 58.3256 19.3384C58.5358 19.6561 58.8354 19.9043 59.1867 20.0517C59.5379 20.1991 59.925 20.239 60.2989 20.1664C60.6728 20.0938 61.0168 19.9119 61.2874 19.6438C61.5579 19.3757 61.7429 19.0334 61.819 18.6602C61.895 18.287 61.8586 17.8996 61.7145 17.547C61.5703 17.1944 61.3249 16.8925 61.0092 16.6794C60.6934 16.4664 60.3216 16.3517 59.9407 16.3499C59.6871 16.3476 59.4354 16.3954 59.2003 16.4906C58.9652 16.5858 58.7512 16.7265 58.5706 16.9046C58.39 17.0827 58.2464 17.2948 58.1479 17.5286C58.0495 17.7624 57.9983 18.0133 57.9971 18.267H58.006ZM69.7471 17.4471C69.7624 17.8728 69.6622 18.2947 69.4571 18.668C69.252 19.0414 68.9496 19.3522 68.5821 19.5676L69.9299 21.5436H67.9775L66.9924 19.9156H65.8363V21.5436H64.2585V14.9903H67.426C68.7561 14.9903 69.7471 16.0226 69.7471 17.4471ZM65.8245 16.4561V18.4498H67.1841C67.4485 18.4498 67.7021 18.3448 67.889 18.1579C68.076 17.9709 68.181 17.7174 68.181 17.453C68.181 17.1886 68.076 16.935 67.889 16.7481C67.7021 16.5611 67.4485 16.4561 67.1841 16.4561H65.8245ZM75.9907 14.9903V16.465H72.5518V17.5916H75.4215V18.9601H72.5518V20.0867H75.9907V21.5613H70.9769V14.9903H75.9907ZM84.2458 20.5202H81.0871L80.6594 21.5436H78.9783L81.7802 14.9903H83.5497L86.3634 21.5436H84.6705L84.2458 20.5202ZM83.6972 19.2314L82.6767 16.7923L81.6356 19.2402L83.6972 19.2314ZM92.7899 17.5149C92.7899 18.8067 91.9729 20.0601 90.2948 20.0601H88.8702V21.5348H87.2806V14.9903H90.3066C91.9817 14.9903 92.7899 16.2438 92.7899 17.5149ZM88.8702 16.4561V18.6032H90.1237C90.2687 18.6152 90.4146 18.5951 90.551 18.5444C90.6874 18.4936 90.811 18.4135 90.9129 18.3096C91.0148 18.2057 91.0926 18.0806 91.1407 17.9433C91.1888 17.8059 91.2061 17.6597 91.1913 17.5149C91.2036 17.372 91.1844 17.2281 91.135 17.0935C91.0855 16.9588 91.0071 16.8367 90.9053 16.7357C90.8034 16.6347 90.6806 16.5573 90.5456 16.509C90.4105 16.4607 90.2665 16.4426 90.1237 16.4561H88.8702ZM99.3697 17.5149C99.3697 18.8067 98.5528 20.0601 96.8746 20.0601H95.4501V21.5348H93.8604V14.9903H96.8805C98.5616 14.9903 99.3697 16.2438 99.3697 17.5149ZM95.4501 16.4561V18.6032H96.7006C96.8454 18.6147 96.991 18.5943 97.127 18.5434C97.263 18.4924 97.3862 18.4122 97.4878 18.3084C97.5894 18.2045 97.6669 18.0796 97.7148 17.9425C97.7628 17.8054 97.78 17.6594 97.7653 17.5149C97.7777 17.3717 97.7584 17.2276 97.7088 17.0927C97.6592 16.9578 97.5805 16.8355 97.4783 16.7345C97.3761 16.6334 97.2529 16.5561 97.1175 16.508C96.9821 16.4599 96.8377 16.4422 96.6947 16.4561H95.4501ZM105.563 17.0637H103.994C103.994 16.7363 103.608 16.291 102.935 16.291C102.464 16.291 101.885 16.5033 101.885 16.8808C101.885 17.1964 102.319 17.3232 103.242 17.565C104.274 17.8334 105.728 18.1814 105.728 19.6295C105.728 20.88 104.631 21.6616 103.098 21.6616C101.048 21.6616 100.19 20.2754 100.19 19.252H101.759C101.759 19.252 101.885 20.2931 103.186 20.2931C103.888 20.2931 104.148 19.9982 104.148 19.7033C104.148 19.2904 103.599 19.1459 102.991 19.0013C102.009 18.7684 100.287 18.4115 100.287 16.9368C100.287 15.7424 101.467 14.8546 102.941 14.8546C104.658 14.8753 105.563 16.0403 105.563 17.0637Z" fill="#161E2E"/>
								</g>
							</svg>
						</div>
			<?php
		}

		/**
		 * Pagination control
		 *
		 * @param integer $screen_id The screen id.
		 */
		public function pagination_controls( $screen_id = null ) {
			?>
						<!-- Pagination Controls -->
						<div class="pagination-controls">
							<div class="pagination-dots">
								<?php
								for ( $i = 1; $i <= 6; $i++ ) {
									if ( $i === $screen_id ) {
										?>
										<div class="dot active"></div>
										<?php
									} else {
										?>
										<div class="dot"></div>
										<?php
									}
								}
								?>
							</div>
							
							<a href="<?php echo esc_url( add_query_arg( array( 'page' => 'sc-about' ), admin_url( 'admin.php' ) ) ); ?>" class="skip-link">
								<span><?php echo esc_html_x( 'Skip', 'Skip link on activation onboarding steps on admin side', 'woocommerce-smart-coupons' ); ?></span>
								<svg class="skip-icon" viewBox="0 0 16 16" fill="none">
									<path d="M5.3125 0.709991L9.28998 4.68747L5.3125 8.66494" stroke="#7F54B3" stroke-width="0.9375" transform="translate(3, 3)"/>
									<path d="M1.47766 0.709991L5.45514 4.68747L1.47766 8.66494" stroke="#7F54B3" stroke-width="0.9375" transform="translate(3, 3)"/>
								</svg>
							</a>
						</div>
			<?php
		}
	}

}

WC_SC_Admin_Welcome::get_instance();
