<?php
/**
 * BOGO preset wizard template.
 *
 * @package woocommerce-smart-coupons/templates/admin/presets
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$coupon_discount_types = ( ! empty( $coupon_discount_types ) && is_array( $coupon_discount_types ) ) ? $coupon_discount_types : array();
$is_wc_gte_30          = ( isset( $is_wc_gte_30 ) && is_bool( $is_wc_gte_30 ) ) ? $is_wc_gte_30 : false;
$is_allow_auto_apply   = ( isset( $is_allow_auto_apply ) ) ? $is_allow_auto_apply : true;

if ( empty( $coupon_discount_types ) ) {
	$coupon_discount_types = array(
		'percent'       => __( 'Percentage discount', 'woocommerce' ),
		'fixed_cart'    => __( 'Fixed cart discount', 'woocommerce' ),
		'fixed_product' => __( 'Fixed product discount', 'woocommerce' ),
	);
}
?>
<div class="sc-preset-template" data-sc-preset="bogo">
	<div class="sc-wizard-header">
		<h2><?php esc_html_e( 'Create BOGO Coupon', 'woocommerce-smart-coupons' ); ?></h2>
		<p><?php esc_html_e( 'Set up your offer in three simple steps.', 'woocommerce-smart-coupons' ); ?></p>
	</div>

	<div class="sc-stepper" id="scWizardStepper">
		<div class="sc-stepper-item is-active" data-step="1">
			<div class="sc-stepper-dot">1</div>
			<span><?php esc_html_e( 'Buy Product', 'woocommerce-smart-coupons' ); ?></span>
		</div>
		<div class="sc-stepper-line"></div>
		<div class="sc-stepper-item" data-step="2">
			<div class="sc-stepper-dot">2</div>
			<span><?php esc_html_e( 'Products Customer Gets', 'woocommerce-smart-coupons' ); ?></span>
		</div>
		<div class="sc-stepper-line"></div>
		<div class="sc-stepper-item" data-step="3">
			<div class="sc-stepper-dot">3</div>
			<span><?php esc_html_e( 'Additional settings', 'woocommerce-smart-coupons' ); ?></span>
		</div>
	</div>

	<div class="sc-wizard-body">
		<div class="sc-step-panel" data-step="3">
			<div class="sc-field-grid sc-grid-3">
				<div class="sc-field">
					<label for="sc_bogo_code"><?php esc_html_e( 'Coupon Code', 'woocommerce-smart-coupons' ); ?></label>
					<input type="text" id="sc_bogo_code" class="regular-text" placeholder="<?php echo esc_attr__( 'Leave empty to auto generate', 'woocommerce-smart-coupons' ); ?>">
				</div>
				<div class="sc-field">
					<label for="sc_bogo_discount_type"><?php esc_html_e( 'Discount Type', 'woocommerce-smart-coupons' ); ?></label>
					<select id="sc_bogo_discount_type">
						<?php if ( ! empty( $coupon_discount_types ) ) { ?>
							<?php foreach ( $coupon_discount_types as $discount_key => $discount_label ) { ?>
								<option value="<?php echo esc_attr( $discount_key ); ?>" <?php selected( 'fixed_cart', $discount_key ); ?>>
									<?php echo esc_html( $discount_label ); ?>
								</option>
							<?php } ?>
						<?php } ?>
					</select>
				</div>
				<div class="sc-field">
					<label for="sc_bogo_amount"><?php esc_html_e( 'Amount', 'woocommerce-smart-coupons' ); ?></label>
					<input type="number" id="sc_bogo_amount" class="small-text" min="0">
				</div>
				<?php if ( true === $is_allow_auto_apply ) { ?>
					<div class="sc-field sc-full-width sc-auto-apply-row" id="sc_auto_apply_row">
						<label for="wc_sc_auto_apply_coupon" class="sc-auto-apply-title"><?php esc_html_e( 'Auto apply?', 'woocommerce-smart-coupons' ); ?></label>
						<label class="sc-auto-apply-option">
							<input type="checkbox" id="wc_sc_auto_apply_coupon" value="yes">
							<span>
								<?php esc_html_e( 'This coupon will automatically apply to the cart when its conditions are met.', 'woocommerce-smart-coupons' ); ?>
							</span>
						</label>
					</div>
				<?php } ?>
			</div>
		</div>

		<div class="sc-step-panel is-active" data-step="1">
			<div class="sc-field-grid sc-grid-2 sc-buy-step-grid">
				<div class="sc-field sc-full-width sc-buy-product-field">
					<label for="sc_buy_product_id"><?php esc_html_e( 'Buy Product', 'woocommerce-smart-coupons' ); ?> 
						<button
								type="button"
								class="sc-product-qty-restrictions__tooltip"
								aria-label="<?php echo esc_attr__( 'When multiple products are selected, the offer applies if any one product meets the quantity requirement.', 'woocommerce-smart-coupons' ); ?>"
								data-tooltip="<?php echo esc_attr__( 'When multiple products are selected, the offer applies if any one product meets the quantity requirement.', 'woocommerce-smart-coupons' ); ?>"
						>
								<span aria-hidden="true">?</span>
						</button>
					</label>
					<?php if ( true === $is_wc_gte_30 ) { ?>
						<select class="sc-preset-product-search select2_search_products_coupons" style="width: 100%;" multiple="multiple" id="sc_buy_product_id" name="sc_buy_product_id[]" data-placeholder="<?php echo esc_attr__( 'Search for a product&hellip;', 'woocommerce-smart-coupons' ); ?>" data-action="wc_sc_json_search_products_and_variations" data-security="<?php echo esc_attr( wp_create_nonce( 'search-products' ) ); ?>">
						</select>
					<?php } else { ?>
						<input type="hidden" class="sc-preset-product-search select2_search_products_coupons" style="width: 100%;" id="sc_buy_product_id" name="sc_buy_product_id[]" data-placeholder="<?php echo esc_attr__( 'Search for a product&hellip;', 'woocommerce-smart-coupons' ); ?>" data-action="wc_sc_json_search_products_and_variations" data-multiple="true" data-security="<?php echo esc_attr( wp_create_nonce( 'search-products' ) ); ?>"/>
					<?php } ?>
				</div>
				<div class="sc-field sc-full-width sc-product-qty-restrictions" id="sc_product_qty_restrictions_field" style="display:none;">
					<label class="sc-product-qty-restrictions__label">
						<span><?php esc_html_e( 'Buy Product Quantity Restrictions', 'woocommerce-smart-coupons' ); ?></span>
						
					</label>
					<div id="sc_product_qty_restrictions_rows" class="sc-product-qty-restrictions__rows"></div>
				</div>

			</div>
		</div>

		<div class="sc-step-panel" data-step="2">
			<div class="sc-field-grid sc-grid-2">
				<div class="sc-field">
					<label for="sc_product_id"><?php esc_html_e( 'Products Customer Gets', 'woocommerce-smart-coupons' ); ?></label>
					<?php if ( true === $is_wc_gte_30 ) { ?>
						<select class="sc-preset-product-search select2_search_products_coupons" style="width: 100%;" multiple="multiple" id="sc_product_id" name="sc_product_id[]" data-placeholder="<?php echo esc_attr__( 'Search for a product&hellip;', 'woocommerce-smart-coupons' ); ?>" data-action="wc_sc_json_search_products_and_variations" data-security="<?php echo esc_attr( wp_create_nonce( 'search-products' ) ); ?>">
						</select>
					<?php } else { ?>
						<input type="hidden" class="sc-preset-product-search select2_search_products_coupons" style="width: 100%;" id="sc_product_id" name="sc_product_id[]" data-placeholder="<?php echo esc_attr__( 'Search for a product&hellip;', 'woocommerce-smart-coupons' ); ?>" data-action="wc_sc_json_search_products_and_variations" data-multiple="true" data-security="<?php echo esc_attr( wp_create_nonce( 'search-products' ) ); ?>"/>
					<?php } ?>
				</div>
				<div class="sc-field">
					<label for="sc_quantity"><?php esc_html_e( 'Quantity per Product', 'woocommerce-smart-coupons' ); ?></label>
					<input type="number" id="sc_quantity" class="small-text" value="1" min="1">
				</div>
				<div class="sc-field">
					<label for="sc_discount_amount"><?php esc_html_e( 'Discount Amount', 'woocommerce-smart-coupons' ); ?></label>
					<input type="number" id="sc_discount_amount" class="small-text" min="0">
				</div>
				<div class="sc-field">
					<label for="sc_discount_type"><?php esc_html_e( 'Discount Type', 'woocommerce-smart-coupons' ); ?></label>
					<select id="sc_discount_type">
						<option value="percent"><?php esc_html_e( '%', 'woocommerce-smart-coupons' ); ?></option>
						<option value="flat"><?php esc_html_e( '$', 'woocommerce-smart-coupons' ); ?></option>
					</select>
				</div>
				<div class="sc-field sc-checkbox-field">
					<label for="wc_sc_no_of_selectable_product" class="sc-checkbox-title"><?php esc_html_e( 'Allow Users choose only one gift product', 'woocommerce-smart-coupons' ); ?></label>
					<label class="sc-checkbox-option" style="width: max-content;"><input type="checkbox" id="wc_sc_no_of_selectable_product" value="yes"> <?php esc_html_e( 'Allow customers to select one when multiple products are offered.', 'woocommerce-smart-coupons' ); ?></label>
				</div>
				<div class="sc-field sc-full-width">
					<label for="wc_coupon_message"><?php esc_html_e( 'Message Shown to Customer', 'woocommerce-smart-coupons' ); ?></label>
					<textarea id="wc_coupon_message" class="large-text" rows="3"></textarea>
				</div>
				<div class="sc-field sc-full-width sc-checkbox-field">
					<label class="sc-checkbox-option"><input type="checkbox" id="wc_email_message" value="yes"> <?php esc_html_e( 'Include this message in order confirmation email.', 'woocommerce-smart-coupons' ); ?></label>
				</div>
			</div>
		</div>
	</div>
</div>
