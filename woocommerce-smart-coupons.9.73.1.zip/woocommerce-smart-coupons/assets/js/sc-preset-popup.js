document.addEventListener('DOMContentLoaded', function () {
	const modal = document.getElementById('scBogoModal') || document.getElementById('scCouponPresetModal');
	const modalBody = document.getElementById('scPresetModalBody') || (modal ? modal.querySelector('.sc-modal-content') : null);
	const templateRoot = document.getElementById('scPresetTemplates');
	const resultBox = document.getElementById('scBogoResult') || document.getElementById('scPresetResult');
	const prevButton = document.getElementById('scStepPrev');
	const nextButton = document.getElementById('scStepNext');
	const generateButton = document.getElementById('scGenerateBogo');

	if (!modal || !modalBody || !resultBox || !prevButton || !nextButton || !generateButton) {
		return;
	}

	let currentPreset = 'bogo';
	let currentStep = 1;
	let totalSteps = 1;
	let isGenerating = false;
	let resultHighlightTimer = null;

	document.addEventListener('click', function (event) {
		const trigger = getClosest(event.target, '[data-sc-open-preset]');

		if (trigger || event.target.id === 'scOpenBogoPopup') {
			const presetKey = trigger ? String(trigger.getAttribute('data-sc-preset') || '').trim() : 'bogo';
			openModal(presetKey || 'bogo');
			return;
		}

		if (event.target.classList.contains('sc-close')) {
			closeModal();
			return;
		}

		if (event.target.id === 'scStepNext') {
			goNext();
			return;
		}

		if (event.target.id === 'scStepPrev') {
			goPrevious();
			return;
		}

		if (event.target.id === 'scGenerateBogo') {
			handleGenerate();
		}
	});

	window.addEventListener('click', function (event) {
		if (event.target === modal) {
			closeModal();
		}
	});

	function openModal(presetKey) {
		currentPreset = presetKey;
		loadPresetTemplate(currentPreset);
		currentStep = 1;
		updateWizard();
		resetResultState();
		document.body.classList.add('sc-preset-popup-open');
		document.documentElement.classList.add('sc-preset-popup-open');
		modal.style.display = 'block';
	}

	// Allow external UI triggers (for example, preset dropdowns) to open the modal reliably.
	window.scOpenPresetModal = openModal;

	function closeModal() {
		document.body.classList.remove('sc-preset-popup-open');
		document.documentElement.classList.remove('sc-preset-popup-open');
		modal.style.display = 'none';
	}

	function loadPresetTemplate(presetKey) {
		if (!templateRoot) {
			return;
		}

		const templateNode = templateRoot.querySelector('[data-sc-preset-template="' + escapeSelectorValue(presetKey) + '"]');

		if (!templateNode) {
			showError(getI18nValue('coupon_failed', 'Coupon creation failed.'));
			return;
		}

		modalBody.innerHTML = templateNode.innerHTML;

		const stepPanels = Array.from(modalBody.querySelectorAll('.sc-step-panel'));
		totalSteps = stepPanels.length > 0 ? stepPanels.length : 1;

		initProductSearchFields(modalBody);
		initAutoApplyVisibility(modalBody);
		initBuyProductQuantityRestrictions(modalBody);
	}

	function goNext() {
		if (!validateStep(currentStep)) {
			return;
		}

		if (currentStep < totalSteps) {
			currentStep += 1;
			resetResultState();
			updateWizard();
		}
	}

	function goPrevious() {
		if (currentStep > 1) {
			currentStep -= 1;
			resetResultState();
			updateWizard();
		}
	}

	function updateWizard() {
		const stepPanels = Array.from(modalBody.querySelectorAll('.sc-step-panel'));
		const stepItems = Array.from(modalBody.querySelectorAll('.sc-stepper-item'));

		stepPanels.forEach(function (panel) {
			const step = parseInt(panel.getAttribute('data-step'), 10);
			panel.classList.toggle('is-active', step === currentStep);
		});

		stepItems.forEach(function (item) {
			const step = parseInt(item.getAttribute('data-step'), 10);
			item.classList.toggle('is-active', step === currentStep);
			item.classList.toggle('is-done', step < currentStep);
		});

		prevButton.style.visibility = currentStep === 1 ? 'hidden' : 'visible';
		nextButton.style.display = currentStep === totalSteps ? 'none' : 'inline-flex';
		generateButton.style.display = currentStep === totalSteps ? 'inline-flex' : 'none';
	}

	function validateStep(step) {
		if ('bogo' !== currentPreset) {
			return true;
		}

		if (1 === step) {
			const buyProductField = modalBody.querySelector('#sc_buy_product_id');
			if (!buyProductField || getSelectedValues(buyProductField).length < 1) {
				showError(getI18nValue('select_buy_product', 'Please select at least one buy product.'));
				return false;
			}
		}

		if (2 === step) {
			const getProductField = modalBody.querySelector('#sc_product_id');
			if (!getProductField || getSelectedValues(getProductField).length < 1) {
				showError(getI18nValue('select_get_product', 'Please select at least one get product.'));
				return false;
			}
		}

		if (3 === step) {
			const amountField = modalBody.querySelector('#sc_bogo_amount');

			if (!amountField || Number(amountField.value) < 0) {
				showError(getI18nValue('valid_coupon_amount', 'Please enter a valid coupon amount.'));
				return false;
			}
		}

		return true;
	}

	function handleGenerate() {
		if (isGenerating || !validateStep(totalSteps)) {
			return;
		}

		isGenerating = true;
		generateButton.disabled = true;
		generateButton.textContent = getI18nValue('generate_in_progress', 'Generating...');
		resultBox.innerHTML = escapeHtml(getI18nValue('generating_coupon', 'Generating coupon...'));
		resultBox.className = 'sc-bogo-result is-info';

		const discountTypeField = modalBody.querySelector('#sc_bogo_discount_type');
		const amountField = modalBody.querySelector('#sc_bogo_amount');
		const codeField = modalBody.querySelector('#sc_bogo_code');

		createCouponWithPreset(
			{
				code: codeField ? String(codeField.value).trim() : '',
				discount_type: discountTypeField ? discountTypeField.value : '',
				amount: amountField ? amountField.value : ''
			},
			function () {
				return buildPresetPayload(currentPreset, modalBody);
			}
		)
			.then(function (response) {
				resultBox.className = 'sc-bogo-result is-success';
				resultBox.innerHTML =
					'<p><strong>' +
					escapeHtml(getI18nValue('coupon_created', 'Coupon Created:')) +
					'</strong> <span class="sc-bogo-result__code">' +
					escapeHtml(response.code || '') +
					'</span>' +
					'</p>';
				highlightGeneratedCoupon();
			})
			.catch(function (error) {
				showError(error && error.message ? error.message : getI18nValue('coupon_failed', 'Coupon creation failed.'));
			})
			.finally(function () {
				isGenerating = false;
				generateButton.disabled = false;
				generateButton.textContent = getI18nValue('generate_button', 'Generate coupon');
			});
	}

	function showError(message) {
		resultBox.className = 'sc-bogo-result is-error';
		resultBox.innerHTML = '<p>' + escapeHtml(message) + '</p>';
	}

	function resetResultState() {
		if (resultHighlightTimer) {
			window.clearTimeout(resultHighlightTimer);
			resultHighlightTimer = null;
		}
		resultBox.className = 'sc-bogo-result';
		resultBox.innerHTML = '';
	}

	function highlightGeneratedCoupon() {
		resultBox.classList.add('is-highlighted');
		resultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

		if (resultHighlightTimer) {
			window.clearTimeout(resultHighlightTimer);
		}

		resultHighlightTimer = window.setTimeout(function () {
			resultBox.classList.remove('is-highlighted');
			resultHighlightTimer = null;
		}, 2600);
	}

	function getI18nValue(key, fallback) {
		if (window.scPresetData && window.scPresetData.i18n && window.scPresetData.i18n[key]) {
			return String(window.scPresetData.i18n[key]);
		}

		if (window.scBogoData && window.scBogoData.i18n && window.scBogoData.i18n[key]) {
			return String(window.scBogoData.i18n[key]);
		}

		return fallback;
	}

	function initProductSearchFields(scopeNode) {
		if (!window.jQuery) {
			return;
		}

		const $ = window.jQuery;
		const $scope = scopeNode ? $(scopeNode) : $(document);
		const $fields = $scope.find('.select2_search_products_coupons');

		if ($fields.length < 1) {
			return;
		}

		$fields.each(function () {
			const $field = $(this);
			const fieldElement = $field.get(0);
			if ($field.data('select2') || $field.data('selectWoo')) {
				return;
			}

			if (fieldElement && fieldElement.style && 'none' === fieldElement.style.display) {
				fieldElement.style.display = '';
			}

			$field.removeClass('select2-hidden-accessible');
			$field.removeAttr('data-select2-id');
			$field.removeAttr('aria-hidden');
			$field.removeAttr('tabindex');
			$field.next('.select2, .select2-container').remove();

			const selectArgs = {
				allowClear: !!$field.data('allow_clear'),
				placeholder: $field.data('placeholder') || '',
				minimumInputLength: parseInt($field.data('minimum_input_length'), 10) || 3,
				dropdownParent: $(modal),
				escapeMarkup: function (markup) {
					return markup;
				},
				ajax: {
					url: (window.wc_enhanced_select_params && window.wc_enhanced_select_params.ajax_url) || window.ajaxurl,
					dataType: 'json',
					delay: 250,
					data: function (params) {
						return {
							term: params.term,
							action: $field.data('action') || 'woocommerce_json_search_products_and_variations',
							security: $field.data('security') || ''
						};
					},
					processResults: function (data) {
						const terms = [];
						if (data) {
							Object.keys(data).forEach(function (id) {
								terms.push({ id: id, text: data[id] });
							});
						}
						return { results: terms };
					},
					cache: true
				}
			};

			if (true === $field.data('multiple') || $field.prop('multiple')) {
				selectArgs.multiple = true;
			}

			if (window.wc_enhanced_select_params) {
				selectArgs.language = {
					noResults: function () {
						return window.wc_enhanced_select_params.i18n_no_matches;
					},
					errorLoading: function () {
						return window.wc_enhanced_select_params.i18n_ajax_error;
					},
					inputTooShort: function (args) {
						const remainingChars = args.minimum - args.input.length;
						if (1 === remainingChars) {
							return window.wc_enhanced_select_params.i18n_input_too_short_1;
						}
						return window.wc_enhanced_select_params.i18n_input_too_short_n.replace('%qty%', remainingChars);
					},
					inputTooLong: function (args) {
						const overChars = args.input.length - args.maximum;
						if (1 === overChars) {
							return window.wc_enhanced_select_params.i18n_input_too_long_1;
						}
						return window.wc_enhanced_select_params.i18n_input_too_long_n.replace('%qty%', overChars);
					},
					maximumSelected: function (args) {
						if (1 === args.maximum) {
							return window.wc_enhanced_select_params.i18n_selection_too_long_1;
						}
						return window.wc_enhanced_select_params.i18n_selection_too_long_n.replace('%qty%', args.maximum);
					},
					loadingMore: function () {
						return window.wc_enhanced_select_params.i18n_load_more;
					},
					searching: function () {
						return window.wc_enhanced_select_params.i18n_searching;
					}
				};
			}

			if ('function' === typeof $field.selectWoo) {
				$field.selectWoo(selectArgs);
			} else if ('function' === typeof $field.select2) {
				$field.select2(selectArgs);
			} else {
				return;
			}
		});
	}

	function getClosest(element, selector) {
		if (!element) {
			return null;
		}

		if ('function' === typeof element.closest) {
			return element.closest(selector);
		}

		if (window.jQuery && element.nodeType) {
			const matched = window.jQuery(element).closest(selector);
			return matched.length > 0 ? matched.get(0) : null;
		}

		return null;
	}

	function initAutoApplyVisibility(scopeNode) {
		const root = scopeNode || modalBody;
		if (!root) {
			return;
		}

		const discountTypeField = root.querySelector('#sc_bogo_discount_type');
		const autoApplyRow = root.querySelector('#sc_auto_apply_row');
		const autoApplyField = root.querySelector('#wc_sc_auto_apply_coupon');

		if (!discountTypeField || !autoApplyRow || !autoApplyField) {
			return;
		}

		const toggleAutoApply = function () {
			const isSmartCoupon = 'smart_coupon' === String(discountTypeField.value || '').trim();

			if (isSmartCoupon) {
				autoApplyRow.style.display = 'none';
				autoApplyField.checked = false;
				return;
			}

			autoApplyRow.style.display = '';
		};

		discountTypeField.addEventListener('change', toggleAutoApply);
		toggleAutoApply();
	}

	function initBuyProductQuantityRestrictions(scopeNode) {
		const root = scopeNode || modalBody;
		if (!root) {
			return;
		}

		const buyProductField = root.querySelector('#sc_buy_product_id');
		let wrapper = root.querySelector('#sc_product_qty_restrictions_field');
		let rowsContainer = root.querySelector('#sc_product_qty_restrictions_rows');

		if (!buyProductField) {
			return;
		}

		// Fallback: build the restrictions UI from JS in case older cached template markup is loaded.
		if (!wrapper || !rowsContainer) {
			const buyProductFieldWrapper = buyProductField.closest('.sc-field');
			if (!buyProductFieldWrapper || !buyProductFieldWrapper.parentNode) {
				return;
			}

			wrapper = document.createElement('div');
			wrapper.className = 'sc-field sc-full-width sc-product-qty-restrictions';
			wrapper.id = 'sc_product_qty_restrictions_field';
			wrapper.style.display = 'none';
			wrapper.innerHTML =
				'<label class="sc-product-qty-restrictions__label">' +
				'<span>Buy Product Quantity Restrictions</span>' +
				'<button type="button" class="sc-product-qty-restrictions__tooltip" aria-label="OR: The offer will apply if any one of the selected products meets the quantity condition." data-tooltip="OR: The offer will apply if any one of the selected products meets the quantity condition.">' +
				'<span aria-hidden="true">?</span>' +
				'</button>' +
				'</label>' +
				'<div class="sc-product-qty-restrictions__head">' +
				'<span>Product</span><span>Min</span><span>Max</span>' +
				'</div>' +
				'<div id="sc_product_qty_restrictions_rows" class="sc-product-qty-restrictions__rows"></div>';

			buyProductFieldWrapper.parentNode.appendChild(wrapper);
			rowsContainer = wrapper.querySelector('#sc_product_qty_restrictions_rows');
		}

		const getSelectedProductIds = function () {
			const ids = [];

			getSelectedValues(buyProductField).forEach(function (id) {
				if (ids.indexOf(id) < 0) {
					ids.push(id);
				}
			});

			if (window.jQuery) {
				try {
					const $field = window.jQuery(buyProductField);
					const selectedData = $field.select2 ? $field.select2('data') : [];
					if (Array.isArray(selectedData)) {
						selectedData.forEach(function (item) {
							if (!item || typeof item.id === 'undefined') {
								return;
							}
							const id = String(item.id).trim();
							if ('' !== id && ids.indexOf(id) < 0) {
								ids.push(id);
							}
						});
					}
				} catch (e) {
					// Ignore Select2 access issues and continue with available values.
				}
			}

			return ids;
		};

		const getSelectedProductMap = function () {
			const map = {};
			const selectedIds = getSelectedProductIds();

			if (buyProductField.selectedOptions && buyProductField.selectedOptions.length > 0) {
				Array.from(buyProductField.selectedOptions).forEach(function (option) {
					const id = String(option.value || '').trim();
					if ('' !== id) {
						map[id] = String(option.text || option.innerText || '').trim();
					}
				});
			}

			if (window.jQuery) {
				try {
					const $field = window.jQuery(buyProductField);
					const selectedData = $field.select2 ? $field.select2('data') : [];
					if (Array.isArray(selectedData)) {
						selectedData.forEach(function (item) {
							if (!item || typeof item.id === 'undefined') {
								return;
							}

							const id = String(item.id).trim();
							if ('' !== id && !map[id]) {
								map[id] = String(item.text || '').trim();
							}
						});
					}
				} catch (e) {
					// Ignore select2 access errors and use fallback product labels.
				}
			}

			selectedIds.forEach(function (id) {
				if (!map[id]) {
					map[id] = 'Product #' + id;
				}
			});

			return map;
		};

		const readExistingValues = function () {
			const values = {};
			const existingRows = Array.from(rowsContainer.querySelectorAll('.sc-product-qty-row'));

			existingRows.forEach(function (row) {
				const productId = String(row.getAttribute('data-product-id') || '').trim();
				if ('' === productId) {
					return;
				}

				const minField = row.querySelector('.sc-product-qty-min');
				const maxField = row.querySelector('.sc-product-qty-max');

				values[productId] = {
					min: minField ? String(minField.value || '').trim() : '',
					max: maxField ? String(maxField.value || '').trim() : ''
				};
			});

			return values;
		};

		const renderRows = function () {
			const selectedIds = getSelectedProductIds();
			const labelsById = getSelectedProductMap();
			const existingValues = readExistingValues();

			rowsContainer.innerHTML = '';

			if (selectedIds.length < 1) {
				wrapper.style.display = 'none';
				return;
			}

			selectedIds.forEach(function (productId, index) {
				const row = document.createElement('div');
				row.className = 'sc-product-qty-row';
				row.setAttribute('data-product-id', productId);

				const productLabel = document.createElement('span');
				productLabel.className = 'sc-product-qty-product';
				productLabel.textContent = labelsById[productId] || ('Product #' + productId);

				const minField = document.createElement('input');
				minField.type = 'number';
				minField.min = '0';
				minField.className = 'sc-product-qty-min';
				minField.placeholder = 'Minimum Qty';
				minField.value = existingValues[productId] ? existingValues[productId].min : '';

				const maxField = document.createElement('input');
				maxField.type = 'number';
				maxField.min = '0';
				maxField.className = 'sc-product-qty-max';
				maxField.placeholder = 'Maximum Qty';
				maxField.value = existingValues[productId] ? existingValues[productId].max : '';

				row.appendChild(productLabel);
				row.appendChild(minField);
				row.appendChild(maxField);

				rowsContainer.appendChild(row);

				if (index < selectedIds.length - 1) {
					const divider = document.createElement('div');
					divider.className = 'sc-product-qty-divider';
					divider.setAttribute('aria-hidden', 'true');
					divider.innerHTML = '<span>OR</span>';
					rowsContainer.appendChild(divider);
				}
			});

			wrapper.style.display = '';
		};

		buyProductField.addEventListener('change', renderRows);
		buyProductField.addEventListener('input', renderRows);

		if (window.jQuery) {
			const $buyProductField = window.jQuery(buyProductField);
			$buyProductField.on('select2:select select2:unselect select2:clear change', renderRows);
			window.jQuery(document).on('select2:select select2:unselect select2:clear', '#sc_buy_product_id', renderRows);
		}

		renderRows();
		setTimeout(renderRows, 100);
		setTimeout(renderRows, 400);
	}
});

function createCouponWithPreset(couponData, presetBuilder) {
	return createCoupon(couponData).then(function (couponResponse) {
		if (!couponResponse.id) {
			throw new Error(couponResponse.message || 'Coupon creation failed');
		}

		const presetData = presetBuilder();
		return applyPreset(couponResponse.id, presetData);
	});
}

function createCoupon(data) {
	const presetData = window.scPresetData || window.scBogoData;

	if (!presetData || !presetData.rest_url || !presetData.rest_nonce) {
		return Promise.reject(new Error('Coupon API data is not available'));
	}

	return fetch(presetData.rest_url + 'wc/v3/sc/coupons', {
		method: 'POST',
		credentials: 'same-origin',
		headers: {
			'Content-Type': 'application/json;charset=UTF-8',
			'X-WP-Nonce': presetData.rest_nonce
		},
		body: JSON.stringify(cleanPayload(data))
	}).then(handleApiResponse);
}

function applyPreset(couponId, presetData) {
	const localizedData = window.scPresetData || window.scBogoData;

	if (!localizedData || !localizedData.rest_url || !localizedData.rest_nonce) {
		return Promise.reject(new Error('Coupon API data is not available'));
	}

	return fetch(localizedData.rest_url + 'wc/v3/coupons/' + couponId, {
		method: 'POST',
		credentials: 'same-origin',
		headers: {
			'Content-Type': 'application/json',
			'X-WP-Nonce': localizedData.rest_nonce
		},
		body: JSON.stringify(cleanPayload(presetData))
	}).then(handleApiResponse);
}

function cleanPayload(data) {
	return Object.fromEntries(
		Object.entries(data).filter(function ([key, value]) {
			return value !== undefined && value !== null && value !== '';
		})
	);
}

function buildPresetPayload(presetKey, scopeNode) {
	if ('bogo' !== presetKey) {
		return {};
	}

	return buildBogoPreset(scopeNode);
}

function buildBogoPreset(scopeNode) {
	const root = scopeNode || document;
	const buyProductSelect = root.querySelector('#sc_buy_product_id');
	const productSelect = root.querySelector('#sc_product_id');

	const buyProductIds = getNumericSelectedValues(buyProductSelect);
	const productIds = getNumericSelectedValues(productSelect);

	const quantityField = root.querySelector('#sc_quantity');
	const discountAmountField = root.querySelector('#sc_discount_amount');
	const discountTypeField = root.querySelector('#sc_discount_type');
	const selectableProductsField = root.querySelector('#wc_sc_no_of_selectable_product');
	const couponMessageField = root.querySelector('#wc_coupon_message');
	const emailMessageField = root.querySelector('#wc_email_message');
	const autoApplyField = root.querySelector('#wc_sc_auto_apply_coupon');
	const productQuantityRestrictions = buildProductQuantityRestrictions(root, buyProductIds);

	return {
		product_ids: buyProductIds,
		wc_sc_add_product_ids: productIds,
		wc_sc_add_product_qty: quantityField ? quantityField.value : '',
		wc_sc_product_discount_amount: discountAmountField ? discountAmountField.value : '',
		wc_sc_product_discount_type: discountTypeField ? discountTypeField.value : '',
		wc_sc_no_of_selectable_product: selectableProductsField && selectableProductsField.checked ? 'yes' : 'no',
		wc_coupon_message: couponMessageField ? couponMessageField.value : '',
		wc_email_message: emailMessageField && emailMessageField.checked ? 'yes' : 'no',
		wc_sc_auto_apply_coupon: autoApplyField && autoApplyField.checked && 'smart_coupon' !== (discountTypeField ? String(discountTypeField.value || '').trim() : '') ? 'yes' : 'no',
		wc_sc_product_quantity_restrictions: productQuantityRestrictions
	};
}

function buildProductQuantityRestrictions(rootNode, buyProductIds) {
	const root = rootNode || document;
	const restrictionRows = Array.from(root.querySelectorAll('#sc_product_qty_restrictions_rows .sc-product-qty-row'));
	const allowedIds = Array.isArray(buyProductIds)
		? buyProductIds
				.map(function (id) {
					return parseInt(id, 10);
				})
				.filter(function (id) {
					return Number.isFinite(id);
				})
		: [];

	if (restrictionRows.length < 1 || allowedIds.length < 1) {
		return undefined;
	}

	const productValues = {};

	restrictionRows.forEach(function (row) {
		const productId = parseInt(row.getAttribute('data-product-id') || '', 10);

		if (!Number.isFinite(productId) || allowedIds.indexOf(productId) < 0) {
			return;
		}

		const minField = row.querySelector('.sc-product-qty-min');
		const maxField = row.querySelector('.sc-product-qty-max');

		productValues[String(productId)] = {
			min: minField ? String(minField.value || '').trim() : '',
			max: maxField ? String(maxField.value || '').trim() : ''
		};
	});

	if (Object.keys(productValues).length < 1) {
		return undefined;
	}

	return {
		values: {
			product: productValues,
			product_category: {},
			cart: { min: '', max: '' }
		},
		type: 'product',
		condition: 'any'
	};
}

function getSelectedValues(selectElement) {
	if (!selectElement) {
		return [];
	}

	if (selectElement.selectedOptions && selectElement.selectedOptions.length > 0) {
		return Array.from(selectElement.selectedOptions)
			.map(function (option) {
				return String(option.value || '').trim();
			})
			.filter(function (value) {
				return '' !== value;
			});
	}

	const value = String(selectElement.value || '').trim();

	if ('' === value) {
		if (window.jQuery) {
			const $element = window.jQuery(selectElement);
			const jQueryValue = $element.val();

			if (Array.isArray(jQueryValue) && jQueryValue.length > 0) {
				return jQueryValue
					.map(function (item) {
						return String(item || '').trim();
					})
					.filter(function (item) {
						return '' !== item;
					});
			}

			try {
				const select2Data = $element.select2 ? $element.select2('data') : [];
				if (Array.isArray(select2Data) && select2Data.length > 0) {
					return select2Data
						.map(function (item) {
							return String(item && item.id ? item.id : '').trim();
						})
						.filter(function (item) {
							return '' !== item;
						});
				}
			} catch (e) {
				// Ignore Select2 access issues and return empty array fallback.
			}
		}

		return [];
	}

	return value
		.split(',')
		.map(function (item) {
			return String(item).trim();
		})
		.filter(function (item) {
			return '' !== item;
		});
}

function getNumericSelectedValues(selectElement) {
	return getSelectedValues(selectElement)
		.map(function (value) {
			return parseInt(value, 10);
		})
		.filter(function (id) {
			return Number.isFinite(id);
		});
}

function handleApiResponse(response) {
	if (!response.ok) {
		return response.text().then(function (body) {
			let error;

			try {
				error = JSON.parse(body);
			} catch (e) {
				error = { message: body };
			}

			throw new Error(error.message || 'WooCommerce API Error');
		});
	}

	return response.json();
}

function escapeHtml(value) {
	return String(value)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#039;');
}

function escapeSelectorValue(value) {
	if (window.CSS && 'function' === typeof window.CSS.escape) {
		return window.CSS.escape(String(value));
	}

	return String(value).replace(/"/g, '\\"');
}
